# -*- coding: utf-8 -*-
"""
faltante.py  --  obra faltante y monto a pagar a precio nuevo, redeterminación por redeterminación.

La redeterminación se aplica SOLO a la obra que falta ejecutar en el mes en que salta:
  - R1 salta con 15 % de avance  → el 85 % que falta se paga a precios de la R1 (el 15 % ya ejecutado quedó a precio original).
  - R2 salta con 25 % de avance  → el 75 % que falta se paga a precios de la R2; el tramo 15 %→25 % quedó a precios de la R1.
  - y así con cada una.

Por cada redeterminación n (P = precio total de la obra a valores de esa redeterminación, el total de la planilla de costos;
a = avance acumulado al mes en que salta):
  faltante_n           = 100 % − a_n
  monto faltante_n     = P_n × faltante_n                      (lo que queda por pagar, a precio nuevo)
  mayor costo_n        = (P_n − P_{n−1}) × faltante_n          (lo que agrega ESTA redeterminación)
  contrato vigente_n   = contrato original + Σ mayores costos
                       = P_0·a_1 + P_1·(a_2 − a_1) + … + P_n·(1 − a_n)   (cada tramo de obra a su precio)
"""
import re

from verificador.comunes import MESES_LARGOS

MESES = list(MESES_LARGOS)


def leer_numero(txt):
    """'4.561.268.277,88' / '4561268277.88' / '$ 1.000' / '35,5 %' → float (None si vacío o no es número)."""
    if txt is None:
        return None
    if isinstance(txt, (int, float)):
        return float(txt)
    s = re.sub(r'[\s$%]', '', str(txt))
    if not s:
        return None
    if ',' in s:                                  # formato argentino: punto de miles, coma decimal
        s = s.replace('.', '').replace(',', '.')
    elif s.count('.') > 1 or re.fullmatch(r'-?\d{1,3}(\.\d{3})+', s):
        s = s.replace('.', '')                    # '4.561.268' = miles
    try:
        return float(s)
    except ValueError:
        return None


def total_final(cierre):
    """Ver verificador.costos.total_precio."""
    from verificador import costos as cs
    return cs.total_precio(cierre)


def _cierre_generico(pl, b):
    from verificador import costos as cs
    return cs.cierre_generico(pl, b)


def montos_de_planillas(planillas):
    """{n_redet: total de la obra} de cada bloque de la planilla de costos (0 = contrato original / base)."""
    from verificador import costos as cs
    out = {}
    for pl in planillas or []:
        for b in pl.bloques:
            if b.n_redet is None:
                continue
            t = None
            try:      # el PRECIO TOTAL del cierre: costo + gastos + beneficio + impuestos (ver total_final)
                t = total_final(cs.controlar_aritmetica(pl, b, []).get('cierre'))
            except Exception:
                pass
            if not t:
                try:
                    t = total_final(_cierre_generico(pl, b))
                except Exception:
                    t = None
            if not t:
                try:
                    t = cs.total_de_bloque(pl, b)
                except Exception:
                    t = None
            if t:
                out.setdefault(int(b.n_redet), round(float(t), 2))
    return out


def leer_montos(excel_path):
    """Lee la planilla de costos de un Excel (para las redeterminaciones analizadas antes de esta versión)."""
    from verificador import costos as cs
    from verificador.contexto import Contexto
    from interfaz import motor
    ctx = Contexto(excel_path, wb=motor.libro(excel_path))
    pls, _ = cs.detectar_planillas(ctx)
    return montos_de_planillas(pls)


_RE_MES = re.compile(r'-\s*(' + '|'.join(MESES) + r')\s+(\d{4})\s*$', re.I)


def mes_de_salto(nombre):
    """'Redeterminación de Precios N° 2 - Enero 2026 - Mayo 2026' → 'Mayo 2026' (el mes redeterminado)."""
    m = _RE_MES.search(nombre or '')
    return f"{m.group(1).capitalize()} {m.group(2)}" if m else ''


def mes_iso(txt):
    """'Mayo 2026' -> '2026-05' ('' si no se entiende)."""
    m = re.fullmatch(r'\s*(' + '|'.join(MESES) + r')\s+(\d{4})\s*', txt or '', re.I)
    if not m:
        return ''
    return f"{m.group(2)}-{[x.lower() for x in MESES].index(m.group(1).lower()) + 1:02d}"


def mes_anterior(iso):
    a, m = int(iso[:4]), int(iso[5:7])
    return f"{a - 1}-12" if m == 1 else f"{a}-{m - 1:02d}"


def mes_corto(iso):
    """'2026-04' -> 'abr 2026'."""
    t = mes_txt_largo(iso)
    return (t[:3] + t[t.index(' '):]) if t else ''


def certificados_de(obra):
    """Los certificados cargados de la obra, del más viejo al más nuevo: [{'n', 'mes', 'avance', 'usuario', 'cargado'}]."""
    try:
        import json
        lista = json.loads(obra.get('avance_hist_json') or '[]')
    except (ValueError, TypeError):
        lista = []
    out = sorted([dict(h) for h in lista if re.fullmatch(r'\d{4}-\d{2}', str(h.get('mes') or '')) and h.get('avance') is not None],
                 key=lambda h: h['mes'])
    previo = 0                                    # los que no tienen N°: el siguiente al anterior (numeración automática)
    for h in out:
        if h.get('n') is None:
            h['n'] = previo + 1
        previo = h['n']
    return out


def avance_al_salto(certs, mes_salto, regla=None):
    """Avance acumulado al salto (Decreto 691/16: se redetermina la parte faltante de ejecutar AL PRINCIPIO del mes en
    que se produce la variación). Si salta en mayo, los precios nuevos rigen desde el 1° de mayo, así que el avance al
    salto es el acumulado certificado al cierre de ABRIL (certificado del mes anterior; si ese mes no hubo certificado,
    el último anterior). El certificado de mayo ya se liquida entero con los precios nuevos (ver _por_certificado_mes).
    Si el primer certificado de la obra es del mes del salto o posterior, el avance al salto es 0 %.
    -> (avance, certificado | {'cero': True, ...}, mes buscado) o (None, None, mes buscado) si todavía no están cargados
    los certificados hasta el mes anterior al salto."""
    if not mes_salto:
        return None, None, ''
    objetivo = mes_anterior(mes_salto)             # cierre del mes ANTERIOR al salto
    if not certs or certs[-1]['mes'] < objetivo:
        return None, None, objetivo                # faltan los certificados hasta el mes anterior al salto
    antes = [c for c in certs if c['mes'] <= objetivo]
    if not antes:                                  # el primer certificado es del mes del salto o posterior: no había obra
        return 0.0, {'cero': True, 'n': None, 'mes': certs[0]['mes'], 'avance': 0.0}, objetivo
    return float(antes[-1]['avance']), antes[-1], objetivo


def _elegir(redets):
    """Una redeterminación por número (si hay repetidas, la más nueva que no esté rechazada)."""
    por_n, repetidas = {}, set()
    for r in sorted(redets, key=lambda r: r['id']):
        n = r.get('numero')
        if not n or r.get('estado') == 'rechazada':
            continue
        if n in por_n:
            repetidas.add(n)
        por_n[n] = r
    return [por_n[n] for n in sorted(por_n)], repetidas


def _precios_aprobados(aprobadas, alertas):
    """Precio total de la obra en cada redeterminación (0 = contrato original), tomado SOLO de los Excel aprobados de la
    obra. Cada Excel trae su propio total y el de la anterior (la planilla de costos tiene las dos columnas): vale el del
    Excel aprobado de esa misma redeterminación; si no está, el que trae la siguiente. -> ({k: (precio, fuente)})."""
    fuentes = {}
    for r in aprobadas:
        for k, v in (r.get('montos') or {}).items():
            if v:
                prio = 0 if r['numero'] == k else (1 if r['numero'] == k + 1 else 2)
                fuentes.setdefault(k, []).append((prio, r['numero'], v))
    out = {}
    for k, lst in sorted(fuentes.items()):
        lst.sort()
        prio, n, v = lst[0]
        out[k] = (v, f"Excel aprobado de la R{n}")
    return out


def matriz_precios(elegidas):
    """El precio total de cada redeterminación (filas: contrato original, R1, R2…) según CADA archivo cargado
    (columnas: el Excel de la R1, de la R2…). Cada archivo trae su propio precio y el de las anteriores: si no coinciden
    puede haber una modificación de obra (o un error). -> {'columnas': [n], 'filas': [{'k', 'propio', 'valores': {n: v},
    'difs': {n: (dif $, dif %)}}], 'n_difs'}."""
    cols = sorted({r['numero'] for r in elegidas if r.get('montos')})
    tope = max([r['numero'] for r in elegidas if r.get('numero')] or [0]) + 1      # descarta rótulos mal leídos (ej. «R23»)
    ks = sorted({k for r in elegidas for k in (r.get('montos') or {}) if 0 <= k <= tope})
    filas, n_difs = [], 0
    por_n = {r['numero']: r for r in elegidas}
    for k in ks:
        valores = {n: (por_n[n].get('montos') or {}).get(k) for n in cols}
        valores = {n: v for n, v in valores.items() if v}
        propio = valores.get(k)
        ref = propio if propio else (valores[min(valores)] if valores else None)
        difs = {}
        for n, v in valores.items():
            if ref and abs(v - ref) > 1:
                difs[n] = (v - ref, (v / ref - 1) * 100)
        n_difs += len(difs)
        filas.append({'k': k, 'nombre': f'R{k}' if k else 'Contrato original', 'propio': propio, 'valores': valores,
                      'difs': difs, 'ref_de': k if propio else (min(valores) if valores else None)})
    return {'columnas': cols, 'filas': filas, 'n_difs': n_difs,
            'estados': {n: por_n[n].get('estado') for n in cols}}


# Plan de trabajos: si al salto el avance real acumulado es INFERIOR AL PREVISTO MENOS 5 PUNTOS (tolerancia absoluta:
# real < previsto − 5), la obra está caída del plan y NO corresponde redeterminar: se sigue a precios de la última
# redeterminación que sí correspondió. Se puede habilitar a mano, con motivo (por cuestiones administrativas).
TOLERANCIA_PLAN = 5.0                                    # puntos de avance (absolutos)


def _pts(v):
    return f"{v:,.4f}".replace(',', 'X').replace('.', ',').replace('X', '.') + ' puntos'


def cuadro(obra, redets):
    """Todo lo que muestra la tarjeta de la obra y el Excel del cuadro. Los precios salen solos de los Excel APROBADOS
    de la obra (total de la planilla de costos); lo único que se carga es el avance de cada redeterminación."""
    elegidas, repetidas = _elegir(redets)
    alertas = []
    if repetidas:
        alertas.append('Hay números de redeterminación repetidos (' + ', '.join(f'R{n}' for n in sorted(repetidas))
                       + '): se usa la cargada más recientemente de cada uno.')
    aprobadas = [r for r in elegidas if r.get('estado') == 'aprobada']
    precios = _precios_aprobados(aprobadas, alertas)
    matriz = matriz_precios(elegidas)
    if matriz['n_difs']:
        alertas.append(f"Hay {matriz['n_difs']} diferencia(s) de precio entre los archivos (posibles modificaciones de obra): "
                       "mirá «Precio de cada redeterminación según cada archivo». Cada redeterminación usa el de su propio archivo.")
    del_excel = {k: v for k, (v, _) in precios.items()}
    # correcciones a mano (por si el programa leyó mal el total de un Excel): reemplazan al del Excel y quedan a la vista
    correcciones = []
    for k, m in sorted((obra.get('precios_manual') or {}).items()):
        if not m or m.get('valor') is None:
            continue
        precios[k] = (m['valor'], f"corregido a mano por {m.get('usuario') or '?'}")
        que = 'Contrato original' if k == 0 else f'R{k}'
        correcciones.append({'k': k, 'que': que, 'valor': m['valor'], 'excel': del_excel.get(k), 'usuario': m.get('usuario') or '',
                             'fecha': m.get('fecha') or ''})
    p0, p0_fuente = precios.get(0, (None, ''))

    certs = certificados_de(obra)
    regla = 'mismo'
    filas = []
    prev_avance, prev_n = 0.0, 0
    vigente = p0
    rige, rige_nombre = p0, 'contrato original'      # el precio que está rigiendo (la última que correspondió)
    ant_excluida = False
    for r in elegidas:
        n = r['numero']
        f = r.get('faltante') or {}
        aprobada = r.get('estado') == 'aprobada'
        precio, fuente = precios.get(n, (None, '')) if aprobada else (None, '')
        precio_ant, fuente_ant = precios.get(n - 1, (None, ''))
        manual_av = f.get('avance')
        mes_salto_origen = 'manual' if f.get('mes_salto') else ('Excel' if r.get('mes_salto_var') else 'nombre')
        mes_salto = f.get('mes_salto') or r.get('mes_salto_var') or mes_iso(mes_de_salto(r['nombre']))
        av_cert, cert, buscado = avance_al_salto(certs, mes_salto, regla)
        avance = av_cert if av_cert is not None else manual_av
        info_cert = None
        if cert is not None:
            info_cert = {'n': cert.get('n'), 'mes': cert['mes'], 'mes_txt': mes_corto(cert['mes']), 'cero': bool(cert.get('cero')),
                         'manual_dif': manual_av if (manual_av is not None and abs(manual_av - av_cert) > 0.005) else None}
        if n - 1 > 0 and n - 1 not in precios and prev_n != n - 1:
            alertas.append(f"Falta la R{n - 1} aprobada en esta obra: sin su precio no se puede calcular la R{n}.")
        if avance is not None and prev_avance is not None and avance < prev_avance:
            alertas.append(f"R{n}: el avance ({_pct(avance)}) es menor que el de la redeterminación anterior ({_pct(prev_avance)}).")
        faltante = None if avance is None else max(0.0, 100.0 - avance)
        # plan de trabajos: real vs previsto al mes del salto
        previsto = f.get('previsto')
        atraso = (previsto - avance) if (previsto is not None and avance is not None) else None
        limite = previsto - TOLERANCIA_PLAN if previsto is not None else None      # mínimo exigido (real ≥ previsto − 5)
        caida = bool(atraso is not None and avance < limite - 1e-9)
        habilitada = f.get('habilitada') if caida else None          # {'motivo', 'usuario', 'fecha'}
        no_corresponde = bool(aprobada and caida and not habilitada)
        if ant_excluida:                            # la anterior no correspondió: se compara con el precio que regía
            precio_ant, fuente_ant = rige, f'{rige_nombre} (la anterior no correspondió por atraso)'
        if no_corresponde:
            alertas.append(f"R{n}: obra caída del plan al salto: real {_pct(avance)}, previsto {_pct(previsto)} (atraso de "
                           f"{_pts(atraso)}; mínimo previsto − 5 = {_pct(limite)}). No corresponde redeterminar: sigue a precios de "
                           f"{'la ' if rige_nombre.startswith('R') else 'el '}{rige_nombre}.")
            monto_faltante = rige * faltante / 100 if (rige and faltante is not None) else None
            mayor = 0.0 if faltante is not None else None
        else:
            monto_faltante = precio * faltante / 100 if (precio and faltante is not None) else None
            mayor = (precio - precio_ant) * faltante / 100 if (precio and precio_ant and faltante is not None) else None
        vigente = vigente + mayor if (vigente is not None and mayor is not None) else None
        if aprobada and not no_corresponde and precio:
            rige, rige_nombre = precio, f'R{n}'
        ant_excluida = no_corresponde
        manual = next((x for x in correcciones if x['k'] == n), None) if aprobada else None
        filas.append({'id': r['id'], 'numero': n, 'nombre': r['nombre'],
                      'mes': (mes_txt_largo(mes_salto).capitalize() if mes_salto else ''), 'mes_salto_origen': mes_salto_origen,
                      'falta_mes_var': r.get('mes_salto_var') is None and bool(r.get('excel_ruta')),
                      'manual': manual, 'precio_excel': del_excel.get(n),
                      'estado': r.get('estado'), 'estado_txt': _nombre_estado(r.get('estado')), 'aprobada': aprobada, 'avance': avance, 'faltante': faltante,
                      'precio': precio, 'fuente': fuente, 'precio_ant': precio_ant, 'fuente_ant': fuente_ant,
                      'variacion': (precio / precio_ant - 1) if (precio and precio_ant) else None,
                      'monto_faltante': monto_faltante, 'mayor': mayor, 'vigente': vigente,
                      'tiene_montos': bool(r.get('montos')), 'cert': info_cert, 'mes_salto': mes_salto,
                      'cert_buscado': buscado, 'cert_buscado_txt': mes_txt_largo(buscado),
                      'previsto': previsto, 'atraso': atraso, 'no_corresponde': no_corresponde,
                      'plan': (None if atraso is None else ('habilitada' if (caida and habilitada) else ('atrasada' if caida else
                               ('adelantada' if atraso < 0 else 'en plan')))),
                      'caida': caida, 'habilitada': habilitada, 'limite': limite,
                      'cumplimiento': (avance / previsto * 100) if (atraso is not None and previsto) else None,
                      'rige_txt': rige_nombre if no_corresponde else ''})
        if avance is not None:
            prev_avance = avance
        prev_n = n

    # tramos: cada parte de la obra con el precio al que se paga (solo con las aprobadas)
    calc = [x for x in filas if x['aprobada']]
    aplican = [x for x in calc if not x['no_corresponde']]          # las que no corresponden por atraso no abren tramo
    tramos = []
    niveles = [{'nombre': 'Contrato original', 'precio': p0, 'desde': 0.0}] + \
              [{'nombre': f"R{x['numero']}", 'precio': x['precio'], 'desde': x['avance']} for x in aplican]
    for i, nv in enumerate(niveles):
        hasta = niveles[i + 1]['desde'] if i + 1 < len(niveles) else 100.0
        pct = (hasta - nv['desde']) if (hasta is not None and nv['desde'] is not None) else None
        tramos.append({'nombre': nv['nombre'], 'desde': nv['desde'], 'hasta': hasta, 'pct': pct,
                       'monto': nv['precio'] * pct / 100 if (nv['precio'] and pct is not None) else None,
                       'ultimo': i == len(niveles) - 1})

    # cada tramo separado en OBRA BÁSICA (al precio original) y REDETERMINADO (lo que se suma por encima)
    for t in tramos:
        t['basico'] = p0 * t['pct'] / 100 if (p0 and t['pct'] is not None) else None
        t['redet'] = (t['monto'] - t['basico']) if (t['monto'] is not None and t['basico'] is not None) else None
    hoy = _a_hoy(obra, tramos, p0, alertas, calc)
    saltos = [(x['mes_salto'], f"R{x['numero']}", x['precio']) for x in aplican]
    lista_certs = _por_certificado(certs, tramos, p0, alertas, saltos)
    p_vig = next((x['precio'] for x in reversed(aplican) if x['precio']), p0)
    hoy = _hoy_por_certificados(hoy, lista_certs, p0, p_vig, obra)

    ult = next((x for x in reversed(calc) if x['monto_faltante'] is not None), None)
    resumen = None
    if ult:
        hasta_ult = [x for x in calc if x['numero'] <= ult['numero']]
        resumen = {'numero': ult['numero'], 'mes': ult['mes'], 'faltante': ult['faltante'],
                   'queda': ult['monto_faltante'], 'precio': ult['precio'],
                   'mayores': sum(x['mayor'] for x in hasta_ult) if all(x['mayor'] is not None for x in hasta_ult) else None,
                   'vigente': ult['vigente']}
    return {'p0': p0, 'p0_fuente': p0_fuente, 'p0_excel': del_excel.get(0),
            'p0_manual': next((x for x in correcciones if x['k'] == 0), None), 'correcciones': correcciones, 'filas': filas, 'tramos': tramos, 'resumen': resumen, 'alertas': alertas,
            'faltan_montos': [x['numero'] for x in calc if not x['tiene_montos']],
            'hoy': hoy, 'p_vigente': next((x['precio'] for x in reversed(aplican) if x['precio']), p0),
            'sin_previsto': [x['numero'] for x in calc if x['previsto'] is None],
            'no_corresponden': [x['numero'] for x in calc if x['no_corresponde']], 'tolerancia_plan': TOLERANCIA_PLAN,
            'n_aprobadas': len(calc), 'pendientes': [x['numero'] for x in filas if not x['aprobada']],
            'sin_avance': [x['numero'] for x in calc if x['avance'] is None],
            'falta_mes_var': [x['numero'] for x in filas if x['falta_mes_var']],
            'certificados': lista_certs, 'regla': regla, 'matriz_precios': matriz,
            'certs_total': _sumar(lista_certs), 'cert_siguiente': _siguiente(certs, obra)}


def _siguiente(certs, obra):
    """Lo que se propone en la fila nueva de la tabla de certificados: el número y el mes que siguen."""
    if not certs:
        return {'n': None, 'mes': '', 'avance': obra.get('avance_actual')}
    u = certs[-1]
    a, m = int(u['mes'][:4]), int(u['mes'][5:7])
    mes = f"{a + 1}-01" if m == 12 else f"{a}-{m + 1:02d}"
    return {'n': (int(u['n']) + 1) if u.get('n') is not None else None, 'mes': mes, 'avance': None}


def _sumar(lista):
    if not lista or any(c['total'] is None for c in lista):
        return None
    return {k: sum(c[k] for c in lista) for k in ('basico', 'redet', 'total')} | {'avance': lista[-1]['avance']}


def _por_certificado(certs, tramos, p0, alertas, saltos=None):
    """Cada certificado con lo que le corresponde pagar: la obra de ese mes (acumulado − acumulado anterior), separada
    en obra básica (al precio original) y redeterminado.
    Con 'saltos' [(mes del salto 'AAAA-MM', 'R1', precio total)] (las redeterminaciones que corresponden, en orden):
    cada certificado se paga ENTERO al precio de la última redeterminación que saltó en su mes o antes (salta en mayo
    -> el certificado de mayo ya va a precio de esa redeterminación). Sin 'saltos': tramo por tramo según el avance."""
    if saltos is not None:
        return _por_certificado_mes(certs, p0, alertas, saltos)
    completos = tramos and all(t['monto'] is not None and t['pct'] is not None for t in tramos) and p0
    out, prev = [], 0.0
    for c in certs:
        a = float(c['avance'])
        if a < prev - 0.005:
            alertas.append(f"El certificado {('N° ' + str(c['n']) + ' ') if c.get('n') else ''}de {mes_txt_largo(c['mes'])} "
                           f"tiene un acumulado ({_pct(a)}) menor que el anterior ({_pct(prev)}).")
        b = r = 0.0
        precios = []
        if completos:
            for t in tramos:
                parte = max(0.0, min(t['hasta'], a) - max(t['desde'], prev))
                if parte > 0:
                    b += p0 * parte / 100
                    r += (t['monto'] / t['pct'] * parte if t['pct'] else 0.0) - p0 * parte / 100
                    precios.append(t['nombre'])
        out.append({'n': c.get('n'), 'mes': c['mes'], 'mes_txt': mes_txt_largo(c['mes']), 'mes_corto': mes_corto(c['mes']),
                    'avance': a, 'del_mes': a - prev,
                    'basico': b if completos else None, 'redet': r if completos else None,
                    'total': (b + r) if completos else None, 'precios': precios,
                    'usuario': c.get('usuario') or '', 'cargado': c.get('cargado') or ''})
        prev = max(prev, a)
    return out


def _por_certificado_mes(certs, p0, alertas, saltos):
    saltos = sorted(saltos, key=lambda x: x[0] or '')
    completos = bool(p0) and all(m and pr for m, _, pr in saltos)
    out, prev = [], 0.0
    for c in certs:
        a = float(c['avance'])
        if a < prev - 0.005:
            alertas.append(f"El certificado {('N° ' + str(c['n']) + ' ') if c.get('n') else ''}de {mes_txt_largo(c['mes'])} "
                           f"tiene un acumulado ({_pct(a)}) menor que el anterior ({_pct(prev)}).")
        del_mes = a - prev
        rige_n, rige_p = 'Contrato original', p0
        escalones, ant = {}, p0             # lo que suma CADA redeterminación en este certificado (escalonado)
        for m, nombre, pr in saltos:
            if m and m <= c['mes']:
                rige_n, rige_p = nombre, pr
                if completos:
                    escalones[nombre] = (pr - ant) * del_mes / 100
                ant = pr
        b = p0 * del_mes / 100 if completos else None
        r = (rige_p - p0) * del_mes / 100 if completos else None
        out.append({'n': c.get('n'), 'mes': c['mes'], 'mes_txt': mes_txt_largo(c['mes']), 'mes_corto': mes_corto(c['mes']),
                    'avance': a, 'del_mes': del_mes, 'basico': b, 'redet': r,
                    'total': (b + r) if completos else None, 'precios': [rige_n], 'precio_rige': rige_p, 'escalones': escalones,
                    'usuario': c.get('usuario') or '', 'cargado': c.get('cargado') or ''})
        prev = max(prev, a)
    return out


def _hoy_por_certificados(hoy, lista, p0, p_vig, obra):
    """Con certificados cargados: lo ya certificado es la suma de los certificados (cada uno a su precio) y lo que falta
    es la obra que queda por ejecutar al precio que rige hoy. Monto final = certificado + falta."""
    if not hoy or not lista or any(x['total'] is None for x in lista) or not p0 or not p_vig:
        return hoy
    cerrada = bool(obra.get('cerrada'))
    av = 100.0 if cerrada else lista[-1]['avance']
    pb = sum(x['basico'] for x in lista)
    pr = sum(x['redet'] for x in lista)
    resto = max(0.0, 100.0 - av)
    fb, fr = p0 * resto / 100, (p_vig - p0) * resto / 100
    hoy.update({'avance': av, 'pagado_b': pb, 'pagado_r': pr, 'pagado': pb + pr,
                'falta_b': fb, 'falta_r': fr, 'falta': fb + fr, 'terminada': av >= 100.0,
                'final_b': pb + fb, 'final_r': pr + fr, 'final': pb + pr + fb + fr, 'por_certificados': True})
    if hoy['terminada']:
        hoy.update({'falta_b': 0.0, 'falta_r': 0.0, 'falta': 0.0, 'final_b': pb, 'final_r': pr, 'final': pb + pr})
    return hoy


def _a_hoy(obra, tramos, p0, alertas, calc):
    """Monto final de la obra (a hoy) y, con el avance de hoy, lo ya pagado y lo que falta pagar, cada uno separado en
    obra básica y redeterminado. Obra cerrada = 100 %: no queda nada por pagar."""
    if not tramos or any(t['monto'] is None or t['basico'] is None for t in tramos):
        return None
    final_b = sum(t['basico'] for t in tramos)
    final_r = sum(t['redet'] for t in tramos)
    cerrada = bool(obra.get('cerrada'))
    avance = 100.0 if cerrada else obra.get('avance_actual')
    out = {'final_b': final_b, 'final_r': final_r, 'final': final_b + final_r, 'cerrada': cerrada, 'avance': avance,
           'fecha': obra.get('cerrada_fecha') if cerrada else obra.get('avance_actual_fecha'), 'pagado': None,
           'mes': None if cerrada else obra.get('avance_actual_mes'),
           'mes_txt': '' if cerrada else mes_txt_largo(obra.get('avance_actual_mes'))}
    if avance is None:
        return out
    ult_salto = max((x['avance'] for x in calc if x['avance'] is not None), default=0.0)
    if not cerrada and avance < ult_salto:
        alertas.append(f"El avance de hoy ({_pct(avance)}) es menor que el de la última redeterminación ({_pct(ult_salto)}).")
    pb = pr = 0.0
    for t in tramos:
        parte = max(0.0, min(t['hasta'], avance) - t['desde'])
        if parte > 0:
            pb += p0 * parte / 100
            pr += (t['monto'] / t['pct'] * parte if t['pct'] else 0.0) - p0 * parte / 100
    out.update({'pagado_b': pb, 'pagado_r': pr, 'pagado': pb + pr,
                'falta_b': max(0.0, final_b - pb), 'falta_r': max(0.0, final_r - pr),
                'terminada': avance >= 100.0})
    out['falta'] = 0.0 if out['terminada'] else out['falta_b'] + out['falta_r']
    if out['terminada']:
        out['falta_b'] = out['falta_r'] = 0.0
    return out


def mes_txt_largo(mes):
    """'2026-10' -> 'octubre 2026'."""
    m = re.fullmatch(r'(\d{4})-(\d{2})', mes or '')
    return f"{MESES[int(m.group(2)) - 1].lower()} {m.group(1)}" if m and 1 <= int(m.group(2)) <= 12 else ''


def _nombre_estado(e):
    try:
        from interfaz.almacen import NOMBRE_ESTADO
        return NOMBRE_ESTADO.get(e, e or '')
    except Exception:
        return e or ''


def _pesos(v):
    return '$ ' + f"{v:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.') if v is not None else '—'


def _pct(v):
    return f"{v:,.4f} %".replace(',', 'X').replace('.', ',').replace('X', '.') if v is not None else '—'


pesos, pct = _pesos, _pct

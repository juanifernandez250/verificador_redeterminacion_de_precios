# -*- coding: utf-8 -*-
"""
items_indec.py  --  CONTROL 1: ítems INDEC
-------------------------------------------
Compara cada código de índice que declara la contratista (en su hoja de índices) para un mes
contra el valor OFICIAL del boletín "INDEC Informa" (PDF).

Pasos:
    prep = preparar(wb, hoja=None)                  # detecta hoja, columna de códigos y columnas de fecha
    res  = verificar_mes(wb, prep, boletin, ym)     # compara un mes contra un boletín
"""
import re
import datetime as dt

from openpyxl.utils import get_column_letter as L

from .comunes import (ErrorVerificacion, MESES_TXT, TOL_INDICE, barra_progreso, mes_txt, num,
                      strip_accents)
from .excel import es_hoja_de_datos
from .pdf_indec import ART15_INCISO_RE

CODE_LIKE_RE = re.compile(r'^\(?\d{1,3}\)?\s*\d{3,6}(\s*-\s*\d{1,3})?$|^\d{1,3}(\.\d{1,2})?-\d{1,4}$')
SHEET_NAME_HINTS = ['indic', 'índic']


def es_codigo_valido(sval):
    return bool(CODE_LIKE_RE.match(sval)) or bool(ART15_INCISO_RE.match(sval.strip()))


# ----------------------------------------------------------------------
# Detección de la hoja, la columna de códigos y las columnas de fecha
# ----------------------------------------------------------------------
_ENCABEZADO_CODIGO = ('codigo', 'cpc', 'indicador')


def _puntuar_columnas(ws, max_row=600, max_col=40):
    """{columna: (celdas de TEXTO con forma de código, números con forma de código, encabezado que dice 'código')}.
    Los números sueltos (precios de 4 a 9 dígitos) NO se cuentan como códigos: en una planilla de materiales
    la columna de precios totales tiene muchos y le ganaba a la de códigos reales."""
    max_row = min(ws.max_row, max_row)
    max_col = min(ws.max_column, max_col)
    out = {}
    for col in range(1, max_col + 1):
        n_txt = n_num = 0
        enc = False
        for row in range(1, max_row + 1):
            v = ws.cell(row=row, column=col).value
            if v is None:
                continue
            if isinstance(v, str):
                t = v.strip()
                if es_codigo_valido(t):
                    n_txt += 1
                elif row <= 15 and any(k in strip_accents(t.lower()) for k in _ENCABEZADO_CODIGO) and len(t) <= 30:
                    enc = True
            elif isinstance(v, int) and not isinstance(v, bool) and 1000 <= v <= 999999:
                n_num += 1
            elif isinstance(v, float) and v == int(v) and 1000 <= v <= 999999:
                n_num += 1
        out[col] = (n_txt, n_num, enc)
    return out


def _puntaje(t):
    n_txt, n_num, enc = t
    return n_txt * 1000 + n_num + (500 if enc and (n_txt or n_num) else 0)


def _mejor_columna(cuenta):
    """(columna, (n_txt, n_num, enc)) de la columna con más códigos, o None si no hay ninguna."""
    if not cuenta:
        return None
    col = max(cuenta, key=lambda c: (_puntaje(cuenta[c]), -c))
    return (col, cuenta[col]) if _puntaje(cuenta[col]) > 0 else None


def detectar_hoja_columna_codigos(wb, hoja_forzada=None):
    """(n_códigos, hoja, columna) de la hoja de índices de la contratista, o None.
    Sin hoja forzada, prefiere 'Indices Seleccionados' (el subconjunto realmente usado en la obra),
    luego cualquier hoja 'Indices', y por último cualquier hoja con muchas celdas con forma de código."""
    if hoja_forzada is not None:
        mejor = _mejor_columna(_puntuar_columnas(wb[hoja_forzada]))
        if mejor is None:
            return None
        col, (n_txt, n_num, _) = mejor
        return (n_txt or n_num, hoja_forzada, col)
    todas = [s for s in wb.sheetnames if es_hoja_de_datos(wb[s])]
    preferidas = [s for s in todas if 'selecc' in s.lower()]
    otras_indic = [s for s in todas if any(h in s.lower() for h in SHEET_NAME_HINTS) and s not in preferidas]
    resto = [s for s in todas if s not in preferidas and s not in otras_indic]
    for grupo in (preferidas, otras_indic, resto):
        mejor = None
        for nombre in grupo:
            m = _mejor_columna(_puntuar_columnas(wb[nombre]))
            if m is None:
                continue
            col, t = m
            if (t[0] >= 5 or (t[0] == 0 and t[1] >= 5)) and (mejor is None or _puntaje(t) > mejor[0]):
                mejor = (_puntaje(t), nombre, col, t[0] or t[1])
        if mejor:
            return (mejor[3], mejor[1], mejor[2])
    return None


def construir_lookup_merges(ws):
    """{(fila, col): valor} de las celdas combinadas (openpyxl solo guarda el valor en la 1ª celda)."""
    lookup = {}
    for rng in ws.merged_cells.ranges:
        top_val = ws.cell(row=rng.min_row, column=rng.min_col).value
        if top_val is None:
            continue
        for r in range(rng.min_row, rng.max_row + 1):
            for c in range(rng.min_col, rng.max_col + 1):
                lookup[(r, c)] = top_val
    return lookup


def detectar_columnas_fecha(ws, col_codigo, header_search_rows=40, col_span=20):
    """{columna: (año, mes)} de las columnas de mes cercanas a la de códigos. Busca en el encabezado
    fechas reales o texto tipo 'Mar-26' / 'Abr-2026' / '03-2026' (también dentro de un texto más largo)
    y contempla celdas combinadas."""
    merge_lookup = construir_lookup_merges(ws)
    resultado = {}
    pat_txt = re.compile(r'([A-Za-zÁÉÍÓÚáéíóú]{3,})[\-/\s]+(\d{2,4})')
    pat_num = re.compile(r'^(\d{1,2})[\-/](\d{4})$')
    pat_dma = re.compile(r'^(\d{1,2})[\-/.](\d{1,2})[\-/.](\d{4})$')
    col_min = max(1, col_codigo - 2)
    col_max = col_codigo + col_span
    for row in range(1, header_search_rows + 1):
        for col in range(col_min, col_max):
            v = ws.cell(row=row, column=col).value
            if v is None:
                v = merge_lookup.get((row, col))
            if isinstance(v, (dt.datetime, dt.date)):
                resultado[col] = (v.year, v.month)
            elif isinstance(v, str):
                vs = v.strip()
                m = pat_num.match(vs)
                if m:
                    resultado[col] = (int(m.group(2)), int(m.group(1)))
                    continue
                m = pat_dma.match(vs)               # '1/5/2026' escrito como texto: día/mes/año (formato argentino)
                if m and 1 <= int(m.group(2)) <= 12:
                    resultado[col] = (int(m.group(3)), int(m.group(2)))
                    continue
                m = pat_txt.search(vs)
                if m:
                    mes = MESES_TXT.get(strip_accents(m.group(1).lower())[:3])
                    if mes:
                        anio = int(m.group(2))
                        resultado[col] = (anio + 2000 if anio < 100 else anio, mes)
    return resultado


def vista_previa(ws, col_codigo, filas=15, col_span=20):
    """Líneas de texto con el contenido de las primeras filas cerca de la columna de códigos
    (para ayudar al usuario a ubicar la columna del valor declarado)."""
    col_min = max(1, col_codigo - 2)
    col_max = col_codigo + col_span
    merge_lookup = construir_lookup_merges(ws)
    out = []
    for row in range(1, filas + 1):
        valores = []
        for col in range(col_min, col_max):
            v = ws.cell(row=row, column=col).value
            if v is None:
                v = merge_lookup.get((row, col))
            if v is not None:
                valores.append(f"{L(col)}={v!r}")
        if valores:
            out.append(f"fila {row}: " + '  '.join(valores))
    return out


class PrepItems:
    """Lo que se detectó en el Excel para el control de ítems (no depende del mes ni del PDF)."""

    def __init__(self, hoja, col_codigos, n_codigos, fechas_col, ejemplos=(), numericos=False):
        self.hoja = hoja
        self.col_codigos = col_codigos
        self.n_codigos = n_codigos
        self.fechas_col = fechas_col          # {columna: (año, mes)}
        self.ejemplos = list(ejemplos)        # primeros códigos, para que el usuario vea si es la columna correcta
        self.numericos = numericos            # los códigos están escritos como números (solo si no hay ninguno como texto)

    def columna_del_mes(self, ym):
        """Primera columna cuyo encabezado es ese mes, o None."""
        for c, m in self.fechas_col.items():
            if m == ym:
                return c
        return None

    def descripcion(self):
        ej = ', '.join(self.ejemplos[:3])
        return f"hoja '{self.hoja}', códigos en la columna {L(self.col_codigos)} ({self.n_codigos} códigos" + (f", ej. {ej}" if ej else '') + ")"


def preparar(wb, hoja=None, col_codigos=None):
    """Detecta hoja, columna de códigos y columnas de fecha. Devuelve PrepItems o None si no encontró
    ninguna hoja con códigos. hoja / col_codigos: lo que indicó el usuario a mano."""
    hallazgo = detectar_hoja_columna_codigos(wb, hoja_forzada=hoja)
    if not hallazgo:
        return None
    n, nombre, col = hallazgo
    ws = wb[nombre]
    if col_codigos is not None:
        col = col_codigos
    n_txt, n_num, _ = _puntuar_columnas(ws)[col] if col <= min(ws.max_column, 40) else (0, 0, False)
    numericos = n_txt == 0
    filas = _leer_filas_excel(ws, col, None, numericos)
    if not filas:
        return None
    return PrepItems(nombre, col, len(filas), detectar_columnas_fecha(ws, col), list(dict.fromkeys(f['codigo'] for f in filas))[:3], numericos)


# ----------------------------------------------------------------------
# Comparación contra el boletín
# ----------------------------------------------------------------------
def sugerir_codigo(boletin, codigo, ym):
    """Si un código no aparece en el PDF, prueba variantes recortando el final (error de tipeo, ej.
    '83107-11' en vez de '83107-1') y devuelve la primera que sí encuentre algo."""
    base = codigo.strip()
    candidatos = []
    if len(base) > 3:
        candidatos.append(base[:-1])
    if len(base) > 4:
        candidatos.append(base[:-2])
    for variante in candidatos:
        matches = boletin.buscar(variante, ym)
        if matches:
            return variante, matches
    return None, []


def _valor_pdf(txt):
    """'13.805,7' -> 13805.7 ; 's' (sin dato) -> None"""
    return num(txt) if txt not in (None, 's') else None


def _leer_filas_excel(ws, col_codigo, col_valor, numericos=False):
    filas = []
    vistos = set()
    for row in range(1, ws.max_row + 1):
        v = ws.cell(row=row, column=col_codigo).value
        if v is None or (not isinstance(v, str) and not numericos):
            continue                        # un número suelto solo vale como código si TODA la columna son números
        if isinstance(v, float) and v == int(v):
            v = int(v)
        sval = str(v).strip()
        if es_codigo_valido(sval) and (row, sval) not in vistos:
            vistos.add((row, sval))
            declarado = None
            if col_valor is not None:
                declarado = num(ws.cell(row=row, column=col_valor).value)
            filas.append({'fila': row, 'codigo': sval, 'declarado': declarado})
    return filas


def verificar_mes(wb, prep, boletin, ym, col_valor, progreso=True, otros=()):
    """Compara los códigos de la hoja de la contratista para el mes 'ym' contra el boletín.
    col_valor: columna del valor declarado para ese mes (None = solo se trae el valor oficial).
    otros: los demás boletines cargados; SOLO para avisar (sin cambiar el estado) que traen ese mes con otro valor:
    cada mes se compara con el boletín de ese mes."""
    if ym not in boletin.meses:
        raise ErrorVerificacion(f"El mes {mes_txt(ym)} no está en '{boletin.nombre}'. "
                                f"Meses disponibles: {boletin.texto_meses()}")
    ws = wb[prep.hoja]
    filas_excel = _leer_filas_excel(ws, prep.col_codigos, col_valor, prep.numericos)
    if not filas_excel:
        raise ErrorVerificacion(f"No encontré códigos en la hoja '{prep.hoja}' (columna {L(prep.col_codigos)}).")
    col_celda = col_valor if col_valor is not None else prep.col_codigos

    filas = []
    total = len(filas_excel)
    for n, fe in enumerate(filas_excel, start=1):
        if progreso:
            barra_progreso(n, total, prefijo=f'  Ítems {mes_txt(ym)} vs {boletin.nombre[:24]}')
        codigo, declarado = fe['codigo'], fe['declarado']
        celda = f"{prep.hoja}!{L(col_celda)}{fe['fila']}"
        base = {'celda': celda, 'codigo': codigo, 'declarado': declarado, 'codigo_oficial': None,
                'oficial': None, 'dif': None, 'estado': '', 'cat': '', 'ambiguo': False}
        matches = boletin.buscar(codigo, ym)
        if not matches:
            sug, matches_sug = sugerir_codigo(boletin, codigo, ym)
            if sug:
                filas.append(dict(base, codigo_oficial=matches_sug[0]['codigo_oficial'],
                                  oficial=_valor_pdf(matches_sug[0]['valor']), cat='typo',
                                  estado=f"SIN MATCH -- ¿Typo? ¿Quisiste decir '{sug}'?"))
            else:
                filas.append(dict(base, cat='sin_match', estado='SIN MATCH EN PDF'))
            continue
        # Si el código es ambiguo (varias coincidencias) pero UNA da exactamente el valor declarado,
        # esa es la correcta: las demás son otros productos que comparten el código genérico.
        evaluados = []
        for m in matches:
            oficial = _valor_pdf(m['valor'])
            if declarado is not None and oficial not in (None, 0):
                dif = declarado - oficial
                cat = 'ok' if abs(dif) <= TOL_INDICE else 'revisar'
                dif_rel = dif / oficial
            else:
                cat, dif_rel = 'sin_datos', None
            evaluados.append((m, oficial, dif_rel, cat))
        if any(e[3] == 'ok' for e in evaluados):
            evaluados = [e for e in evaluados if e[3] == 'ok']
        estados = {'ok': 'OK', 'revisar': 'REVISAR', 'sin_datos': 'Sin datos para comparar'}
        nota, otro = '', None
        if declarado is not None and all(e[3] == 'revisar' for e in evaluados):
            for b2 in otros:                       # solo informativo: otro boletín trae ese mes con otro valor
                if b2.ultimo_mes == ym:
                    v2 = [v for v, _ in b2.valores(codigo, ym)]
                    if v2:
                        nota = f" (ojo: '{b2.nombre}' también trae {mes_txt(ym)}: {v2[0]:g}; se compara con el boletín de ese mes)"
                        otro = (b2.nombre, v2[0])
                        break
        for m, oficial, dif_rel, cat in evaluados:
            filas.append(dict(base, codigo_oficial=m['codigo_oficial'], oficial=oficial, dif=dif_rel, cat=cat,
                              estado=estados[cat] + (nota if cat == 'revisar' else ''), ambiguo=len(evaluados) > 1,
                              cuadro=m['cuadro'], boletin=boletin.nombre, otro=otro if cat == 'revisar' else None))

    cuenta = {k: sum(1 for f in filas if f['cat'] == k) for k in ('ok', 'revisar', 'typo', 'sin_match', 'sin_datos')}
    return {'ym': ym, 'boletin': boletin.nombre, 'hoja': prep.hoja, 'col_codigos': prep.col_codigos,
            'col_valor': col_valor, 'filas': filas, 'cuenta': cuenta, 'n_codigos': total}

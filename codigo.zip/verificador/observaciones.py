# -*- coding: utf-8 -*-
"""
observaciones.py
-----------------
Pasa de "un hallazgo por celda" a "una OBSERVACION por causa", que es lo que se le presenta a la empresa:

  - Agrupa lo repetido: un índice mal cargado que aparece en 29 hojas es UNA observación con 29 lugares; el mismo
    valor mal en la hoja de origen (ej. Materiales) y en las hojas que lo toman también es una sola.
  - Gravedad:  ERROR (hay que corregir)  |  MENOR (diferencia chica o dato provisorio del INDEC: a criterio)  |
               AVISO (no es un error, conviene mirarlo).
  - Impacto estimado en $ cuando se puede calcular (costo directo y, con gastos/beneficio/impuestos, en el total).
  - Fuente (boletín, cuadro), causa raíz (fórmula o dato de origen) y la corrección que se solicita.

Cada observación tiene una 'firma' estable (para compararla entre corridas y para las pruebas automáticas).
"""
import re

from .comunes import TOL_INDICE, fmt_es, mes_txt

# una diferencia relativa menor a esto se considera "menor" (redondeo o revisión del INDEC)
UMBRAL_MENOR = 0.0015
GRAVEDADES = ('ERROR', 'MENOR', 'AVISO')
NOMBRE_GRAVEDAD = {'ERROR': 'Error', 'MENOR': 'Diferencia menor', 'AVISO': 'Aviso'}
NOMBRE_CONTROL = {'items': 'Ítems INDEC', 'var': 'VAR', 'ap': 'Análisis de precios', 'costos': 'Planilla de costos'}


class Ubicacion:
    """Un lugar concreto: hoja + celda, con lo que hay y lo que debería haber."""
    __slots__ = ('hoja', 'celda', 'actual', 'correcto', 'rol', 'nota')

    def __init__(self, hoja, celda, actual=None, correcto=None, rol='', nota=''):
        self.hoja, self.celda, self.actual, self.correcto, self.rol, self.nota = hoja, celda, actual, correcto, rol, nota

    def texto(self):
        return f"{self.hoja}!{self.celda}"


class Observacion:
    factor_global = None               # factor de cierre de la planilla (total / costo directo), si se pudo calcular

    def __init__(self, clave, control, tipo, gravedad, titulo):
        self.id = ''
        self.clave = clave
        self.control = control
        self.tipo = tipo
        self.gravedad = gravedad
        self.titulo = titulo
        self.descripcion = ''
        self.ubicaciones = []
        self.actual = None
        self.correcto = None
        self.fuente = ''
        self.mes = None
        self.impacto_directo = None        # $ (positivo: la planilla sobreestima)
        self.impacto_total = None          # con gastos, beneficio e impuestos
        self.causa = ''
        self.accion = ''
        self.controles = {control}
        self.meses = {}                    # mes -> (actual, correcto, boletín, cuadro, otro): índices y VAR, un registro por mes
        self.bloque = ''
        self.ejemplo = ''
        self._filas = {}                   # (hoja, fila) -> impacto, para no sumar dos veces la misma fila
        self._rows = set()                 # (hoja, fila) que abarca (para juntar observaciones de las mismas filas)
        self.n_otra = None                 # a0_otra: número de la redeterminación cuyo A0/V0 se usa

    @property
    def firma(self):
        return '|'.join(str(x) for x in self.clave)

    @property
    def n(self):
        return len(self.ubicaciones)

    def agregar(self, u):
        if not any(x.hoja == u.hoja and x.celda == u.celda for x in self.ubicaciones):
            self.ubicaciones.append(u)


def nombre_boletin(nombre):
    """'INDEC_Informa_Noviembre_2025_indices_octubre_2025__1_.pdf' -> 'INDEC Informa Noviembre 2025 índices octubre 2025'."""
    t = re.sub(r'\.pdf$', '', nombre or '', flags=re.I).replace('_', ' ')
    t = re.sub(r'\s+', ' ', t).strip()
    t = re.sub(r'\s+\d$', '', t)
    return t.replace(' indices ', ' índices ')


# ----------------------------------------------------------------------
# Reglas
# ----------------------------------------------------------------------
def gravedad_indice(actual, correcto, otro=None):
    """MENOR si la diferencia es chica, o si coincide con lo que trae OTRO boletín para el mismo mes (dato
    provisorio que el INDEC revisó); ERROR en cualquier otro caso."""
    if actual is None or not correcto:
        return 'ERROR'
    if abs(actual - correcto) / abs(correcto) <= UMBRAL_MENOR:
        return 'MENOR'
    if otro and otro[1] and abs(actual - otro[1]) <= 0.0005 * abs(otro[1]):
        return 'MENOR'
    return 'ERROR'


def _pct(actual, correcto):
    if actual is None or not correcto:
        return ''
    return fmt_es((actual / correcto - 1) * 100, 2) + ' %'


def _split(celda):
    hoja, _, c = celda.rpartition('!')
    return hoja, c


def _peor(a, b):
    return a if GRAVEDADES.index(a) <= GRAVEDADES.index(b) else b


ACCIONES = {
    'indice': "Corregir el valor por el publicado por el INDEC en la hoja de origen indicada y verificar que se actualicen las hojas que lo toman.",
    'indice_directo': "Corregir el índice por el publicado por el INDEC.",
    'formula': "Restablecer la fórmula al patrón del resto de la columna y verificar el resultado.",
    'a0_otra': "En cada fila indicada, reemplazar las referencias al A0/V0 de la otra redeterminación por las de esta (celdas escritas encima de su columna de precio) y verificar el precio.",
    'tipeado': "Reemplazar el valor escrito a mano por la fórmula del resto de la columna.",
    'precio': "Verificar la fórmula y el coeficiente aplicado; el precio redeterminado debe ser el precio original por el coeficiente.",
    'coef': "Recalcular el coeficiente como índice de la redeterminación dividido índice base.",
    'costos_precio': "Vincular el precio de la planilla con el costo que resulta del análisis de precios del ítem.",
    'costos_calculo': "Corregir el cálculo indicado (debe resultar de las cantidades y precios de la planilla).",
    'cadena': "El precio de partida de cada redeterminación debe ser el precio actualizado de la anterior.",
    'anticipo': "Verificar el anticipo financiero (A0 = A.F. × V0 / V1) y que el análisis use ese valor.",
    'var': "Corregir el valor de la variación de referencia por el publicado por el INDEC para el mes indicado.",
    'error_celda': "Resolver el error de la celda (#N/A, #REF!, #DIV/0!) para que el precio pueda verificarse.",
    'codigo': "Verificar el código de índice asignado: no figura en el boletín del INDEC.",
    'aviso': "Revisar; no implica un error en sí mismo.",
}

# tipo de hallazgo -> (clave de acción, título)
_TIPOS_AP = {
    'Precio de partida ≠ precio de la redet. anterior': ('cadena', "El precio de partida no es el precio actualizado de la redeterminación anterior"),
    'Precio acumulado (vs. cadena correcta)': ('cadena', "El precio final no coincide con la cadena completa recalculada con los índices correctos"),
    'Anticipo financiero (A0)': ('anticipo', "Anticipo financiero (A0) distinto del que resulta de la hoja AF"),
    'Anticipo financiero (AF)': ('anticipo', "Inconsistencia en la hoja de anticipo financiero (AF)"),
    'Coeficiente': ('coef', "Coeficiente que no resulta de los índices de la fila"),
    'Precio del bloque': ('precio', "Precio redeterminado que no resulta de multiplicar el original por el coeficiente"),
}


# ----------------------------------------------------------------------
# Construcción
# ----------------------------------------------------------------------
class _Constructor:
    def __init__(self):
        self.obs = {}          # clave -> Observacion

    def get(self, clave, control, tipo, gravedad, titulo):
        o = self.obs.get(clave)
        if o is None:
            o = Observacion(clave, control, tipo, gravedad, titulo)
            self.obs[clave] = o
        else:
            o.controles.add(control)
        return o


def construir(resultados):
    """resultados: {'items': [res...], 'var': res, 'ap': res, 'costos': res} tal como los deja cli.analizar.
    Devuelve la lista de observaciones, ordenada y numerada (O-01, O-02...)."""
    C = _Constructor()
    factor = _factor(resultados.get('costos'))
    for res in resultados.get('items') or []:
        _desde_items(C, res)
    if resultados.get('var'):
        _desde_var(C, resultados['var'])
    if resultados.get('ap'):
        _desde_ap(C, resultados['ap'], factor)
    if resultados.get('costos'):
        _desde_costos(C, resultados['costos'], factor)
    _fusionar_filas_copiadas(C)
    lista = list(C.obs.values())
    for o in lista:
        if o.meses:
            _finalizar_meses(o)
        elif o.tipo in ('precio', 'cadena', 'coef', 'a0_otra') and not o.descripcion:
            _finalizar_grupo(o)
        o.impacto_directo = sum(o._filas.values()) if o._filas else o.impacto_directo
        if o.impacto_directo is not None and factor and (o._filas or o.control == 'costos'):
            o.impacto_total = o.impacto_directo * factor
    Observacion.factor_global = factor
    lista.sort(key=lambda o: (GRAVEDADES.index(o.gravedad), -abs(o.impacto_total or o.impacto_directo or 0), -o.n, o.firma))
    for i, o in enumerate(lista, start=1):
        o.id = f"O-{i:02d}"
    return lista


def _factor(costos):
    """Factor de cierre de la planilla de costos (total / costo directo) del último bloque analizado."""
    if not costos:
        return None
    fs = [b.get('factor_cierre') for x in costos['resultados'] for b in x['bloques'] if b.get('factor_cierre')]
    return fs[-1] if fs else None


# ---- Ítems INDEC
def _desde_items(C, res):
    ym = res['ym']
    sin_match = []
    for f in res['filas']:
        hoja, celda = _split(f['celda'])
        if f['cat'] == 'revisar' and f['declarado'] is not None and f['oficial']:
            g = gravedad_indice(f['declarado'], f['oficial'], f.get('otro'))
            o = C.get(('indice', f['codigo']), 'items', 'indice', g, '')
            o.gravedad = _peor(o.gravedad, g)
            o.meses.setdefault(ym, (f['declarado'], f['oficial'], f.get('boletin') or res['boletin'], f.get('cuadro'), f.get('otro')))
            o.agregar(Ubicacion(hoja, celda, f['declarado'], f['oficial'], 'origen', 'tabla de índices de la contratista'))
        elif f['cat'] == 'typo':
            o = C.get(('codigo', f['codigo']), 'items', 'codigo', 'AVISO', f"Código {f['codigo']} no figura en el boletín")
            o.descripcion = f"{f['estado'].replace('SIN MATCH -- ', '')}."
            o.accion = ACCIONES['codigo']
            o.agregar(Ubicacion(hoja, celda, f['codigo'], None))
        elif f['cat'] == 'sin_match':
            sin_match.append((hoja, celda, f['codigo']))
    if sin_match:
        o = C.get(('codigos_sin_boletin', ym), 'items', 'codigo', 'AVISO', f"Códigos que no figuran en el boletín ({mes_txt(ym)})")
        o.descripcion = "El código no se encontró en el Anexo del boletín; puede ser un código propio o estar mal escrito."
        o.accion = ACCIONES['codigo']
        for hoja, celda, cod in sin_match:
            o.agregar(Ubicacion(hoja, celda, cod, None))


def _finalizar_meses(o):
    """Arma título, descripción, fuente y valores de una observación de índice / VAR a partir de sus registros por mes."""
    meses = sorted(o.meses)
    txt_meses = ' y '.join(mes_txt(m) for m in meses)
    if o.tipo == 'indice':
        cod = str(o.clave[1])
        o.titulo = (f"Índice del código {cod}" if cod[:1].isdigit() or cod[:1] == '(' else f"Índice «{cod}»") + \
            f" distinto al publicado por el INDEC ({txt_meses})"
    else:
        o.titulo = f"VAR – {o.clave[1]}: valor distinto al publicado por el INDEC ({txt_meses})"
    partes, fuentes, otros = [], [], []
    for m in meses:
        actual, correcto, boletin, cuadro, otro = o.meses[m]
        partes.append(f"Para {mes_txt(m)} la planilla usa {fmt_es(actual, 1)} y el INDEC publica {fmt_es(correcto, 1)} ({_pct(actual, correcto)}).")
        if boletin:
            fuentes.append(f"{mes_txt(m)}: boletín «{nombre_boletin(boletin)}»" + (f", Cuadro {cuadro}" if cuadro else ''))
        if otro and abs(otro[1] - correcto) > TOL_INDICE:            # solo si el otro boletín dice algo distinto del oficial
            otros.append(f"«{nombre_boletin(otro[0])}» también trae {mes_txt(m)} y dice {fmt_es(otro[1], 1)}")
    ref = getattr(o, 'referencia', '')
    o.descripcion = ' '.join(partes) + (f" Referencia: {ref}." if ref else '')
    if o.gravedad == 'MENOR':
        o.descripcion += " Diferencia menor: puede deberse a un dato provisorio del INDEC que fue revisado; queda a criterio del organismo."
    if otros:
        o.descripcion += ' ' + '; '.join(otros) + '.'
    o.fuente = '; '.join(fuentes) if fuentes else o.fuente
    if len(meses) == 1:
        o.mes, o.actual, o.correcto = meses[0], o.meses[meses[0]][0], o.meses[meses[0]][1]
    o.accion = ACCIONES['indice'] if o.tipo == 'indice' and any(u.rol == 'origen' for u in o.ubicaciones) and o.causa else \
        (ACCIONES['var'] if o.tipo == 'var' else ACCIONES['indice_directo'])


# ---- VAR
def _desde_var(C, res):
    sin_ref = []
    for f in res['filas']:
        hoja, celda = _split(f['celda'])
        if f['cat'] == 'revisar' and f['oficial'] is not None:
            g = gravedad_indice(f['valor_var'], f['oficial'], f.get('otro'))
            o = C.get(('var', f['categoria']), 'var', 'var', g, '')
            o.gravedad = _peor(o.gravedad, g)
            o.referencia = f['referencia']
            o.meses.setdefault(f['ym'], (f['valor_var'], f['oficial'], f.get('boletin'), f.get('cuadro'), f.get('otro')))
            o.agregar(Ubicacion(hoja, celda, f['valor_var'], f['oficial'], 'origen'))
        elif f['cat'] == 'sin_ref':
            sin_ref.append((hoja, celda, f['categoria']))
    if sin_ref:
        o = C.get(('var_sin_ref',), 'var', 'aviso', 'AVISO', "Categorías de la VAR que no se pudieron verificar")
        o.descripcion = "No se encontró un índice del INDEC al cual asociar estas categorías (falta el código o el valor no figura en el boletín)."
        o.accion = ACCIONES['aviso']
        for hoja, celda, cat in sin_ref:
            o.agregar(Ubicacion(hoja, celda, cat, None))


# ---- Análisis de precios (los dos formatos)
def _desde_ap(C, res, factor):
    hallazgos = res['hallazgos']
    # una fórmula apartada explica el precio malo de la misma celda: se junta en una sola observación
    con_formula = {(h['hoja'], h['fila'], h['col']) for h in hallazgos if h['tipo'] in ('Fórmula distinta a la de las filas vecinas', 'Fórmula usa el A0/V0 de otra redeterminación')}
    # "usa el A0/V0 de otra redeterminación" ya es la causa exacta de la fórmula apartada: no se repite como otra observación
    con_a0_otra = {(h['hoja'], h['fila'], h['col']) for h in hallazgos if h['tipo'] == 'Fórmula usa el A0/V0 de otra redeterminación'}
    precio_en = {(h['hoja'], h['fila'], h['col']): h for h in hallazgos if h['tipo'] == 'Precio del bloque'}
    for h in hallazgos:
        t = h['tipo']
        celda = f"{h['col']}{h['fila']}" if h['col'] and h['fila'] != '' else ''
        if t == 'Rótulo del mes':
            _ap_rotulo(C, h, celda)
        elif t in ('Índice base', 'Índice de la redet.'):
            _ap_indice(C, h, celda)
        elif t == 'Fórmula distinta a la de las filas vecinas':
            if (h['hoja'], h['fila'], h['col']) in con_a0_otra:
                continue
            _ap_formula(C, h, celda, hallazgos)
        elif t == 'Fórmula usa el A0/V0 de otra redeterminación':
            _ap_a0_otra(C, h, celda, precio_en.get((h['hoja'], h['fila'], h['col'])))
        elif t in ('Precio del bloque', 'Precio acumulado (vs. cadena correcta)') and (h['hoja'], h['fila'], h['col']) in con_formula:
            continue                                                       # ya está explicado por la fórmula
        elif t == 'Fórmula distinta con resultado correcto':
            o = C.get(('formula_ok', 'ap', h['col']), 'ap', 'formula_ok', 'AVISO', f"Fórmulas distintas a las de las filas vecinas, con resultado correcto (columna {h['col']})")
            o.descripcion = ("La fórmula no es igual a la de las demás filas de la columna (por ejemplo, busca en otra celda), pero el valor que da es el correcto. "
                             "No es un error: se informa solo por si no fuera intencional.")
            o.accion = ACCIONES['aviso']
            o.agregar(Ubicacion(h['hoja'], celda, h.get('formula_actual'), h.get('formula_esperada'), '', 'fórmula actual → patrón de la columna'))
        elif t == 'Valor tipeado donde las demás filas tienen fórmula':
            o = C.get(('tipeado', 'ap'), 'ap', 'tipeado', 'AVISO', "Valores escritos a mano donde el resto de la columna tiene fórmula")
            o.descripcion = "Una celda con un número escrito a mano en una columna de fórmulas puede quedar desactualizada si cambian los datos."
            o.accion = ACCIONES['tipeado']
            o.agregar(Ubicacion(h['hoja'], celda, h['valor_hoja'], h.get('formula_esperada'), '', 'fórmula esperada'))
        elif t == 'Precio con error':
            o = C.get(('error_celda', 'ap'), 'ap', 'error_celda', 'AVISO', "Precios que dan error (#N/A) y no se pudieron verificar")
            o.descripcion = "El precio de estos insumos da error en la planilla, por lo que no se puede controlar el precio redeterminado."
            o.accion = ACCIONES['error_celda']
            o.agregar(Ubicacion(h['hoja'], celda, '#N/A', None, '', h['insumo']))
        elif t in _TIPOS_AP:
            _ap_generico(C, h, celda, factor)
        elif h['nivel'] != 'ERROR':
            o = C.get(('aviso_ap', t), 'ap', 'aviso', 'AVISO', t)
            o.descripcion = h['detalle']
            o.accion = ACCIONES['aviso']
            if h['hoja'] != '(varias)':
                o.agregar(Ubicacion(h['hoja'], celda or '-', None, None))
        else:
            o = C.get(('ap_otro', t, h['hoja'], celda), 'ap', 'aviso', 'ERROR', t)
            o.descripcion = h['detalle']
            o.accion = ACCIONES['aviso']
            o.agregar(Ubicacion(h['hoja'], celda or '-', h['valor_hoja'], h['valor_esperado']))


def _ap_rotulo(C, h, celda):
    """Encabezado de columna con el mes equivocado (los índices son de otro mes): una observación por cambio de mes,
    con todas las hojas. Los índices se controlaron con el mes que corresponde a los valores."""
    mr, mv = tuple(h['m_rotulo']), tuple(h['m_valores'])
    col = 'base' if h['columna'] == 'Índice base' else 'de la redeterminación'
    o = C.get(('rotulo_mes', h['columna'], mr, mv), 'ap', 'rotulo_mes', 'ERROR',
              f"Encabezado del análisis de precios con el mes equivocado: dice {mes_txt(mr)} y los índices son de {mes_txt(mv)}")
    o.fuente = 'Comparación de los índices de la columna con los boletines del INDEC cargados'
    o.causa = ("La hoja parece copiada de la redeterminación anterior sin actualizar el rótulo: los VALORES son los de "
               f"{mes_txt(mv)} pero el encabezado sigue diciendo {mes_txt(mr)}.")
    o.accion = (f"Cambiar el encabezado de la columna del índice {col} a {mes_txt(mv)} en todas las hojas indicadas "
                "(y el título de la redeterminación si también quedó el anterior). No hace falta cambiar los índices: "
                f"el programa ya los controló contra {mes_txt(mv)}.")
    o.agregar(Ubicacion(h['hoja'], celda, h.get('rotulo') or mes_txt(mr), mes_txt(mv), 'origen', f"{h['coinciden'][0]} de {h['coinciden'][1]} índices son de {mes_txt(mv)}"))
    hojas = sorted({u.hoja for u in o.ubicaciones})
    o.descripcion = (f"En {len(hojas)} hoja(s) de análisis la columna del índice {col} dice {mes_txt(mr)}, pero los índices "
                     f"cargados son los de {mes_txt(mv)} (se comprobó código por código contra el boletín). El control de índices, "
                     f"coeficientes y precios se hizo con {mes_txt(mv)}; lo único a corregir acá es el rótulo.")


def _ap_indice(C, h, celda):
    ym = h['m_base'] if h['tipo'] == 'Índice base' else h['m_red']
    if h.get('mes_usado') and isinstance(h['valor_hoja'], float):
        _ap_indice_otro_mes(C, h, celda, ym)
        return
    if not isinstance(h['valor_hoja'], float) or not isinstance(h['valor_esperado'], float):
        o = C.get(('indice_error', h['no'], ym), 'ap', 'error_celda', 'ERROR', f"Índice del código {h['no']} con error ({mes_txt(ym)})")
        o.descripcion, o.accion = h['detalle'], ACCIONES['error_celda']
        o.agregar(Ubicacion(h['hoja'], celda, '#', None))
        return
    g = gravedad_indice(h['valor_hoja'], h['valor_esperado'], h.get('otro'))
    o = C.get(('indice', h['no']), 'ap', 'indice', g, '')
    o.gravedad = _peor(o.gravedad, g)
    o.meses.setdefault(ym, (h['valor_hoja'], h['valor_esperado'], h.get('boletin') or '', h.get('cuadro'), h.get('otro')))
    if not h.get('boletin') and not o.fuente:
        o.fuente = 'Uso del resto de la planilla (el boletín no trae este dato)'
    if h.get('revisado'):
        o.revisados = getattr(o, 'revisados', {})
        o.revisados[ym] = h['revisado']
        o.causa = ' '.join(f"El valor cargado para {mes_txt(m)} es el dato REVISADO que trae «{nombre_boletin(n)}», un boletín posterior."
                           for m, n in sorted(o.revisados.items())) + \
                  " Para la redeterminación vale el índice del boletín publicado para ese mes (el INDEC revisa los últimos meses en cada boletín nuevo)."
        return _ap_indice_ubic(o, h, celda)
    if not getattr(o, 'revisados', None):
        origen = h.get('origen')
        if origen:
            o.causa = f"Valor escrito en la hoja {origen[0]}; las hojas de análisis lo toman por BUSCARV."
    _ap_indice_ubic(o, h, celda)


def _ap_indice_ubic(o, h, celda):
    origen = h.get('origen')
    if origen:
        o.agregar(Ubicacion(origen[0], origen[1], h['valor_hoja'], h['valor_esperado'], 'origen', 'dato escrito en la hoja de origen'))
    o.agregar(Ubicacion(h['hoja'], celda, h['valor_hoja'], h['valor_esperado'], 'propagacion' if origen else ''))
    if h.get('impacto_fila') is not None:
        o._filas[(h['hoja'], h['fila'])] = h['impacto_fila']


def _ap_indice_otro_mes(C, h, celda, m_esp):
    """Índices que son EXACTAMENTE los de otro mes de la tabla (la referencia al mes quedó apuntando a otra columna,
    típico de filas copiadas del bloque anterior): una sola observación por bloque y mes, con todas las filas."""
    mu = tuple(h['mes_usado'])
    o = C.get(('indice_mes', h['hoja'], h['bloque'], h['tipo'], m_esp, mu), 'ap', 'indice_mes', 'ERROR',
              f"Índices de {mes_txt(m_esp)} tomados de {mes_txt(mu)} en el bloque {h['bloque']}")
    o.bloque, o.mes = h['bloque'], m_esp
    o.mes_usado = mu
    o.es_mes_base = h['tipo'] == 'Índice de la redet.' and h.get('m_base') and tuple(h['m_base']) == mu
    o.fuente = f"Hoja de índices de la propia planilla, columna {mes_txt(m_esp)}"
    o.causa = (f"La celda del índice toma el valor de {mes_txt(mu)} en lugar del de {mes_txt(m_esp)}: la referencia al mes "
               "quedó apuntando a otra columna (por ejemplo, filas copiadas del bloque anterior sin actualizar).")
    o.accion = (f"Corregir la referencia al mes en la fórmula de esas celdas para que tomen el índice de {mes_txt(m_esp)}, "
                "igual que el resto de la columna, y verificar el coeficiente y el precio de esas filas.")
    o.agregar(Ubicacion(h['hoja'], celda, h['valor_hoja'], h['valor_esperado'], 'origen', f"{h['no']} {h.get('insumo') or ''}".strip()))
    o._rows.add((h['hoja'], h['fila']))
    if h.get('impacto_fila') is not None:
        o._filas[(h['hoja'], h['fila'])] = h['impacto_fila']
    o.descripcion = (f"En {o.n} fila(s) del bloque {o.bloque} el índice de {mes_txt(m_esp)} es en realidad el de {mes_txt(mu)}"
                     + (" (el mes base del bloque): el coeficiente queda en 1 y el precio no se actualiza." if o.es_mes_base else ".")
                     + f" Códigos: {', '.join(u.nota.split(' ')[0] for u in o.ubicaciones)}.")


def _filas_txt(filas):
    """[10448, 10449, 10450, 10454] -> '10448–10450 y 10454'."""
    filas = sorted(filas)
    tramos, ini = [], None
    for i, f in enumerate(filas):
        if ini is None:
            ini = f
        if i + 1 == len(filas) or filas[i + 1] > f + 1:
            tramos.append(f"{ini}" if ini == f else f"{ini}–{f}")
            ini = None
    return ', '.join(tramos[:-1]) + (' y ' if len(tramos) > 1 else '') + tramos[-1] if tramos else ''


def _fusionar_filas_copiadas(C):
    """Si las filas con el índice de otro mes son las MISMAS que usan el A0/V0 de otra redeterminación, es una sola
    causa (filas copiadas del bloque anterior sin actualizar las referencias): se presentan como UNA observación."""
    a0s = [o for o in C.obs.values() if o.tipo == 'a0_otra']
    for clave, oi in list(C.obs.items()):
        if oi.tipo != 'indice_mes' or not oi._rows:
            continue
        oa = next((o for o in a0s if o.bloque == oi.bloque and oi._rows <= o._rows), None)
        if oa is None:
            continue
        hoja = next(iter(oa._rows))[0]
        filas = _filas_txt({f for _, f in oa._rows})
        n = oa.n_otra
        oa.titulo = (f"Filas del bloque {oa.bloque} copiadas de la redeterminación {n} sin actualizar sus referencias "
                     f"(índice de {mes_txt(oi.mes)} y A0/V0)")
        oa.causa = (f"Las filas {filas} de la hoja {hoja} conservan las fórmulas del bloque de la redeterminación {n}: "
                    f"el índice busca {mes_txt(oi.mes_usado)} en lugar de {mes_txt(oi.mes)}"
                    + (" (por eso el coeficiente da 1)" if oi.es_mes_base else "")
                    + f" y el precio usa el A0/V0 de la redeterminación {n} en lugar del de este bloque.")
        oa.accion = ("En esas filas, copiar las fórmulas de las filas vecinas del mismo bloque (columna del índice de la "
                     "redeterminación y columna del precio actualizado) y verificar que el coeficiente y el precio den lo correcto.")
        oa.fuente = oi.fuente
        for u in oi.ubicaciones:
            u.nota = f"índice {mes_txt(oi.mes)} – {u.nota}"
            oa.agregar(u)
        insumo_de_fila = {re.sub(r'\D', '', u.celda): u.nota.split('– ', 1)[-1] for u in oi.ubicaciones}
        for u in oa.ubicaciones:
            if not u.nota.startswith('índice'):
                u.nota = 'precio actualizado – ' + (u.nota or insumo_de_fila.get(re.sub(r'\D', '', u.celda), ''))
                u.nota = u.nota.rstrip(' –')
        oa.ubicaciones.sort(key=lambda u: (int(re.sub(r'\D', '', u.celda) or 0), u.celda))
        oa._filas.update(oi._filas)
        oa.descripcion = (f"{len(oa._rows)} fila(s) ({filas}) tienen dos errores juntos: el índice de {mes_txt(oi.mes)} es el de "
                          f"{mes_txt(oi.mes_usado)} y el precio se calcula con el A0/V0 de la redeterminación {n}. {oa.ejemplo}")
        del C.obs[clave]


def _ap_formula(C, h, celda, hallazgos):
    o = C.get(('formula', celda), 'ap', 'formula', 'ERROR', f"Fórmula con referencia distinta a la de las filas vecinas en la celda {celda}")
    o.actual, o.correcto = h.get('formula_actual'), h.get('formula_esperada')
    o.causa = "La fórmula de esta celda no sigue el patrón de su columna (referencia corrida)."
    o.accion = ACCIONES['formula']
    o.agregar(Ubicacion(h['hoja'], celda, h.get('formula_actual'), h.get('formula_esperada'), 'origen', 'fórmula actual → fórmula esperada'))
    precio = next((p for p in hallazgos if p['tipo'] == 'Precio del bloque' and (p['hoja'], p['fila'], p['col']) == (h['hoja'], h['fila'], h['col'])), None)
    if precio and precio.get('impacto_fila') is not None:
        o._filas[(h['hoja'], h['fila'])] = precio['impacto_fila']
    o.impacto_directo = o.impacto_directo if o._filas else None
    n = len(o.ubicaciones)
    o.descripcion = (f"En {n} hoja(s) la fórmula de la celda {celda} usa una referencia distinta a la de las demás filas de la columna "
                     f"(ej.: {h.get('formula_actual')} en lugar de {h.get('formula_esperada')}), y el valor resultante es incorrecto.")


def _ap_a0_otra(C, h, celda, precio):
    """Filas cuya fórmula usa el A0/V0 de otra redeterminación: una sola observación por bloque, con todas las filas."""
    o = C.get(('a0_otra', h['bloque'], h.get('n_otra')), 'ap', 'a0_otra', 'ERROR',
              f"Precios del bloque {h['bloque']} calculados con el A0/V0 de la redeterminación {h.get('n_otra')}")
    o.bloque = h['bloque']
    o.n_otra = h.get('n_otra')
    o._rows.add((h['hoja'], h['fila']))
    o.causa = f"La fórmula del precio apunta a las celdas de A0/V0 de la redeterminación {h.get('n_otra')} en lugar de las de este bloque."
    o.accion = ACCIONES['a0_otra']
    o.ejemplo = f"Ej.: {celda} tiene {h.get('formula_actual')} y debería tener {h.get('formula_esperada')}."
    if precio is not None:
        o.agregar(Ubicacion(h['hoja'], celda, precio['valor_hoja'], precio['valor_esperado'], 'origen', h['insumo']))
    else:
        o.agregar(Ubicacion(h['hoja'], celda, h.get('formula_actual'), h.get('formula_esperada'), 'origen', h['insumo']))


def _ap_generico(C, h, celda, factor):
    """Precios / cadena / coeficiente / anticipo: se agrupan por causa (mismo tipo, bloque y causa), no por celda."""
    accion, titulo = _TIPOS_AP[h['tipo']]
    grupal = accion in ('precio', 'cadena', 'coef')
    por_insumo = h['tipo'].startswith('Precio de partida')          # el mismo insumo cortado en varias redeterminaciones = una causa
    clave = ((accion, h['tipo'], h['no']) if por_insumo else (accion, h['tipo'], h['bloque'], h.get('causa') or '')) if grupal else (accion, h['tipo'], h['hoja'], celda)
    o = C.get(clave, 'ap', accion, 'ERROR' if h['nivel'] == 'ERROR' else 'AVISO',
              titulo + (f": {h['no']} {h.get('insumo', '')}".rstrip() if por_insumo else (f" ({h['bloque']})" if grupal and h['bloque'] else '')))
    o.bloque = '' if por_insumo else h['bloque']
    o.accion = ACCIONES[accion]
    if not o.ejemplo:
        o.ejemplo = h['detalle'] + (f" [{h['causa']}]" if h.get('causa') else '')
    if h.get('causa') and not o.causa:
        o.causa = h['causa'][:1].upper() + h['causa'][1:] + '.'
    if h.get('impacto_fila') is not None:
        o._filas[(h['hoja'], h['fila'])] = h['impacto_fila']
    if not grupal:
        o.actual, o.correcto = h['valor_hoja'], h['valor_esperado']
        o.descripcion = h['detalle'] + (f" [{h['causa']}]" if h.get('causa') else '')
        if h['valor_hoja'] is not None and h['valor_esperado'] is not None:
            o.descripcion = f"La planilla dice {fmt_es(h['valor_hoja'])} y debería ser {fmt_es(h['valor_esperado'])} ({_pct(h['valor_hoja'], h['valor_esperado'])}). " + o.descripcion
    o.agregar(Ubicacion(h['hoja'], celda or '-', h['valor_hoja'], h['valor_esperado'], 'propagacion' if 'consecuencia' in (h.get('causa') or '') else '',
                        (f"{h['bloque']}: " if por_insumo else '') + h.get('insumo', '')))


def _finalizar_grupo(o):
    """Descripción de una observación que agrupa muchas celdas: cuántas, rango de diferencia y un ejemplo."""
    pares = [(u.actual, u.correcto) for u in o.ubicaciones if isinstance(u.actual, (int, float)) and isinstance(u.correcto, (int, float)) and u.correcto]
    partes = [f"{o.n} celda(s) de la columna de precio" + (f" del bloque {o.bloque}" if o.bloque else '') + " no coinciden con el valor que corresponde."]
    if pares:
        difs = [a / c - 1 for a, c in pares]
        partes.append(f"La diferencia es de {fmt_es(min(difs) * 100, 3)} %." if abs(max(difs) - min(difs)) < 1e-6 else
                      f"La diferencia va de {fmt_es(min(difs) * 100, 3)} % a {fmt_es(max(difs) * 100, 3)} %.")
    if o.ejemplo:
        partes.append(o.ejemplo)
    o.descripcion = ' '.join(partes)


# ---- Planilla de costos
_TIPOS_COSTOS = {
    'Precio distinto al del análisis': ('costos_precio', "Precio unitario de la planilla distinto al que resulta del análisis de precios"),
    'Ítem sin precio en la planilla': ('costos_precio', "Ítem sin precio en la planilla (el análisis sí lo tiene)"),
    'Parcial ≠ cantidad × precio unitario': ('costos_calculo', "Parcial que no resulta de cantidad × precio unitario"),
    'Subtotal de rubro ≠ suma de sus ítems': ('costos_calculo', "Subtotal de rubro que no suma sus ítems"),
    'Total de costo ≠ suma de los rubros': ('costos_calculo', "Total de costo que no suma los rubros"),
    'Adicional ≠ porcentaje × base': ('costos_calculo', "Gastos, beneficio o impuestos que no resultan del porcentaje sobre su base"),
    'Subtotal / total ≠ suma acumulada': ('costos_calculo', "Subtotal o total final que no suma lo anterior"),
}


def _desde_costos(C, res, factor):
    for h in res['hallazgos']:
        t = h['tipo']
        celda = f"{h['col']}{h['fila']}" if h['col'] and h['fila'] != '' else ''
        etiqueta = f"{h['hoja'].strip()}" if h['hoja'] else ''
        que = f"ítem {h['item']} {h['desc'][:40]}".strip() if h['item'] else (h['desc'][:50] if h['desc'] else '')
        if t in _TIPOS_COSTOS and h['nivel'] == 'ERROR':
            accion, titulo = _TIPOS_COSTOS[t]
            o = C.get((accion, t, h['bloque'], etiqueta, celda), 'costos', accion, 'ERROR', f"{titulo} – {que} ({h['bloque']})")
            o.actual, o.correcto = h['valor_hoja'], h['valor_esperado']
            o.accion = ACCIONES[accion]
            txt = ''
            if h['valor_hoja'] is not None and h['valor_esperado'] is not None:
                txt = f"La planilla dice {fmt_es(h['valor_hoja'])} y debería ser {fmt_es(h['valor_esperado'])} ({_pct(h['valor_hoja'], h['valor_esperado'])}). "
            o.descripcion = txt + (h['detalle'] or '')
            if h.get('celda_analisis'):
                o.fuente = f"Análisis de precios: {h['celda_analisis']}"
            if h.get('impacto') is not None:
                o.impacto_directo = h['impacto']
            o.agregar(Ubicacion(etiqueta, celda, h['valor_hoja'], h['valor_esperado'], 'origen'))
        elif t == 'Fórmula distinta con resultado correcto':
            o = C.get(('formula_ok', 'costos', h['col']), 'costos', 'formula_ok', 'AVISO', f"Fórmulas distintas a las de las filas vecinas, con resultado correcto (columna {h['col']})")
            o.descripcion = "La fórmula no es igual a la de las demás filas de la columna, pero no se encontró diferencia en el valor. No es un error: se informa solo por si no fuera intencional."
            o.accion = ACCIONES['aviso']
            o.agregar(Ubicacion(etiqueta, celda, h.get('formula_actual'), h.get('formula_esperada'), '', 'fórmula actual → patrón de la columna'))
        elif t == 'Valor tipeado donde las demás filas tienen fórmula':
            o = C.get(('tipeado', 'costos'), 'costos', 'tipeado', 'AVISO', "Valores escritos a mano donde el resto de la columna tiene fórmula")
            o.descripcion, o.accion = "Una celda con un número escrito a mano en una columna de fórmulas puede quedar desactualizada.", ACCIONES['tipeado']
            o.agregar(Ubicacion(etiqueta, celda, h['valor_hoja'], h.get('formula_esperada'), '', 'fórmula esperada'))
        elif h['nivel'] != 'ERROR':
            o = C.get(('aviso_costos', t), 'costos', 'aviso', 'AVISO', t)
            o.descripcion = h['detalle'] if len(o.ubicaciones) == 0 else o.descripcion
            o.accion = ACCIONES['aviso']
            o.agregar(Ubicacion(etiqueta, celda or '-', h['valor_hoja'], h['valor_esperado'], '', que))
        else:
            o = C.get(('costos_otro', t, celda), 'costos', 'aviso', 'ERROR', t)
            o.descripcion, o.accion = h['detalle'], ACCIONES['aviso']
            o.agregar(Ubicacion(etiqueta, celda or '-', h['valor_hoja'], h['valor_esperado']))


# ----------------------------------------------------------------------
# Resúmenes
# ----------------------------------------------------------------------
def contar(obs):
    """{gravedad: cantidad de observaciones}"""
    return {g: sum(1 for o in obs if o.gravedad == g) for g in GRAVEDADES}


def impacto_total(obs, gravedad='ERROR'):
    """(directo, total) de las observaciones de esa gravedad: suma de diferencias en VALOR ABSOLUTO, contando una vez
    cada fila aunque la compartan dos observaciones (ej. el índice base y el de la redet. de un mismo insumo)."""
    filas, sueltos = {}, 0.0
    for o in obs:
        if o.gravedad != gravedad:
            continue
        if o._filas:
            filas.update(o._filas)
        elif o.impacto_directo is not None:
            sueltos += abs(o.impacto_directo)
    d = sum(abs(v) for v in filas.values()) + sueltos
    f = Observacion.factor_global
    return d, (d * f if f and d else None)


def cobertura(resultados):
    """Frases con lo que se verificó (para que un 'sin observaciones' diga qué tan completo fue el control)."""
    out = []
    for res in resultados.get('items') or []:
        out.append(f"Ítems INDEC {mes_txt(res['ym'])}: {res['n_codigos']} códigos de índice comparados con el boletín «{nombre_boletin(res['boletin'])}».")
    if resultados.get('var'):
        v = resultados['var']
        meses = ', '.join(mes_txt(m) for m, _ in v['meses'])
        out.append(f"VAR ({meses}): {len(v['filas'])} valores comparados; {v['cuenta']['ok']} coinciden.")
    if resultados.get('ap'):
        a = resultados['ap']
        ins = sum(x['insumos'] for x in a['resumen_agr'])
        out.append(f"Análisis de precios: {ins} insumos revisados (índices, coeficiente y precio redeterminado)"
                   + (f" en {len(a['hojas'])} hoja(s)." if a.get('hojas') else '.'))
    if resultados.get('costos'):
        c = resultados['costos']
        items = sum(len(x['pl'].items) for x in c['resultados'])
        bl = sum(len(x['bloques']) for x in c['resultados'])
        out.append(f"Planilla de costos: {items} ítems, {bl} bloque(s) (base y redeterminaciones): precios contra el análisis y cálculos de la planilla.")
    return out

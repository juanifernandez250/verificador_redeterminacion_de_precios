# -*- coding: utf-8 -*-
"""
cruce_anterior.py  --  CONTROL 5: precios de la redeterminación anterior
------------------------------------------------------------------------
En el archivo de la Rn, la planilla de costos trae primero la columna de la R(n-1) (los precios de los que parte) y
después la de la Rn. Esos precios de la R(n-1) tienen que ser LOS MISMOS que los del archivo de la R(n-1) que ya se
presentó (y se aprobó). Este control los compara ítem por ítem (precio unitario) y el precio total de la obra, y
devuelve cada diferencia con su hoja, celda e ítem, para que se vea DÓNDE está.

Solo se compara la planilla de costos (donde está el total de la obra). Cada diferencia mayor a 1 centavo es un ERROR.
"""
from openpyxl.utils import get_column_letter as L

TOL = 0.01          # 1 centavo


def _bloque(pl, n):
    """El bloque (columna de precios) de la redeterminación n en esa planilla, o None."""
    for b in pl.bloques:
        if b.n_redet is not None and int(b.n_redet) == int(n):
            return b
    return None


def _total(pl, n):
    try:
        from interfaz.faltante import montos_de_planillas
        return montos_de_planillas([pl]).get(int(n))
    except Exception:
        return None


def comparar(pls_act, pls_ant, n_ant, archivo_ant):
    """pls_act: planillas de costos del archivo que se analiza; pls_ant: las del archivo de la R(n_ant).
    Devuelve {'n_ant', 'archivo', 'hoja', 'col_act', 'col_ant', 'items', 'ok', 'hallazgos', 'faltan', 'sobran',
    'total_act', 'total_ant'} o {'error': motivo}."""
    res = {'n_ant': n_ant, 'archivo': archivo_ant, 'hallazgos': [], 'faltan': [], 'sobran': [], 'items': 0, 'ok': 0}
    if not pls_act:
        return dict(res, error='no se encontró la planilla de costos en este archivo')
    if not pls_ant:
        return dict(res, error=f'no se encontró la planilla de costos en el archivo de la R{n_ant}')
    pl, pa = pls_act[0], pls_ant[0]
    b = _bloque(pl, n_ant)
    if b is None:
        return dict(res, error=f'la planilla de costos de este archivo no tiene una columna de la R{n_ant}')
    ba = _bloque(pa, n_ant) or (pa.bloques[-1] if pa.bloques else None)      # su propia redeterminación (la última)
    if ba is None:
        return dict(res, error=f'no se encontraron los precios en la planilla de costos del archivo de la R{n_ant}')
    g, ga = pl.grilla, pa.grilla
    res.update(hoja=pl.hoja, col_act=L(b.p), col_ant=L(ba.p), hoja_ant=pa.hoja)
    ant = pa.por_id()
    vistos = set()
    for x in pl.items:
        y = ant.get(x['id'])
        va = g.n(x['r'], b.p)
        if y is None:
            if va is not None:
                res['sobran'].append({'fila': x['r'], 'col': L(b.p), 'item': x['id'], 'desc': x['desc'], 'actual': va})
            continue
        vistos.add(x['id'])
        vb = ga.n(y['r'], ba.p)
        if va is None and vb is None:
            continue
        res['items'] += 1
        if va is not None and vb is not None and abs(va - vb) <= TOL:
            res['ok'] += 1
            continue
        cant = x.get('cant') if isinstance(x.get('cant'), (int, float)) else None
        res['hallazgos'].append({'fila': x['r'], 'col': L(b.p), 'item': x['id'], 'desc': x['desc'], 'actual': va, 'anterior': vb,
                                 'celda_ant': f"{pa.hoja}!{L(ba.p)}{y['r']}",
                                 'dif_parcial': ((va or 0) - (vb or 0)) * cant if cant is not None else None})
    for i, y in ant.items():
        if i not in vistos:
            vb = ga.n(y['r'], ba.p)
            if vb is not None and not any(s['item'] == i for s in res['sobran']):
                res['faltan'].append({'item': i, 'desc': y['desc'], 'anterior': vb, 'celda_ant': f"{pa.hoja}!{L(ba.p)}{y['r']}"})
    res['total_act'], res['total_ant'] = _total(pl, n_ant), _total(pa, n_ant if _bloque(pa, n_ant) else ba.n_redet)
    res['donde'] = _donde_difiere(pl, b, pa, ba, ant, res) if _difiere_total(res) else []
    return res


def _difiere_total(res):
    t1, t2 = res.get('total_act'), res.get('total_ant')
    return bool(t1 and t2 and abs(t1 - t2) > TOL)


def _distinto(a, b, rel=1e-9):
    if a is None and b is None:
        return False
    if a is None or b is None:
        return True
    return abs(a - b) > max(TOL, rel * abs(b))


def _donde_difiere(pl, b, pa, ba, ant, res):
    """Cuando el precio total de la R(n-1) no coincide, DÓNDE se separan las dos planillas, buscando la causa en este
    orden: 1) cantidades distintas; 2) parciales distintos (con igual precio y cantidad); 3) subtotales de rubro;
    4) filas del cierre (total de costo, gastos generales, beneficio, impuestos, subtotales, total) y sus porcentajes.
    Se devuelve el primer nivel donde aparece alguna diferencia (la causa), no sus consecuencias."""
    from . import costos as cs
    g, ga = pl.grilla, pa.grilla
    con_precio_distinto = {h['item'] for h in res['hallazgos']}
    celda_a = lambda c, r: f"{pa.hoja}!{L(c)}{r}"
    # 1) cantidades
    out = []
    for x in pl.items:
        y = ant.get(x['id'])
        if y is None:
            continue
        if _distinto(x.get('cant'), y.get('cant'), 1e-7):
            out.append({'nivel': 'cantidad', 'fila': x['r'], 'col': L(pl.qc) if pl.qc else '?', 'que': f"ítem {x['id']} {x['desc'][:40]} · cantidad",
                        'actual': x.get('cant'), 'anterior': y.get('cant'), 'celda_ant': celda_a(pa.qc, y['r']) if pa.qc else ''})
    if out:
        return out
    # 2) parciales (cantidad × precio) con el mismo precio unitario y la misma cantidad
    for x in pl.items:
        y = ant.get(x['id'])
        if y is None or x['id'] in con_precio_distinto:
            continue
        va, vb = g.n(x['r'], b.t), ga.n(y['r'], ba.t)
        if _distinto(va, vb):
            out.append({'nivel': 'parcial', 'fila': x['r'], 'col': L(b.t), 'que': f"ítem {x['id']} {x['desc'][:40]} · parcial (cantidad × precio)",
                        'actual': va, 'anterior': vb, 'celda_ant': celda_a(ba.t, y['r'])})
    if out or con_precio_distinto:
        return out
    # 3) y 4): el control de cálculo de la planilla aprende la columna de montos y arma el cierre
    try:
        ra, rb = cs.controlar_aritmetica(pl, b, []), cs.controlar_aritmetica(pa, ba, [])
    except Exception:
        return out
    ca_, cb_ = getattr(b, 'col_amount', b.t), getattr(ba, 'col_amount', ba.t)
    padres_ant = {p['id']: p for p in pa.padres}
    for p in pl.padres:
        q = padres_ant.get(p['id'])
        if q is None or not p.get('hijos'):
            continue
        va, vb = g.n(p['r'], ca_), ga.n(q['r'], cb_)
        if va is not None and vb is not None and _distinto(va, vb):
            out.append({'nivel': 'rubro', 'fila': p['r'], 'col': L(ca_), 'que': f"subtotal del rubro {p['id']} {p['desc'][:40]}",
                        'actual': va, 'anterior': vb, 'celda_ant': celda_a(cb_, q['r'])})
    if out:
        return out
    cierre_a, cierre_b = ra.get('cierre') or [], rb.get('cierre') or []
    norm = lambda t: ' '.join(str(t).lower().split())
    usadas = set()
    for (r, lab, m, pct) in cierre_a:
        j = next((j for j, z in enumerate(cierre_b) if j not in usadas and norm(z[1]) == norm(lab)), None)
        if j is None:
            continue
        usadas.add(j)
        r2, lab2, m2, pct2 = cierre_b[j]
        p1 = pct[-1] if isinstance(pct, tuple) else pct
        p2 = pct2[-1] if isinstance(pct2, tuple) else pct2
        if p1 is not None and p2 is not None and abs(p1 - p2) > 1e-9:
            def col_pct(gr, rr, bl, valor):          # la celda donde está escrito el porcentaje (si está en una celda)
                for c in range(bl.p, bl.c_fin + 1):
                    x = gr.n(rr, c)
                    if x is not None and abs(x - valor) < 1e-12:
                        return c
                return None
            c1, c2 = col_pct(g, r, b, p1), col_pct(ga, r2, ba, p2)
            out.append({'nivel': 'porcentaje', 'fila': r, 'col': L(c1 or ca_), 'que': f"{lab.upper()} · porcentaje",
                        'actual': p1, 'anterior': p2, 'pct': True, 'celda_ant': celda_a(c2 or cb_, r2)})
            break
        if _distinto(m, m2):
            out.append({'nivel': 'cierre', 'fila': r, 'col': L(ca_), 'que': lab.upper(), 'actual': m, 'anterior': m2,
                        'celda_ant': celda_a(cb_, r2)})
            break                                        # la primera fila del cierre donde se separan es la causa
    return out


def hay_diferencias(res):
    if res.get('error'):
        return False
    t1, t2 = res.get('total_act'), res.get('total_ant')
    return bool(res['hallazgos'] or res['faltan'] or res['sobran'] or (t1 and t2 and abs(t1 - t2) > TOL)
                or ((res.get('analisis') or {}).get('distintos')))


# ----------------------------------------------------------------------
# El PORQUÉ de cada diferencia: el análisis de precios del ítem en los dos archivos
# ----------------------------------------------------------------------
import re as _re

_RE_HOJA_ITEM = _re.compile(r'item\s*(\d+(?:[\-.]\d+)*)', _re.I)
_RE_SECCION = _re.compile(r'(equipo|material|mano de obra|transporte|amortiz|reparaci|combustible|lubricant|costo|gastos|beneficio|impuesto)', _re.I)


def _hoja_del_item(ctx, item):
    """La hoja de análisis de ese ítem en el formato «una hoja por ítem» (ej. 'PLANILLA N° 6 item 9-3-1' para el 9.3.1)."""
    from .excel import hojas_de_datos
    clave = str(item).strip().rstrip('.')
    for n in hojas_de_datos(ctx.wb):
        m = _RE_HOJA_ITEM.search(n)
        if m and m.group(1).replace('-', '.').rstrip('.') == clave:
            return n
    return None


def _txt(v):
    return _re.sub(r'\s+', ' ', str(v)).strip() if isinstance(v, str) and len(str(v).strip()) >= 2 else ''


def _desc_fila(g, r, c1, c2):
    for c in range(c1, c2):
        t = _txt(g.v(r, c))
        if t and not _re.fullmatch(r'[\d.,\s%-]+', t):
            return t
    return ''


def _seccion_de(g, r, c1, c2):
    for rr in range(r - 1, max(0, r - 120), -1):
        t = _txt(g.v(rr, c1)) or _txt(g.v(rr, c1 + 1))
        if t and _re.match(r'^\s*\d\s*[.)-]?\s*\D', t) and _RE_SECCION.search(t):
            return t[:45]
    return ''


def _titulo_col(g, r, c):
    for rr in range(r - 1, max(0, r - 25), -1):
        t = _txt(g.v(rr, c))
        if t and len(t) <= 22 and not _re.fullmatch(r'[\d.,\s%-]+', t):
            return t
    return ''


def detalle_analisis(ctx_act, ctx_ant, item, max_filas=60):
    """Qué renglones del análisis de precios del ítem cambiaron entre este archivo (lado izquierdo: los precios de la
    redeterminación anterior) y el archivo de la redeterminación anterior (lado derecho: sus precios redeterminados).
    -> {'hoja_act', 'hoja_ant', 'filas': [{'fila', 'fila_ant', 'seccion', 'desc', 'cambios': [{'titulo', 'celda_act',
    'actual', 'celda_ant', 'anterior'}]}]} o None si no se pudo (otro formato, hoja no encontrada)."""
    from . import analisis_items as ai
    h_act, h_ant = _hoja_del_item(ctx_act, item), _hoja_del_item(ctx_ant, item)
    if not h_act or not h_ant:
        return None
    ga, gb = ctx_act.grilla(h_act), ctx_ant.grilla(h_ant)
    ba, bb = ai.detectar_en_hoja(ga), ai.detectar_en_hoja(gb)
    if not ba or not bb or not bb[0].offset:
        return None
    c_fin = ba[0].c_code                     # columnas del análisis (izquierda): de la B hasta antes del CÓDIGO
    off = bb[0].offset                        # en el archivo anterior, su copia redeterminada está a la derecha
    filas = []
    desde = min(x.fila_hdr for x in ba) + 1        # solo la zona de insumos (no el encabezado: ítem, subítem, títulos)
    for r in range(desde, min(ga.nrows, gb.nrows) + 1):
        d = _desc_fila(ga, r, 2, c_fin)
        if _re.match(r'^(descripci[oó]n|item|ítem|subitem|subítem|unidad|cantidad|rubro|n[º°o]\b|c[oó]digo)', d.lower()):
            continue                           # fila de títulos de columna (trae números de ítem, no precios)
        r2 = r
        if d:                                  # la copia de la derecha del archivo anterior puede estar corrida una fila
            for dv in (0, -1, 1, -2, 2):
                if 1 <= r + dv <= gb.nrows and _desc_fila(gb, r + dv, 2 + off, c_fin + off) == d:
                    r2 = r + dv
                    break
        cambios = []
        for c in range(2, c_fin):
            va, vb = ga.n(r, c), gb.n(r2, c + off)
            if va is None or vb is None:
                continue
            if abs(va - vb) > max(0.01, 1e-6 * abs(vb)):
                cambios.append({'titulo': _titulo_col(ga, r, c), 'celda_act': f"{L(c)}{r}", 'actual': va,
                                'celda_ant': f"{L(c + off)}{r2}", 'anterior': vb})
        if cambios:
            filas.append({'fila': r, 'fila_ant': r2, 'seccion': _seccion_de(ga, r, 2, c_fin), 'desc': d, 'cambios': cambios})
    return {'hoja_act': h_act, 'hoja_ant': h_ant, 'filas': filas[:max_filas], 'mas': max(0, len(filas) - max_filas)}


def comparar_analisis(ctx_act, ctx_ant, items):
    """Compara el análisis de precios de TODOS los ítems (no solo los que difieren en la planilla): el lado izquierdo de
    este archivo (precios de la redeterminación anterior) contra el lado derecho del archivo de la redeterminación
    anterior (sus precios redeterminados). Una diferencia dentro de un análisis puede compensarse y no verse en la
    planilla, por eso se mira cada uno. Solo para el formato «una hoja por ítem».
    -> {'comparados', 'sin_hoja', 'distintos': [{'item', 'desc', 'hoja_act', 'hoja_ant', 'filas', 'mas'}]}"""
    out = {'comparados': 0, 'sin_hoja': 0, 'distintos': []}
    for x in items:
        try:
            d = detalle_analisis(ctx_act, ctx_ant, x['id'])
        except Exception:
            d = None
        if d is None:
            out['sin_hoja'] += 1
            continue
        out['comparados'] += 1
        if d['filas']:
            out['distintos'].append({'item': x['id'], 'desc': x['desc'], **d})
    return out

# -*- coding: utf-8 -*-
"""
analisis_items.py  --  CONTROL 3 (variante): análisis de precios por hoja de ítem
-----------------------------------------------------------------------------------
Algunas contratistas arman el análisis con UNA HOJA POR ÍTEM, con el análisis original a la izquierda y la
redeterminación a la derecha, y los índices de cada insumo identificados por su CODIGO CPC:

     ... | CODIGO CPC | DESCRIPCION | BASE OCT 25 | REDET ENE 26 | COEF |     (copia a la derecha: mismos rótulos)
     ... | 53111-1    | Casilla ... |  10.043,6   |  10.756,9    | 1,071|

No hay hoja INDEC con columna Nº: la fuente de verdad es el boletín del INDEC (por código y mes).
Por cada insumo con código se controla:
  1) Índice base y de la redeterminación = el que dice el boletín para ese código y mes (si el boletín
     no lo trae, se compara con lo que usa el resto de la planilla para ese mismo código y mes).
  2) Coeficiente = índice de la redeterminación / índice base.
  3) Precio redeterminado (a la derecha) = precio original (a la izquierda) x coeficiente. Las columnas que
     no son plata (cantidades, HP, horas) deben quedar iguales.
El resultado tiene el mismo formato que el del análisis clásico, así que el reporte es el mismo.
"""
import re
from collections import Counter

from .analisis_precios import _hallazgo, agrupar_resumen
from .comunes import (TOL_INDICE, TOL_PRECIO_ABS, TOL_PRECIO_REL, ErrorVerificacion, es_error, fecha, mes_txt,
                      strip_accents, texto)
from .excel import hojas_de_datos
from .items_indec import es_codigo_valido
from .pdf_indec import boletin_para_mes
from .seleccion import bloque_seleccionado, texto_bloques
from openpyxl.utils import column_index_from_string as CI

_MES = r'(ene|feb|mar|abr|may|jun|jul|ago|sep|set|oct|nov|dic)[a-z]*\.?[\s\-/.]*(\d{2,4})'
_RE_BASE = re.compile(r'\bbase\b\W*' + _MES)
_RE_REDET = re.compile(r'\bredet\w*\W*' + _MES)
_ORDINALES = {'primera': 1, 'segunda': 2, 'tercera': 3, 'cuarta': 4, 'quinta': 5, 'sexta': 6, 'septima': 7,
              'octava': 8, 'novena': 9, 'decima': 10}
_RE_PLATA = re.compile(r'precio|costo|total|importe|monto|\$|p\.?\s?u\b')
_RE_N_REDET = re.compile(r'(primera|segunda|tercera|cuarta|quinta|sexta|septima|octava|novena|decima|\d+\s*[º°o]?)\s*redetermin')


DESC = 'desc:'                 # prefijo de las filas sin código, identificadas por su descripción oficial
_RE_SIN_CODIGO = re.compile(r'^mano de obra( asalariada| directa| indirecta)?\b')


def etiqueta_codigo(code):
    return code[len(DESC):] if code.startswith(DESC) else code


class BloqueItem:
    """Una tabla de insumos con código de una hoja de ítem (equipos, materiales, mano de obra...)."""

    def __init__(self, hoja, fila_hdr, c_code, c_base, c_red, c_coef, m_base, m_red):
        self.hoja, self.fila_hdr = hoja, fila_hdr
        self.c_code, self.c_base, self.c_red, self.c_coef = c_code, c_base, c_red, c_coef
        self.m_base, self.m_red = m_base, m_red
        self.fila_fin = None
        self.plata = set()            # columnas (izquierda) cuyo encabezado es plata: precio, costo, total, $/día...
        self.offset = None            # columnas de distancia entre el análisis original (izquierda) y el redeterminado (derecha)
        self.n_redet = None
        self.seleccionado = True
        self.filas = []

    @property
    def col_ini(self):
        return self.c_code

    @property
    def c_precio(self):
        return self.c_coef

    @property
    def etiqueta(self):
        return f"R{self.n_redet}" if self.n_redet else f"{mes_txt(self.m_base)}→{mes_txt(self.m_red)}"


def _mes_de(regex, txt):
    m = regex.search(strip_accents(txt.lower()))
    return fecha(f"{m.group(1)}-{m.group(2)}") if m else None


def _es_titulo_codigo(t):
    t = strip_accents(t.lower())
    return len(t) <= 25 and (t.startswith('codigo') or 'cpc' in t)


def _offset(g, r, c_code, c_coef):
    """Distancia entre las dos copias: la más frecuente entre rótulos iguales del encabezado (izquierda vs. derecha)."""
    fila = {c: strip_accents(str(g.v(r, c)).strip().lower()) for c in range(1, g.ncols + 1)
            if isinstance(g.v(r, c), str) and len(str(g.v(r, c)).strip()) >= 2}
    votos = Counter()
    for c1 in range(1, c_code):
        if c1 not in fila:
            continue
        for c2 in range(c_coef + 1, g.ncols + 1):
            if fila.get(c2) == fila[c1]:
                votos[c2 - c1] += 1
    return votos.most_common(1)[0][0] if votos else None


def _n_redet(g):
    for r in range(1, min(g.nrows, 20) + 1):
        for c in range(1, g.ncols + 1):
            v = g.v(r, c)
            if isinstance(v, str):
                m = _RE_N_REDET.search(strip_accents(v.lower()))
                if m:
                    k = m.group(1)
                    return _ORDINALES.get(k) or int(re.match(r'\d+', k).group())
    return None


def detectar_en_hoja(g):
    """Bloques de una hoja (Grilla). Un encabezado tiene: CODIGO..., BASE <mes> <año>, REDET <mes> <año> y COEF."""
    bloques = []
    for r in range(1, g.nrows + 1):
        fila = g.filas[r - 1]
        c_code = c_base = c_red = c_coef = None
        m_base = m_red = None
        redets = []                   # columnas «REDET <mes>» antes del COEF (en una R2, R3… la base también dice REDET)
        for c, v in enumerate(fila, start=1):
            if not isinstance(v, str) or not v.strip():
                continue
            if c_code is None and _es_titulo_codigo(v):
                c_code = c
            elif c_base is None and _mes_de(_RE_BASE, v):
                c_base, m_base = c, _mes_de(_RE_BASE, v)
            elif c_coef is None and _mes_de(_RE_REDET, v):
                redets.append((c, _mes_de(_RE_REDET, v)))
            elif c_coef is None and strip_accents(v.strip().lower()).startswith('coef'):
                c_coef = c
        if c_base is not None and redets:
            c_red, m_red = redets[0]
        elif c_base is None and len(redets) >= 2:
            # «REDET MAYO 26 | REDET AGO 26 | COEF»: la primera es la de la redeterminación anterior (la base de esta)
            (c_base, m_base), (c_red, m_red) = redets[-2], redets[-1]
            if m_base and m_red and m_base > m_red:
                (c_base, m_base), (c_red, m_red) = (c_red, m_red), (c_base, m_base)
        if None in (c_code, c_base, c_red, c_coef):
            continue
        b = BloqueItem(g.nombre, r, c_code, c_base, c_red, c_coef, m_base, m_red)
        b.offset = _offset(g, r, c_code, c_coef)
        b.plata = {c for c in range(2, c_code) if isinstance(g.v(r, c), str) and _RE_PLATA.search(strip_accents(g.v(r, c).lower()))}
        bloques.append(b)
    for b, sig in zip(bloques, bloques[1:] + [None]):
        b.fila_fin = (sig.fila_hdr - 1) if sig else g.nrows
    if bloques:
        n = _n_redet(g)
        for b in bloques:
            b.n_redet = n
    return bloques


def detectar(ctx):
    """{hoja: [BloqueItem]} de las hojas visibles (fuera de INDEC / AF)."""
    out = {}
    for n in hojas_de_datos(ctx.wb):
        if n in ctx.excluir or n in ctx.ocultas:
            continue
        try:
            bl = detectar_en_hoja(ctx.grilla(n))
        except Exception as e:
            ctx.avisos.append(f"No pude leer la hoja '{n}': {type(e).__name__}: {e}")
            continue
        if bl:
            out[n] = bl
    return out


# ----------------------------------------------------------------------
# Lectura de filas y control
# ----------------------------------------------------------------------
def _norm_desc(v):
    return re.sub(r'\s+', ' ', strip_accents(str(v).lower())).strip() if isinstance(v, str) and len(str(v).strip()) >= 3 else None


def _col_descripcion(g, b):
    """La columna de la izquierda con más textos (la descripción de los insumos), o None."""
    cuenta = {c: sum(1 for r in range(b.fila_hdr + 1, b.fila_fin + 1) if _norm_desc(g.v(r, c))) for c in range(2, b.c_code)}
    c = max(cuenta, key=cuenta.get) if cuenta else None
    return c if c and cuenta[c] >= 2 else None


def _corrimiento_fila(g, b, r, c_desc):
    """Filas de diferencia entre un insumo del análisis original (izquierda) y el mismo insumo en la copia
    redeterminada (derecha). Normalmente 0; algunas planillas tienen la copia corrida una o dos filas. Se decide por la
    descripción: si en la misma fila no coincide y una o dos filas más arriba/abajo sí, se usa esa."""
    if not c_desc or not b.offset:
        return 0
    d = _norm_desc(g.v(r, c_desc))
    if not d or d == _norm_desc(g.v(r, c_desc + b.offset)):
        return 0
    for dv in (-1, 1, -2, 2):
        if 1 <= r + dv <= g.nrows and d == _norm_desc(g.v(r + dv, c_desc + b.offset)):
            return dv
    return 0


def _leer_filas(ctx, b):
    g = ctx.grilla(b.hoja)
    filas = []
    c_desc = _col_descripcion(g, b) if b.offset else None
    for r in range(b.fila_hdr + 1, b.fila_fin + 1):
        code = g.v(r, b.c_code)
        nombre = re.sub(r'\s+', ' ', texto(g.v(r, b.c_code + 1))).strip()
        if not isinstance(code, str) or not es_codigo_valido(code.strip()):
            # sin código CPC (vacío o 0) pero con una apertura que el INDEC publica sin código, como
            # "Mano de obra directa" o "Mano de obra asalariada" (Cuadro 7): se busca por la descripción
            if not (_RE_SIN_CODIGO.match(strip_accents(nombre.lower())) and g.n(r, b.c_base) is not None):
                continue
            code = DESC + nombre
        f = {'r': r, 'code': code.strip(), 'nombre': nombre,
             'm': g.n(r, b.c_base), 'n': g.n(r, b.c_red), 'coef': g.n(r, b.c_coef),
             'm_raw': g.v(r, b.c_base), 'n_raw': g.v(r, b.c_red), 'pares': [], 'err_plata': None}
        if b.offset:
            dv = _corrimiento_fila(g, b, r, c_desc)        # la copia de la derecha puede estar corrida una fila
            f['dv'] = dv
            for c in sorted(b.plata):                       # precio con error (#N/A, #REF!...) en el original o en la copia
                if es_error(g.v(r, c)) or es_error(g.v(r + dv, c + b.offset)):
                    f['err_plata'] = c
            for c in range(2, b.c_code):
                izq, der = g.n(r, c), g.n(r + dv, c + b.offset)
                if izq is not None and der is not None:
                    f['pares'].append((c, izq, der))
        filas.append(f)
    b.filas = filas
    return filas


class _Verdad:
    """Valor oficial de un código en un mes: el del boletín DE ESE MES (octubre -> boletín de noviembre; enero ->
    boletín de febrero). Los demás boletines que traen el mes solo sirven para avisar que dicen otra cosa."""

    def __init__(self, boletines, elegidos=None):
        self.boletines = boletines
        self.elegidos = elegidos or {}
        self._c = {}

    def boletin(self, ym):
        return boletin_para_mes(self.boletines, ym, self.elegidos)

    @staticmethod
    def _de(b, code, ym):
        if code.startswith(DESC):
            from .comunes import num
            txt, cu = b.buscar_por_descripcion(code[len(DESC):], ym, 7)
            v = num(txt) if txt else None
            return [(v, cu)] if v is not None else []
        return b.valores(code, ym)

    def valores(self, code, ym):
        k = (code, ym)
        if k not in self._c:
            b = self.boletin(ym)
            self._c[k] = [(v, b.nombre, cu) for v, cu in self._de(b, code, ym)] if b is not None else []
        return self._c[k]

    def revisado(self, code, ym, val):
        """Nombre del boletín POSTERIOR cuyo dato (revisado) de ese mes es 'val', o None: la planilla tomó el índice de
        un boletín más nuevo, que corrige los meses anteriores, en vez del boletín publicado para ese mes."""
        b0 = self.boletin(ym)
        for b in sorted(self.boletines, key=lambda x: getattr(x, 'ultimo_mes', (0, 0))):
            if b is b0 or getattr(b, 'ultimo_mes', None) is None or b.ultimo_mes <= ym:
                continue
            try:
                vals = self._de(b, code, ym)
            except Exception:
                continue
            if any(abs(v - val) <= TOL_INDICE for v, _ in vals):
                return b.nombre
        return None

    def otros(self, code, ym):
        """[(valor, boletín)] de los otros boletines que traen ese mes (solo informativo)."""
        b0 = self.boletin(ym)
        return [(v, b.nombre) for b in self.boletines if b is not b0 and b.ultimo_mes == ym for v, _ in self._de(b, code, ym)]


def analizar_items(ctx, hojas_bloques, boletines=(), seleccion=None, seleccion_txt='todas', progreso=True, meses_boletin=None):
    """meses_boletin: {mes: Boletin} lo que el usuario asignó a cada PDF (por defecto su último mes)."""
    todos = [b for bl in hojas_bloques.values() for b in bl]
    for b in todos:
        b.seleccionado = bloque_seleccionado(b, seleccion)
    elegidos = [b for b in todos if b.seleccionado]
    if not elegidos:
        raise ErrorVerificacion(f"El rango '{seleccion_txt}' no toca ningún bloque. Bloques detectados: {texto_bloques(todos)}")
    verdad = _Verdad(list(boletines), meses_boletin)
    for b in elegidos:
        _leer_filas(ctx, b)
    rotulos = _corregir_meses_por_valores(ctx, elegidos, verdad, boletines)

    # consenso: lo que usa la planilla para cada (código, mes); sirve cuando el boletín no trae el dato
    usos = {}
    for b in elegidos:
        for f in b.filas:
            for ym, v in ((b.m_base, f['m']), (b.m_red, f['n'])):
                if v is not None:
                    usos.setdefault((f['code'], ym), Counter())[round(v, 1)] += 1

    hallazgos, resumen = [], []
    sin_dato = set()
    for b in elegidos:
        res = {'hoja': b.hoja, 'bloque': b.etiqueta, 'm_base': b.m_base, 'm_red': b.m_red, 'n_redet': b.n_redet, 'insumos': len(b.filas),
               'ind_ok': 0, 'ind_mal': 0, 'pre_ok': 0, 'pre_mal': 0, 'acum_mal': 0, 'cortes': 0, 'a0_hoja': None, 'a0_af': None,
               'a0_ajuste': None, 'v0_ajuste': None, 'frac_ajuste': None, 'col_prev': None, 'a_esp': None, 'v_esp': None,
               'origen_av': '', 'notas': []}
        if not b.offset:
            res['notas'].append('no pude ubicar la copia redeterminada (derecha): solo se controlan índices y coeficiente')
        for f in b.filas:
            n0 = len(hallazgos)
            coef_c = _analizar_fila(b, f, verdad, usos, sin_dato, hallazgos, res, boletines)
            _poner_impacto(hallazgos[n0:], f, b, coef_c)
        resumen.append(res)

    hallazgos[:0] = rotulos
    if sin_dato and boletines:
        codigos = sorted({etiqueta_codigo(c) for c, _ in sin_dato})
        hallazgos.append(_hallazgo(hoja='(varias)', bloque='', fila='', col='', tipo='Código sin dato en el boletín', nivel='AVISO',
                                   detalle=f"{len(codigos)} código(s) sin valor en los boletines cargados para el mes pedido (se compararon entre sí): "
                                           + ', '.join(codigos[:12]) + (' ...' if len(codigos) > 12 else '')))
    return {'path': ctx.path, 'hojas': hojas_bloques, 'hallazgos': hallazgos, 'resumen': resumen, 'af_filas': [],
            'hojas_indec': ['(boletín INDEC, por código)'], 'hoja_af': '', 'tabla': {}, 'seleccion_txt': seleccion_txt,
            'resumen_agr': agrupar_resumen(resumen), 'bloques_txt': texto_bloques(elegidos), 'formato': 'items'}


def _coinciden(b, col, ym, verdad):
    """(filas que coinciden con el boletín de 'ym', filas con dato en ese boletín) para la columna 'm' o 'n' del bloque."""
    ok = con = 0
    for f in b.filas:
        val = f[col]
        if val is None:
            continue
        ofi = verdad.valores(f['code'], ym)
        if not ofi:
            continue
        con += 1
        ok += any(abs(o[0] - val) <= TOL_INDICE for o in ofi)
    return ok, con


def _corregir_meses_por_valores(ctx, bloques, verdad, boletines):
    """El encabezado de la columna dice un mes (BASE OCT 25 / REDET ENE 26) pero los índices cargados son, casi
    todos, los de OTRO mes de los boletines cargados (típico: la hoja se copió de la redeterminación anterior y no se
    actualizó el rótulo). En ese caso se controla con el mes que corresponde a los valores (si no, salen cientos de
    índices "mal" que en realidad están bien) y se informa UNA observación: el rótulo equivocado.
    Se decide por hoja (sumando todas sus tablas); una hoja con muy pocos índices sigue lo que se decidió para el
    resto de las hojas con ese mismo rótulo."""
    candidatos = sorted({b.ultimo_mes for b in boletines if getattr(b, 'ultimo_mes', None)})
    if not candidatos:
        return []
    COLS = (('m', 'm_base', 'Índice base'), ('n', 'm_red', 'Índice de la redet.'))

    def sumar(bls, col, ym):
        ok = con = 0
        for b in bls:
            a, c = _coinciden(b, col, ym, verdad)
            ok, con = ok + a, con + c
        return ok, con

    def decidir(bls, col, actual):
        """(mes de los valores, coinciden, con dato) si el rótulo está mal; None si está bien; 'pocos' si no alcanza."""
        n = sum(1 for b in bls for f in b.filas if f[col] is not None)
        ok_h, con_h = sumar(bls, col, actual) if actual in candidatos else (0, 0)
        if con_h and ok_h >= 0.6 * con_h:
            return None
        if n == 0:
            return None
        mejor = None
        for ym in candidatos:
            if ym != actual:
                ok, con = sumar(bls, col, ym)
                if con and ok >= 0.8 * con and (mejor is None or ok > mejor[1]):
                    mejor = (ym, ok, con)
        if n < 3 or not mejor or mejor[1] < ok_h + max(2, 0.3 * n):
            return 'pocos'                   # sin evidencia propia suficiente: sigue a las demás hojas con el mismo rótulo
        return mejor

    por_hoja = {}
    for b in bloques:
        por_hoja.setdefault(b.hoja, []).append(b)
    decisiones, pendientes = {}, []
    for hoja, bls in por_hoja.items():
        for col, attr, _ in COLS:
            for actual in sorted({getattr(b, attr) for b in bls if getattr(b, attr)}):
                grupo = [b for b in bls if getattr(b, attr) == actual]
                d = decidir(grupo, col, actual)
                if d == 'pocos':
                    pendientes.append((hoja, col, attr, actual, grupo))
                elif d:
                    decisiones[(hoja, col, actual)] = (d, grupo)
    # hojas con pocos índices: siguen a la mayoría de las hojas con el mismo rótulo (si todas las que decidieron cambian igual)
    for hoja, col, attr, actual, grupo in pendientes:
        otras = {d[0] for (h2, c2, a2), (d, _) in decisiones.items() if c2 == col and a2 == actual}
        n_otras = sum(1 for (h2, c2, a2) in decisiones if c2 == col and a2 == actual)
        if len(otras) == 1 and n_otras >= 3:
            ym = otras.pop()
            ok, con = sumar(grupo, col, ym)
            decisiones[(hoja, col, actual)] = ((ym, ok, con), grupo)

    out = []
    for (hoja, col, actual), ((ym, ok, con), grupo) in decisiones.items():
        attr, tipo = next((a, t) for c, a, t in COLS if c == col)
        g = ctx.grilla(hoja)
        b0 = grupo[0]
        c_hdr = b0.c_base if col == 'm' else b0.c_red
        rot = texto(g.v(b0.fila_hdr, c_hdr))
        for b in grupo:
            setattr(b, attr, ym)
        out.append(_hallazgo(hoja=hoja, bloque=b0.etiqueta, fila=b0.fila_hdr, col=_letra(c_hdr), tipo='Rótulo del mes', nivel='ERROR',
                             rotulo=rot, m_rotulo=actual, m_valores=ym, columna=tipo, coinciden=(ok, con),
                             m_base=b0.m_base, m_red=b0.m_red,
                             detalle=f"El encabezado dice «{rot}» ({mes_txt(actual)}), pero {ok} de {con} índices de la columna son los de {mes_txt(ym)}."))
    return out


def _analizar_fila(b, f, verdad, usos, sin_dato, hallazgos, res, boletines):
    """Controles de una fila de insumo. Devuelve el coeficiente CORRECTO (con los índices oficiales) o None."""
    H = lambda fila=None, **kw: _hallazgo(hoja=b.hoja, bloque=b.etiqueta, fila=f['r'] if fila is None else fila, no=etiqueta_codigo(f['code']),
                                          insumo=f['nombre'], m_base=b.m_base, m_red=b.m_red, **kw)
    fila_der = f['r'] + f.get('dv', 0)                  # fila del mismo insumo en la copia redeterminada (derecha)
    c_ref, oficial = {}, {}
    mal_indice = False
    for tipo, val, ym, col in (('Índice base', f['m'], b.m_base, b.c_base), ('Índice de la redet.', f['n'], b.m_red, b.c_red)):
        L_ = _letra(col)
        if val is None:
            raw = f['m_raw'] if col == b.c_base else f['n_raw']
            if raw is not None and es_error(raw):
                hallazgos.append(H(col=L_, tipo=tipo, detalle='La celda del índice da error.'))
                mal_indice = True
            continue
        oficiales = verdad.valores(f['code'], ym)
        if oficiales:
            oficial[ym] = oficiales[0][0]
            if not any(abs(o[0] - val) <= TOL_INDICE for o in oficiales):
                mal_indice = True
                otros = verdad.otros(f['code'], ym)
                rev = verdad.revisado(f['code'], ym, val)
                hallazgos.append(H(col=L_, tipo=tipo, valor_hoja=val, valor_esperado=oficiales[0][0], boletin=oficiales[0][1], cuadro=oficiales[0][2],
                                   otro=(otros[0][1], otros[0][0]) if otros else None, revisado=rev,
                                   detalle=f"El boletín '{oficiales[0][1]}' dice {oficiales[0][0]:g} para {mes_txt(ym)}"
                                           + (f" (ojo: '{otros[0][1]}' también trae ese mes y dice {otros[0][0]:g}; se compara con el boletín de ese mes)" if otros else '')))
            else:
                c_ref[ym] = next(o[0] for o in oficiales if abs(o[0] - val) <= TOL_INDICE)
        else:                     # el boletín no trae este código/mes: se compara con lo que usa el resto de la planilla
            cont = usos.get((f['code'], ym))
            sin_dato.add((f['code'], ym))
            modo, n_modo = cont.most_common(1)[0]
            if len(cont) > 1 and round(val, 1) != modo and n_modo > sum(cont.values()) - n_modo:
                mal_indice = True
                hallazgos.append(H(col=L_, tipo=tipo, valor_hoja=val, valor_esperado=modo,
                                   detalle=f"El boletín no trae este código/mes; el resto de la planilla usa {modo:g} ({n_modo} filas)."))
            else:
                c_ref[ym] = val
    if mal_indice:
        res['ind_mal'] += 1
    elif f['m'] is not None and f['n'] is not None:
        res['ind_ok'] += 1

    # coeficiente correcto: con los índices oficiales; si no, con los de la propia fila
    ib, ir = c_ref.get(b.m_base, f['m']), c_ref.get(b.m_red, f['n'])
    coef_ok = (ir / ib) if (ib and ir) else None
    ob, orr = oficial.get(b.m_base), oficial.get(b.m_red)
    coef_c = (orr / ob) if (ob and orr) else coef_ok
    if f['coef'] is not None and f['m'] and f['n'] and abs(f['coef'] - f['n'] / f['m']) > 1e-6 * abs(f['coef']):
        hallazgos.append(H(col=_letra(b.c_coef), tipo='Coeficiente', valor_hoja=f['coef'], valor_esperado=f['n'] / f['m'],
                           detalle='El coeficiente no es índice de la redet. / índice base de esta misma fila.'))
    if f['err_plata'] is not None:
        hallazgos.append(H(fila=fila_der, col=_letra(f['err_plata'] + b.offset), tipo='Precio con error', nivel='AVISO',
                           detalle='El precio de este insumo da error (#N/A, #REF!...) en la planilla: no se pudo controlar el precio redeterminado.'))
        return None
    if coef_ok is None or not f['pares']:
        return coef_c
    # precio redeterminado = original x coeficiente. Solo las columnas de PLATA (por su encabezado); si el
    # encabezado no dice cuáles, la última con números. Cantidades, HP y horas quedan como están.
    mal_precio = False
    ult = max(c for c, _, _ in f['pares'])
    for c, izq, der in f['pares']:
        if (b.plata and c not in b.plata) or (not b.plata and c != ult):
            continue
        esperado = izq * coef_ok
        if abs(der - esperado) <= max(TOL_PRECIO_ABS, TOL_PRECIO_REL * abs(esperado)):
            continue
        mal_precio = True
        hallazgos.append(H(fila=fila_der, col=_letra(c + b.offset), tipo='Precio del bloque', valor_hoja=der, valor_esperado=esperado,
                           causa=('consecuencia del índice de esta fila' if mal_indice else 'el precio redeterminado no es el original x coeficiente'),
                           detalle=f"original {izq:,.2f} x coef. {coef_ok:.6f}".replace(',', '§').replace('.', ',').replace('§', '.')))
        break
    res['pre_mal' if mal_precio else 'pre_ok'] += 1
    return coef_c


def _poner_impacto(hs, f, b, coef_c):
    """Diferencia (en $) entre el importe de la fila en la planilla y el que resulta con el coeficiente correcto:
    importe redeterminado (columna de plata más a la derecha) - importe original x coeficiente correcto."""
    if not hs or not coef_c or not f['pares'] or not b.offset:
        return
    plata = [(c, izq, der) for c, izq, der in f['pares'] if (c in b.plata if b.plata else True)]
    if not plata:
        return
    _, izq, der = max(plata, key=lambda t: t[0])
    delta = der - izq * coef_c
    if abs(delta) > max(TOL_PRECIO_ABS, TOL_PRECIO_REL * abs(izq)):
        for h in hs:
            h['impacto_fila'] = delta


def agregar_formulas(res, ctx, fm):
    """Suma lo que se ve leyendo las FÓRMULAS: (1) de dónde sale cada índice mal cargado (dónde corregirlo) y
    (2) las celdas cuya fórmula se aparta de la de las demás filas (referencia corrida) o que están tipeadas a mano."""
    hallazgos = res['hallazgos']
    for h in hallazgos:                                            # 1) origen de los índices
        if h['tipo'] in ('Índice base', 'Índice de la redet.') and h['fila'] != '' and h['col']:
            o = fm.origen(h['hoja'], h['fila'], CI(h['col']), ctx.wb)
            if o:
                h['origen'] = o
    # Las columnas de INDICE no se revisan por fórmula: cada fila puede buscar el índice donde quiera; lo que importa es
    # que el valor sea el del INDEC (eso ya lo controla el análisis). En coeficiente y precio, una fórmula distinta es
    # ERROR solo si el valor da mal; si da bien es un aviso informativo.
    con_valor_mal = {(h['hoja'], h['fila'], h['col']) for h in hallazgos if h['tipo'] in ('Precio del bloque', 'Coeficiente')}
    for b in [b for bl in res['hojas'].values() for b in bl if b.seleccionado]:
        filas = [x['r'] for x in b.filas]
        info = {x['r']: x for x in b.filas}
        cols = [(b.c_coef, 'coeficiente')]
        if b.offset:
            cols += [(c + b.offset, 'precio redeterminado') for c in sorted(b.plata)]
        for c, nombre in cols:
            for a in fm.apartadas(b.hoja, c, filas):
                x = info[a['fila']]
                letra = _letra(c)
                base = dict(hoja=b.hoja, bloque=b.etiqueta, fila=a['fila'], col=letra, no=etiqueta_codigo(x['code']), insumo=x['nombre'], m_base=b.m_base, m_red=b.m_red)
                if a['tipo'] == 'formula':
                    mal = (b.hoja, a['fila'], letra) in con_valor_mal
                    if not mal:
                        continue    # fórmula distinta pero el valor da bien: no se informa
                    hallazgos.append(_hallazgo(
                        tipo='Fórmula distinta a la de las filas vecinas' if mal else 'Fórmula distinta con resultado correcto', nivel='ERROR' if mal else 'AVISO',
                        formula_actual=a['actual'], formula_esperada=a['esperado'], formula_firma=a.get('firma'),
                        detalle=f"La fórmula del {nombre} es {a['actual']}; en las demás filas de la columna es {a['esperado']} (referencia distinta)."
                                + ('' if mal else ' El valor que da es correcto.'), **base))
                else:
                    hallazgos.append(_hallazgo(
                        tipo='Valor tipeado donde las demás filas tienen fórmula', nivel='AVISO', formula_esperada=a['esperado'], valor_hoja=a['actual'] if isinstance(a['actual'], (int, float)) else None,
                        detalle=f"El {nombre} está escrito a mano ({a['actual']}); las demás filas de la columna usan una fórmula ({a['esperado']}).", **base))


def _letra(c):
    from openpyxl.utils import get_column_letter
    return get_column_letter(c)

"""Verificador unificado de redeterminaciones de precios."""
__version__ = "2.0"

# -*- coding: utf-8 -*-
"""
copia_anotada.py
-----------------
Copia del Excel de la contratista con cada celda observada MARCADA (color según la gravedad) y con un comentario que
dice qué está mal, cuál es el valor correcto, de dónde sale y qué corregir. No se pisa ningún valor ni fórmula: el
original no se toca y la corrección la hace la empresa.

Se guarda con openpyxl: se conservan datos, fórmulas, formatos y tablas, pero pueden perderse imágenes, gráficos
o formatos condicionales avanzados; por eso es una copia de trabajo para revisión y NO reemplaza al original.
Excel recalcula los valores al abrirla. Solo para .xlsx/.xlsm.
"""
import re

from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.hyperlink import Hyperlink

from .comunes import fmt_es
from .observaciones import GRAVEDADES, NOMBRE_CONTROL, NOMBRE_GRAVEDAD

COLORES = {'ERROR': 'FFC7CE', 'MENOR': 'FFEB9C', 'AVISO': 'DDEBF7'}
_CELDA = re.compile(r'^[A-Z]{1,3}\d{1,7}$')


def _v(x, dec):
    if x is None:
        return '—'
    return x if isinstance(x, str) else fmt_es(x, dec)


def _comentario(o, u):
    dec = 1 if o.tipo in ('indice', 'var') else 2
    lineas = [f"[{o.id}] {NOMBRE_GRAVEDAD[o.gravedad].upper()}: {o.titulo}"]
    if u.actual is not None or u.correcto is not None:
        lineas.append(f"Actual: {_v(u.actual, dec)}")
        lineas.append(f"Correcto: {_v(u.correcto, dec)}")
    if o.fuente:
        lineas.append(f"Fuente: {o.fuente}")
    if u.rol == 'origen' and o.control != 'costos' and o.tipo == 'indice':
        lineas.append("Es la celda de ORIGEN: corregir acá y se actualizan las hojas que la toman.")
    if o.causa:
        lineas.append(f"Causa: {o.causa}")
    lineas.append(f"Corregir: {o.accion}")
    return '\n'.join(lineas)


def escribir_copia(out_path, fm, obs):
    """fm: Formulas (libro con fórmulas). obs: observaciones. Devuelve (celdas_marcadas, no_ubicadas)."""
    wb = fm.wb
    marcadas, no_ubicadas = 0, 0
    por_celda = {}
    for o in obs:
        for u in o.ubicaciones:
            if u.hoja in wb.sheetnames and _CELDA.match(str(u.celda)):
                por_celda.setdefault((u.hoja, u.celda), []).append((o, u))
            else:
                no_ubicadas += 1
    for (hoja, celda), lista in por_celda.items():
        ws = wb[hoja]
        c = ws[celda]
        peor = min((o.gravedad for o, _ in lista), key=GRAVEDADES.index)
        c.fill = PatternFill('solid', fgColor=COLORES[peor])
        texto = '\n\n'.join(_comentario(o, u) for o, u in lista)
        com = Comment(texto[:4000], 'Verificador')
        com.width, com.height = 380, min(60 + 18 * texto.count('\n') + 4 * len(texto) // 60, 420)
        c.comment = com
        marcadas += 1

    # hoja índice al frente, con vínculos a cada lugar
    ws = wb.create_sheet('VERIFICACION', 0)
    ws['A1'] = 'Copia anotada por el Verificador'
    ws['A1'].font = Font(name='Arial', bold=True, size=13)
    ws['A2'] = ('Cada celda observada está coloreada (rojo = error, amarillo = diferencia menor, azul = aviso) y tiene un comentario con el valor '
                'correcto, la fuente y lo que hay que corregir. Copia de trabajo: el original no se modificó.')
    ws['A2'].alignment = Alignment(wrap_text=True, vertical='top')
    ws.merge_cells('A2:G2')
    ws.row_dimensions[2].height = 45
    enc = ['N°', 'Gravedad', 'Control', 'Observación', 'Primer lugar', 'Lugares', 'Corrección solicitada']
    for j, t in enumerate(enc, start=1):
        cel = ws.cell(row=4, column=j, value=t)
        cel.font = Font(name='Arial', bold=True, color='FFFFFF')
        cel.fill = PatternFill('solid', fgColor='1F4E78')
    for i, o in enumerate(obs, start=5):
        u0 = next((u for u in o.ubicaciones if u.hoja in wb.sheetnames and _CELDA.match(str(u.celda))), None)
        vals = [o.id, NOMBRE_GRAVEDAD[o.gravedad], NOMBRE_CONTROL.get(o.control, o.control), o.titulo, u0.texto() if u0 else '', o.n, o.accion]
        for j, v in enumerate(vals, start=1):
            ws.cell(row=i, column=j, value=v).alignment = Alignment(wrap_text=True, vertical='top')
        ws.cell(row=i, column=2).fill = PatternFill('solid', fgColor=COLORES[o.gravedad])
        if u0:
            ws.cell(row=i, column=5).hyperlink = Hyperlink(ref=ws.cell(row=i, column=5).coordinate, location=f"'{u0.hoja}'!{u0.celda}", display=u0.texto())
            ws.cell(row=i, column=5).font = Font(name='Arial', color='0563C1', underline='single')
    for col, w in zip('ABCDEFG', [7, 16, 18, 60, 34, 9, 70]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = 'A5'
    wb.active = 0
    wb.save(out_path)
    return marcadas, no_ubicadas

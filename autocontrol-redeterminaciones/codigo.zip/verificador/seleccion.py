# -*- coding: utf-8 -*-
"""
seleccion.py
-------------
Qué columnas / redeterminaciones analizar. El usuario puede escribir, separados por coma:
    AR:BL        un rango de columnas          AZ        una columna
    R4           una redeterminación           base      la base (solo planilla de costos)
    AP!AR:BL     un rango solo en la hoja 'AP'
Un bloque se analiza si lo escrito toca sus columnas. Sirve igual para los bloques del análisis de
precios y para los de la planilla de costos (ambos tienen hoja, n_redet, col_ini y c_precio).
"""
import re

from openpyxl.utils import get_column_letter as L, column_index_from_string as CI


def parsear_seleccion(txt):
    """Interpreta lo que escribe el usuario. Acepta, separados por coma o punto y coma:
         AR:BL        rango de columnas
         AZ           una columna (elige el bloque que la contiene)
         R4           el bloque de la redeterminación 4
         AP!AR:BL     lo mismo, pero solo en la hoja 'AP'
    Devuelve (tokens, error)."""
    tokens = []
    for t in re.split(r'[;,]', txt):
        t = t.strip()
        if not t:
            continue
        hoja = None
        if '!' in t:
            hoja, t = t.rsplit('!', 1)
            hoja = hoja.strip().strip("'")
            t = t.strip()
        m = re.match(r'^([A-Za-z]{1,3})\s*[:\-]\s*([A-Za-z]{1,3})$', t)
        if m:
            a, b = CI(m.group(1).upper()), CI(m.group(2).upper())
            tokens.append(('cols', hoja, min(a, b), max(a, b)))
            continue
        m = re.match(r'^([A-Za-z]{1,3})$', t)
        if m and not re.match(r'^R\d*$', t, re.IGNORECASE):
            c = CI(m.group(1).upper())
            tokens.append(('cols', hoja, c, c))
            continue
        m = re.match(r'^R\s*(\d+)$', t, re.IGNORECASE)
        if m:
            tokens.append(('redet', hoja, int(m.group(1))))
            continue
        return None, f"No entendí '{t}'. Escribí un rango de columnas (AR:BL), una columna (AZ) o una redeterminación (R4)."
    if not tokens:
        return None, "No escribiste nada."
    return tokens, None


def bloque_seleccionado(b, tokens):
    """Un bloque se analiza si el rango pedido toca sus columnas de índices (de Nº a Precio)."""
    if tokens is None:
        return True
    for tk in tokens:
        if tk[1] and tk[1].lower() != str(b.hoja).lower():
            continue
        if tk[0] == 'cols':
            if b.col_ini <= tk[3] and b.c_precio >= tk[2]:
                return True
        elif tk[0] == 'redet' and b.n_redet == tk[2]:
            return True
    return False


def texto_bloques(bloques):
    """Ej.: 'AP R4 (AZ:BD)'. Si muchas hojas tienen el mismo bloque: 'R3 (W:Z) en 65 hojas'."""
    grupos = {}
    for b in bloques:
        grupos.setdefault((b.etiqueta, b.col_ini, b.c_precio), []).append(b.hoja)
    partes = []
    for (et, ci, cp), hojas in grupos.items():
        if len(hojas) == 1:
            partes.append(f"{hojas[0]} {et} ({L(ci)}:{L(cp)})")
        else:
            partes.append(f"{et} ({L(ci)}:{L(cp)}) en {len(hojas)} hojas")
    return ', '.join(partes)


# -*- coding: utf-8 -*-
"""
excel.py
---------
Lectura de Excel, en un solo lugar. Funciona con .xlsx/.xlsm (openpyxl) y con .xls
viejo (xlrd) con la misma interfaz: wb.sheetnames, wb[nombre], ws.max_row, ws.max_column,
ws.cell(row=, column=).value y ws.merged_cells.ranges. Siempre se leen VALORES (lo que
Excel calculó la última vez que se guardó), nunca fórmulas.
"""
import os

import openpyxl

from .comunes import ErrorVerificacion, num


# ----------------------------------------------------------------------
# Adaptador para .xls (formato viejo, que openpyxl no abre)
# ----------------------------------------------------------------------
class _CeldaXLS:
    __slots__ = ('value',)

    def __init__(self, value):
        self.value = value


class _RangoMergeXLS:
    def __init__(self, min_row, max_row, min_col, max_col):
        self.min_row, self.max_row, self.min_col, self.max_col = min_row, max_row, min_col, max_col


class _MergedCellsXLS:
    def __init__(self, ranges):
        self.ranges = ranges


class HojaXLS:
    def __init__(self, sheet):
        import xlrd
        self._sheet = sheet
        self._xlrd = xlrd
        self.max_row = sheet.nrows
        self.max_column = sheet.ncols
        rangos = []
        try:
            for (rlo, rhi, clo, chi) in sheet.merged_cells:
                rangos.append(_RangoMergeXLS(rlo + 1, rhi, clo + 1, chi))
        except Exception:
            pass
        self.merged_cells = _MergedCellsXLS(rangos)

    def cell(self, row, column):
        r0, c0 = row - 1, column - 1
        if r0 < 0 or c0 < 0 or r0 >= self._sheet.nrows or c0 >= self._sheet.ncols:
            return _CeldaXLS(None)
        ctype = self._sheet.cell_type(r0, c0)
        val = self._sheet.cell_value(r0, c0)
        if ctype == self._xlrd.XL_CELL_EMPTY or val == '':
            return _CeldaXLS(None)
        if ctype == self._xlrd.XL_CELL_DATE:
            try:
                val = self._xlrd.xldate_as_datetime(val, self._sheet.book.datemode)
            except Exception:
                pass
        elif ctype == self._xlrd.XL_CELL_ERROR:
            # las celdas con error (#N/A, #DIV/0!) se leen como texto '#...', no como un número
            val = str(self._xlrd.error_text_from_code.get(val, '#ERROR'))
        return _CeldaXLS(val)


class LibroXLS:
    def __init__(self, path):
        import xlrd
        self._book = xlrd.open_workbook(path, formatting_info=True)
        self.sheetnames = list(self._book.sheet_names())
        self._cache = {}

    def __getitem__(self, name):
        if name not in self._cache:
            self._cache[name] = HojaXLS(self._book.sheet_by_name(name))
        return self._cache[name]


def es_hoja_de_datos(ws):
    """True si 'ws' es una hoja con datos (no un gráfico ni similar)."""
    from openpyxl.worksheet.worksheet import Worksheet
    return isinstance(ws, (Worksheet, HojaXLS))


def _cargar_xlsx_con_progreso(path):
    """openpyxl.load_workbook(path, data_only=True), pero imprimiendo una barra de progreso REAL mientras
    lee las hojas (lo que más tarda al abrir un Excel grande). El avance se pondera por el tamaño de
    cada hoja dentro del archivo, así una hoja enorme pesa lo que realmente pesa y el porcentaje no
    salta de 10% a 90% de golpe. La barra usa el mismo formato que barra_progreso(), así la interfaz
    web la muestra igual que las demás."""
    from openpyxl.reader.excel import ExcelReader

    nombre = os.path.basename(path)

    class _Lector(ExcelReader):
        def read(self):
            # Igual que ExcelReader.read(), salvo los ESTILOS: en vez de cargar todos (fuentes, bordes,
            # colores y los estilos con nombre, que en planillas muy copiadas llegan a decenas de miles y
            # eran lo que MÁS tardaba), se leen solo los formatos de número, que es lo único que hace
            # falta para reconocer qué celdas son fechas. Este libro se usa solo para LEER valores.
            self.read_manifest()
            self.read_strings()
            self.read_workbook()
            self.read_properties()
            self.read_custom()
            self.read_theme()
            if not _formatos_de_fecha(self.archive, self.wb):
                from openpyxl.styles.stylesheet import apply_stylesheet
                apply_stylesheet(self.archive, self.wb)          # si algo no se entiende: la carga completa
            self.read_worksheets()
            self.parser.assign_names()
            self.archive.close()

        def read_worksheets(self):
            hojas = list(self.parser.find_sheets())
            tam = {}
            for _, rel in hojas:
                try:
                    tam[rel.target] = max(1, self.archive.getinfo(rel.target).file_size)
                except KeyError:
                    tam[rel.target] = 1
            total = sum(tam.values()) or 1
            hecho = [0]
            original = self.parser.find_sheets

            def _con_avance():
                for i, (sheet, rel) in enumerate(hojas, start=1):
                    pct = int(100 * hecho[0] / total)
                    barra = '#' * (pct * 30 // 100) + '-' * (30 - pct * 30 // 100)
                    print(f"\r  Abriendo el Excel: hoja '{sheet.name}' [{barra}] {pct:3d}% ({i}/{len(hojas)})",
                          end='', flush=True)
                    yield sheet, rel
                    hecho[0] += tam.get(rel.target, 1)

            self.parser.find_sheets = _con_avance
            try:
                super().read_worksheets()
            finally:
                self.parser.find_sheets = original
            print(f"\r  Abriendo el Excel [{'#' * 30}] 100% ({len(hojas)}/{len(hojas)})", end='', flush=True)

    print(f"\r  Abriendo el Excel: leyendo los textos de '{nombre}'…", end='', flush=True)
    lector = _Lector(path, read_only=False, keep_vba=False, data_only=True, keep_links=False)   # vínculos a otros libros: no hacen falta para leer valores
    lector.read()
    print(f"\r  Excel abierto: {nombre} ({len(lector.wb.sheetnames)} hojas).".ljust(100))
    return lector.wb


class _CeldaVacia:
    """Lo que devuelve ws.cell() para una celda vacía en un libro de solo lectura (ver _solo_lectura)."""
    __slots__ = ()
    value = None


_VACIA = _CeldaVacia()


def _formatos_de_fecha(archive, wb):
    """Lee de xl/styles.xml SOLO los formatos de número de cada estilo de celda y marca cuáles son de
    fecha/hora (lo mismo que calcula openpyxl, sin armar el resto de los estilos). Devuelve False si no
    pudo (y entonces se usa la carga completa de openpyxl)."""
    try:
        import xml.etree.ElementTree as ET
        from openpyxl.styles.numbers import BUILTIN_FORMATS, is_date_format, is_timedelta_format
        from openpyxl.styles.cell_style import StyleArray
        try:
            src = archive.read('xl/styles.xml')
        except KeyError:
            return True                                         # sin estilos: no hay fechas por formato
        ns = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
        propios, ids = {}, []
        for ev, el in ET.iterparse(__import__('io').BytesIO(src), events=('end',)):
            if el.tag == ns + 'numFmt':
                propios[int(el.get('numFmtId'))] = el.get('formatCode') or ''
            elif el.tag == ns + 'cellXfs':
                ids = [int(x.get('numFmtId') or 0) for x in el.findall(ns + 'xf')]
                el.clear()
            elif el.tag == ns + 'cellStyleXfs' or el.tag == ns + 'cellStyles':
                el.clear()                                      # lo pesado: no se usa
        fechas, tiempos = set(), set()
        for i, n in enumerate(ids):
            fmt = propios.get(n, BUILTIN_FORMATS.get(n, 'General'))
            if is_date_format(fmt):
                fechas.add(i)
            if is_timedelta_format(fmt):
                tiempos.add(i)
        wb._date_formats, wb._timedelta_formats = fechas, tiempos
        comun = StyleArray()

        class _MismoEstilo:                                     # todas las celdas comparten un estilo vacío
            def __getitem__(self, i):
                return comun

            def __len__(self):
                return max(1, len(ids))
        wb._cell_styles = _MismoEstilo()
        return True
    except Exception:
        return False


def _solo_lectura(wb):
    """ws.cell(fila, col) de openpyxl CREA la celda si está vacía: recorrer un rango grande creaba
    millones de celdas vacías (lento y con mucha memoria). En el libro que se usa solo para leer valores,
    ws.cell() pasa a buscar la celda existente y, si no hay, devuelve una vacía compartida."""
    from openpyxl.worksheet.worksheet import Worksheet
    for ws in wb.worksheets:
        if not isinstance(ws, Worksheet):
            continue
        celdas = ws._cells

        def cell(row, column=None, value=None, _celdas=celdas):
            if value is not None:
                raise TypeError("Este libro es de solo lectura (se usa para verificar, no para escribir).")
            c = _celdas.get((row, column))
            return c if c is not None else _VACIA
        ws.cell = cell
    wb._solo_lectura = True
    return wb


def _cargar_xlsx(path):
    try:
        wb = _cargar_xlsx_con_progreso(path)
    except Exception:
        # si la versión de openpyxl cambia por dentro, se abre igual, sin barra
        wb = openpyxl.load_workbook(path, data_only=True)
    return _solo_lectura(wb)


def abrir_libro(path):
    """Abre un .xlsx/.xlsm con openpyxl o un .xls con xlrd según la extensión, con reintento
    cruzado si el archivo no es lo que su extensión sugiere (pasa con archivos renombrados)."""
    ext = os.path.splitext(path)[1].lower()
    if not os.path.isfile(path):
        raise ErrorVerificacion(f"No encuentro el archivo '{path}'.")
    if ext == '.xls':
        print(f"\r  Abriendo el Excel (.xls): {os.path.basename(path)}…", end='', flush=True)
        try:
            wb = LibroXLS(path)
        except Exception:
            wb = openpyxl.load_workbook(path, data_only=True)
        print(f"\r  Excel abierto: {os.path.basename(path)} ({len(wb.sheetnames)} hojas).".ljust(100))
        return wb
    try:
        return _cargar_xlsx(path)
    except Exception as e:
        if ext in ('.xlsx', '.xlsm'):
            raise ErrorVerificacion(f"No pude abrir '{os.path.basename(path)}': {type(e).__name__}: {e}. "
                                    "Probá abrirlo en Excel y guardarlo de nuevo como .xlsx.")
        return LibroXLS(path)


def hojas_de_datos(wb):
    return [n for n in wb.sheetnames if es_hoja_de_datos(wb[n])]


# ----------------------------------------------------------------------
# Lectura rápida a memoria
# ----------------------------------------------------------------------
def leer_rango(ws, max_col, max_row=None):
    """Filas (listas) de las primeras max_col columnas. Rápido tanto en .xlsx como en .xls."""
    mr = min(ws.max_row, max_row or ws.max_row)
    if hasattr(ws, '_sheet'):                       # .xls
        sh = ws._sheet
        xlrd = ws._xlrd
        out = []
        for r in range(min(mr, sh.nrows)):
            hasta = min(max_col, sh.ncols)
            vals = sh.row_values(r, 0, hasta)
            tipos = sh.row_types(r, 0, hasta)
            fila = []
            for x, t in zip(vals, tipos):
                if t == xlrd.XL_CELL_ERROR:
                    fila.append('#ERROR')            # un error no debe leerse como número
                elif x == '' or isinstance(x, bytes):
                    fila.append(None)
                else:
                    fila.append(x)
            out.append(fila)
        return out
    celdas = getattr(ws, '_cells', None)
    if isinstance(celdas, dict):
        # directo del diccionario de celdas que EXISTEN (no se crea ninguna vacía): mucho más rápido que
        # iter_rows en hojas anchas con pocas celdas llenas
        out = [[None] * max_col for _ in range(mr)]
        for (r, c), cel in celdas.items():
            if r <= mr and c <= max_col:
                out[r - 1][c - 1] = cel.value
        return out
    return [list(r) for r in ws.iter_rows(min_row=1, max_row=mr, min_col=1, max_col=max_col, values_only=True)]


class Grilla:
    """Hoja leída a memoria con acceso 1-based: g.v(fila, columna)."""

    def __init__(self, ws, nombre, max_col=260, max_row=6000):
        self.nombre = nombre
        self.filas = leer_rango(ws, max_col, max_row)
        self.nrows = len(self.filas)
        self.ncols = max((len(f) for f in self.filas), default=0)

    def v(self, r, c):
        if r < 1 or c < 1 or r > self.nrows:
            return None
        f = self.filas[r - 1]
        return f[c - 1] if c <= len(f) else None

    def n(self, r, c):
        x = self.v(r, c)
        return None if isinstance(x, str) and x.strip().startswith('#') else num(x)

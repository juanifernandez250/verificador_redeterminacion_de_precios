# -*- coding: utf-8 -*-
"""
comunes.py
-----------
Utilidades compartidas por todos los controles: lectura de números y fechas,
formatos, tolerancias, estilos del reporte Excel y ayudas para pedir datos.

Convención UNICA de fechas en todo el programa: una tupla (año, mes), que se
ordena sola cronológicamente.
"""
import os
import re
import sys
import datetime as dt
import unicodedata

from openpyxl.styles import Font, PatternFill, Alignment

FONT = 'Arial'

# ----------------------------------------------------------------------
# Tolerancias (un único lugar para todas)
# ----------------------------------------------------------------------
TOL_INDICE = 0.051        # el INDEC publica con 1 decimal: solo se acepta el redondeo
TOL_PRECIO_ABS = 0.011    # un centavo
TOL_PRECIO_REL = 1e-6
TOL_FACTOR = 5e-7         # A0 / V0 (fracciones)


class ErrorVerificacion(Exception):
    """Error 'esperable' (archivo mal armado, falta una hoja, etc.): se le muestra el
    mensaje al usuario y el resto de los controles sigue."""


def configurar_consola():
    """Que la consola de Windows no falle con tildes ni símbolos."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass


# ----------------------------------------------------------------------
# Texto y números
# ----------------------------------------------------------------------
def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')


_RE_NUM_TXT = re.compile(r'^-?\d[\d.,]*$')


def num(x):
    """Número de una celda. Acepta también números escritos como TEXTO, en formato
    argentino ('13.805,7') o con punto decimal ('13805.7'), que algunas planillas
    tienen en la hoja INDEC o en el análisis."""
    if isinstance(x, bool):
        return None
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        s = x.strip().replace('\xa0', '')
        if not _RE_NUM_TXT.match(s):
            return None
        try:
            if ',' in s:
                s = s.replace('.', '').replace(',', '.')
            elif re.match(r'^-?\d{1,3}(\.\d{3})+$', s):       # '13.805' = trece mil ochocientos cinco
                s = s.replace('.', '')
            return float(s)
        except ValueError:
            return None
    return None


def fmt_es(x, dec=2):
    """Formato argentino: 12.020,8"""
    if x is None:
        return ''
    s = f"{x:,.{dec}f}"
    return s.replace(',', '§').replace('.', ',').replace('§', '.')


def es_error(v):
    return isinstance(v, str) and v.strip().startswith('#')


def texto(v):
    """Contenido de una celda como texto limpio ('' si está vacía). Los enteros que
    Excel guarda como float (2695.0) se pasan a '2695'. Las fechas devuelven ''."""
    if v is None:
        return ''
    if isinstance(v, float):
        return str(int(v)) if v == int(v) else str(v)
    if isinstance(v, (dt.datetime, dt.date)):
        return ''
    return str(v).replace('\xa0', ' ').strip()


def norm_clave(k):
    """Clave de identidad normalizada: sin espacios ni puntos, minúscula y sin acentos.
    'Art 15 Inciso (a)' y 'Art.15 Inciso (a)' son la misma clave; 'M.O - 001' = 'MO-001'."""
    if not isinstance(k, str):
        return k
    return re.sub(r'[\s.]+', '', strip_accents(k.strip().lower()))


def es_titulo_n(v):
    """¿La celda es el título de columna 'Nº' / 'N°' / 'Nro'?"""
    if not isinstance(v, str):
        return False
    t = strip_accents(v.strip().lower())
    return bool(re.match(r'^n\s*[ºo°.]{0,2}\s*$', t)) or t in ('nro', 'nro.', 'numero')


# ----------------------------------------------------------------------
# Fechas: siempre (año, mes)
# ----------------------------------------------------------------------
MESES_TXT = {'ene': 1, 'feb': 2, 'mar': 3, 'abr': 4, 'may': 5, 'jun': 6, 'jul': 7,
             'ago': 8, 'sep': 9, 'set': 9, 'oct': 10, 'nov': 11, 'dic': 12}
MESES_ABREV = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']
MESES_LARGOS = {'enero': 1, 'febrero': 2, 'marzo': 3, 'abril': 4, 'mayo': 5, 'junio': 6,
                'julio': 7, 'agosto': 8, 'septiembre': 9, 'octubre': 10, 'noviembre': 11,
                'diciembre': 12}
_FECHA_TXT_1 = re.compile(r'^(ene|feb|mar|abr|may|jun|jul|ago|sep|set|oct|nov|dic)[a-z]*\.?[\s\-/.]+(\d{2}|\d{4})$')
_FECHA_TXT_2 = re.compile(r'^(\d{1,2})\s*[/\-.]\s*(\d{4})$')
_FECHA_TXT_3 = re.compile(r'^(\d{4})\s*[/\-.]\s*(\d{1,2})$')


def fecha(v):
    """(año, mes) si la celda es una fecha (de Excel o escrita como texto:
    'oct-25', '10/2025', '2025-10'); si no, None."""
    if isinstance(v, (dt.datetime, dt.date)):
        return (v.year, v.month)
    if isinstance(v, str):
        s = strip_accents(v.strip().lower())
        if not s or len(s) > 20:
            return None
        m = _FECHA_TXT_1.match(s)
        if m:
            a = int(m.group(2))
            return (a + 2000 if a < 100 else a, MESES_TXT[m.group(1)])
        m = _FECHA_TXT_2.match(s)
        if m and 1 <= int(m.group(1)) <= 12 and 1990 <= int(m.group(2)) <= 2100:
            return (int(m.group(2)), int(m.group(1)))
        m = _FECHA_TXT_3.match(s)
        if m and 1 <= int(m.group(2)) <= 12 and 1990 <= int(m.group(1)) <= 2100:
            return (int(m.group(1)), int(m.group(2)))
    return None


def mes_txt(ym):
    """(2026, 4) -> 'ABR-2026'"""
    if not ym:
        return '?'
    return f"{MESES_ABREV[ym[1] - 1].upper()}-{ym[0]}"


def parsear_mes(txt):
    """Acepta 'ABR-2026', 'abril 2026', '04-2026', '4/2026'. Devuelve (año, mes)."""
    t = strip_accents(txt.strip().lower())
    m = re.match(r'^(\d{1,2})[\-/\s](\d{4})$', t)
    if m and 1 <= int(m.group(1)) <= 12:
        return (int(m.group(2)), int(m.group(1)))
    m = re.match(r'^([a-z]+)[\s\-/]*(\d{4})$', t)
    if m and m.group(1)[:3] in MESES_TXT:
        return (int(m.group(2)), MESES_TXT[m.group(1)[:3]])
    raise ValueError(f"No pude interpretar el mes: '{txt}'. Usá algo como 'ABR-2026'.")


# ----------------------------------------------------------------------
# Consola: progreso y preguntas
# ----------------------------------------------------------------------
def barra_progreso(actual, total, prefijo='', largo=30):
    if total <= 0:
        return
    frac = min(actual / total, 1.0)
    llenado = int(largo * frac)
    barra = '#' * llenado + '-' * (largo - llenado)
    print(f'\r{prefijo} [{barra}] {int(frac * 100):3d}% ({actual}/{total})', end='', flush=True)
    if actual >= total:
        print()


def pedir(pregunta, defecto=''):
    """input() que devuelve 'defecto' si no hay consola (EOF)."""
    try:
        return input(pregunta).strip()
    except EOFError:
        return defecto


def limpiar_ruta(txt):
    return txt.strip().strip('"').strip("'").strip()


def separar_rutas(txt):
    """Rutas que arrastró el usuario. Si es una sola ruta existente (aunque tenga espacios),
    se usa entera; si son varias entre comillas ("a.pdf" "b.pdf"), se separan."""
    t = txt.strip()
    if not t:
        return []
    if os.path.exists(limpiar_ruta(t)):
        return [limpiar_ruta(t)]
    partes = [a or b for a, b in re.findall(r'"([^"]+)"|(\S+)', t)]
    return [limpiar_ruta(p) for p in partes]


# ----------------------------------------------------------------------
# Estilos y utilidades del reporte Excel
# ----------------------------------------------------------------------
ROJO = PatternFill('solid', fgColor='FFC7CE')
VERDE = PatternFill('solid', fgColor='C6EFCE')
AMARILLO = PatternFill('solid', fgColor='FFF2CC')
AZUL = PatternFill('solid', fgColor='1F4E78')
GRIS = PatternFill('solid', fgColor='D9D9D9')


def encabezado(ws, fila, titulos):
    for i, t in enumerate(titulos, start=1):
        c = ws.cell(row=fila, column=i, value=t)
        c.font = Font(name=FONT, bold=True, color='FFFFFF')
        c.fill = AZUL
        c.alignment = Alignment(wrap_text=True, vertical='center')


def anchos(ws, lista):
    from openpyxl.utils import get_column_letter
    for j, w in enumerate(lista, start=1):
        ws.column_dimensions[get_column_letter(j)].width = w


def nombre_salida_unico(xlsx_path, carpeta='.', prefijo='Verificacion', ext='.xlsx'):
    """'Verificacion - <excel>.xlsx'; si existe, agrega (2), (3)... para no pisar nada."""
    base = os.path.splitext(os.path.basename(xlsx_path))[0]
    ruta = os.path.join(carpeta, f"{prefijo} - {base}{ext}")
    i = 2
    while os.path.exists(ruta):
        ruta = os.path.join(carpeta, f"{prefijo} - {base} ({i}){ext}")
        i += 1
    return ruta


# ----------------------------------------------------------------------
# Resultado de cada control (lo que ve el resumen general)
# ----------------------------------------------------------------------
class Veredicto:
    """Estado final de un control, para el resumen general.
    estado: 'OK' | 'REVISAR' | 'AVISO' | 'OMITIDO' | 'ERROR'"""

    def __init__(self, clave, titulo, estado, mensaje, n_errores=0, n_avisos=0, datos=None):
        self.clave = clave
        self.titulo = titulo
        self.estado = estado
        self.mensaje = mensaje
        self.n_errores = n_errores
        self.n_avisos = n_avisos
        self.datos = datos

# -*- coding: utf-8 -*-
"""
contexto.py
------------
Un Excel abierto y leído UNA sola vez, con lo que necesitan el análisis de precios y la planilla de
costos: la hoja de índices INDEC (por Nº o por código), las hojas de anticipo financiero (AF) y los
bloques de índices del análisis.
"""
import datetime as dt
import os
import re

from .bloques import detectar_bloques
from .comunes import es_error, es_titulo_n, fecha, norm_clave, num, strip_accents, texto
from .excel import Grilla, abrir_libro, hojas_de_datos


class TablaIndices(dict):
    """Diccionario {Nº o código -> índices por mes} que compara las claves normalizadas."""
    def __contains__(self, k):
        return dict.__contains__(self, norm_clave(k))

    def __getitem__(self, k):
        return dict.__getitem__(self, norm_clave(k))

    def __setitem__(self, k, v):
        dict.__setitem__(self, norm_clave(k), v)

    def get(self, k, d=None):
        return dict.get(self, norm_clave(k), d)

    def setdefault(self, k, v=None):
        return dict.setdefault(self, norm_clave(k), v)




# ----------------------------------------------------------------------
# Hoja INDEC del archivo: Nº -> índices por mes
# ----------------------------------------------------------------------
def detectar_hojas_indec(wb):
    cand = [n for n in hojas_de_datos(wb) if 'indec' in n.lower() or 'indic' in n.lower()]
    cand.sort(key=lambda n: 1 if 'selecc' in n.lower() else 0)
    return cand


_TITULOS_CODIGO = ('codigo', 'codigoindicador', 'codigocpc')


def leer_indec(ws):
    """{Nº o código: {'nombre', 'fila', 'vals': {(año, mes): valor}}}.
    La columna de identidad se reconoce por su encabezado: 'Nº' (planillas con numeración de insumos)
    o 'Código' (planillas donde el insumo se identifica por el mismo código del INDEC).
    Las columnas de meses se reconocen por sus fechas, que pueden estar en cualquier fila del encabezado.
    Los números pueden estar escritos como texto ('13.805,7')."""
    col_n = None
    modo_codigo = False
    for r in range(1, 16):
        for c in range(1, 9):
            if es_titulo_n(ws.cell(row=r, column=c).value):
                col_n = c
                break
        if col_n:
            break
    if col_n is None:
        for r in range(1, 16):
            for c in range(1, 9):
                v = ws.cell(row=r, column=c).value
                if isinstance(v, str) and re.sub(r'[\s.]+', '', strip_accents(v.lower())) in _TITULOS_CODIGO:
                    col_n, modo_codigo = c, True
                    break
            if col_n:
                break
    if col_n is None:
        col_n = 1
    cols_fecha = {}
    for r in range(1, 16):
        for c in range(1, min(ws.max_column, 60) + 1):
            v = ws.cell(row=r, column=c).value
            if isinstance(v, (dt.datetime, dt.date)):
                cols_fecha.setdefault(c, fecha(v))
    cols = sorted(cols_fecha)
    tabla = TablaIndices()
    for r in range(1, ws.max_row + 1):
        no = ws.cell(row=r, column=col_n).value
        if not isinstance(no, str) or not no.strip() or es_error(no):
            continue
        vals = {}
        for c in cols:
            x = num(ws.cell(row=r, column=c).value)
            if x is not None:
                vals.setdefault(cols_fecha[c], x)      # si el mes se repite, vale la 1ª columna
        if vals:
            no = no.strip()
            if no in tabla:
                tabla[no]['duplicado'] = True
                continue
            nombre = texto(ws.cell(row=r, column=col_n + (2 if modo_codigo else 1)).value)
            tabla[no] = {'nombre': nombre, 'fila': r, 'vals': vals}
    return tabla



# ----------------------------------------------------------------------
# Hoja de Anticipo Financiero (AF): A0 = A.F x V0 / V1
# ----------------------------------------------------------------------
AF_HDR = re.compile(r'porcentaje\s+de\s+anticipo\s+financiero\s+para\s+r\s*(\d+)?', re.IGNORECASE)


def detectar_hojas_af(wb):
    """Hojas de anticipo financiero. Puede ser una sola con un bloque por redeterminación
    ('AF', 'A.F') o una hoja por redeterminación ('AF (1°R)', 'AF (2°R)'...)."""
    res = []
    for n in hojas_de_datos(wb):
        nl = strip_accents(n.lower()).strip()
        if re.match(r'^a\.?\s*f(\W|$)', nl) or 'anticipo' in nl:
            res.append(n)
    if res:
        return res
    for n in hojas_de_datos(wb):                                   # por contenido, en hojas chicas
        ws = wb[n]
        if ws.max_row > 400:
            continue
        for r in range(1, min(ws.max_row, 60) + 1):
            for c in (1, 2):
                v = ws.cell(row=r, column=c).value
                if isinstance(v, str) and AF_HDR.search(strip_accents(v)):
                    res.append(n)
                    break
            else:
                continue
            break
    return res


def _num_der(ws, r, c0, max_c=14):
    """Primer número a la derecha de la celda (r, c0): (valor, columna)."""
    for c in range(c0 + 1, max_c + 1):
        v = ws.cell(row=r, column=c).value
        if num(v) is not None:
            return num(v), c
        if es_error(v):
            return 'ERR', c
    return None, None


def leer_af(ws):
    """Lista de bloques 'Porcentaje de Anticipo Financiero para Rn'."""
    bloques = []
    actual = None

    def guardar(campo, r, c):
        v, cc = _num_der(ws, r, c)
        actual[campo] = v
        actual['celdas'][campo] = (r, cc if cc else c)

    for r in range(1, min(ws.max_row, 600) + 1):
        for c in range(1, 4):
            v = ws.cell(row=r, column=c).value
            if isinstance(v, str) and AF_HDR.search(strip_accents(v)):
                m = AF_HDR.search(strip_accents(v))
                actual = {'n': int(m.group(1)) if m.group(1) else None, 'fila': r, 'col_titulo': c,
                          'V1': None, 'V0': None, 'pct': None, 'A0_res': None, 'V0_res': None,
                          'V1_rotulo': '', 'celdas': {}}
                bloques.append(actual)
                break
        if actual is None:
            continue
        textos_fila = ' '.join(strip_accents(texto(ws.cell(row=r, column=k).value).lower())
                               for k in range(1, 10) if isinstance(ws.cell(row=r, column=k).value, str))
        for c in range(1, 7):
            v = ws.cell(row=r, column=c).value
            if not isinstance(v, str):
                continue
            t = re.sub(r'\s+', '', strip_accents(v.lower()))
            if t == 'v1=':
                guardar('V1', r, c)
                actual['V1_rotulo'] = ' '.join(texto(ws.cell(row=r, column=k).value) for k in range(c + 1, 8)
                                               if isinstance(ws.cell(row=r, column=k).value, str))
            elif t == 'v0=':
                # 'V0=' aparece dos veces: con "Precio de contrato" es el dato; solo con el valor es el RESULTADO
                guardar('V0' if 'precio' in textos_fila else 'V0_res', r, c)
            elif t == 'a0=':
                # con "Calculo del factor" / "A0 = A.F * V0 / V1" es la cuenta; solo con el valor es el RESULTADO
                if 'calculo' not in textos_fila and 'a.f' not in textos_fila:
                    guardar('A0_res', r, c)
            elif t.startswith('porcentajedeanticipo') and 'financiero' not in t:
                guardar('pct', r, c)
            elif re.match(r'^a0\(r\d*\)=?$', t):
                guardar('A0_res', r, c)
            elif re.match(r'^v0\(r\d*\)=?$', t):
                guardar('V0_res', r, c)
    # si algún bloque no trae número de R, se numera por orden de aparición
    for i, b in enumerate(bloques, start=1):
        if b['n'] is None:
            b['n'] = i
            b['n_inferido'] = True
    # si un mismo Rn aparece más de una vez (bloque viejo / copiado), vale el ÚLTIMO
    ultimo = {}
    for b in bloques:
        ultimo[b['n']] = b
    for b in bloques:
        if ultimo[b['n']] is not b:
            b['reemplazado_por'] = ultimo[b['n']]['fila']
    return bloques




# ----------------------------------------------------------------------
# El libro, abierto y leído una sola vez
# ----------------------------------------------------------------------
def es_oculta(ws):
    """¿La hoja está oculta (o 'muy oculta')? Suelen ser versiones viejas que el usuario no ve."""
    if getattr(ws, 'sheet_state', 'visible') != 'visible':
        return True
    sh = getattr(ws, '_sheet', None)                       # .xls
    return bool(sh is not None and getattr(sh, 'visibility', 0))


class Contexto:
    """Excel abierto UNA vez. Guarda la hoja INDEC (tabla), el anticipo financiero y los bloques del
    análisis de precios, para que todos los controles los reutilicen."""

    def __init__(self, path, wb=None):
        """wb: libro YA abierto de ese mismo archivo (para no volver a abrirlo; ver interfaz/motor.py)."""
        self.path = path
        self.nombre = os.path.basename(path)
        self.wb = wb if wb is not None else abrir_libro(path)
        self.avisos = []

        # hoja(s) INDEC: si hay dos ('Indices' e 'Indices Seleccionados') prevalece la primera (completa)
        self.hojas_indec = detectar_hojas_indec(self.wb)
        self.tabla = TablaIndices()
        for h in self.hojas_indec:
            for k, d in leer_indec(self.wb[h]).items():
                self.tabla.setdefault(k, d)

        # anticipo financiero: una hoja con un bloque por redeterminación, o una hoja por redeterminación
        self.hojas_af = detectar_hojas_af(self.wb)
        self.af_bloques = []
        for h in self.hojas_af:
            bls = leer_af(self.wb[h])
            m_h = re.search(r'(\d+)\s*[°º]?\s*r', strip_accents(h.lower()))       # 'AF (3°R)' -> 3
            for b in bls:
                b['hoja'] = h
                if b.get('n_inferido') and m_h:
                    b['n'] = int(m_h.group(1))
            self.af_bloques += bls
        self.af_por_n = {b['n']: b for b in self.af_bloques}

        self.excluir = set(self.hojas_indec) | set(self.hojas_af)
        self.ocultas = {n for n in hojas_de_datos(self.wb) if es_oculta(self.wb[n])}
        self._hojas_bloques = None
        self._grillas = {}

    def configurar_indec(self, hojas):
        """Usa esas hojas como hoja de índices INDEC (cuando el usuario las indica a mano)."""
        self.hojas_indec = list(hojas)
        self.tabla = TablaIndices()
        for h in self.hojas_indec:
            for k, d in leer_indec(self.wb[h]).items():
                self.tabla.setdefault(k, d)
        self.excluir = set(self.hojas_indec) | set(self.hojas_af)
        self._hojas_bloques = None

    def agregar_bloque_manual(self, hoja, c_base, c_red, c_coef, c_precio, c_id=None):
        """Fuerza un bloque de análisis de precios con columnas indicadas A MANO en 'hoja' (para cuando
        la detección automática no encontró ninguna). Se agrega a hojas_bloques como si se hubiera
        detectado solo. Lanza ValueError con un mensaje claro si esas columnas no tienen datos."""
        from .bloques import construir_bloque_manual
        b = construir_bloque_manual(self.wb[hoja], hoja, self.tabla, c_base, c_red, c_coef, c_precio, c_id)
        _ = self.hojas_bloques   # fuerza el escaneo automático primero, si no se hizo todavía
        self._hojas_bloques.setdefault(hoja, [])
        self._hojas_bloques[hoja] = [x for x in self._hojas_bloques[hoja] if x.c_base != c_base or x.c_precio != c_precio] + [b]

    @property
    def hojas_bloques(self):
        """{hoja: [Bloque]} de las hojas de análisis de precios (las que tienen bloques de índices)."""
        if self._hojas_bloques is None:
            self._hojas_bloques = {}
            for n in hojas_de_datos(self.wb):
                if n in self.excluir:
                    continue
                try:
                    bl = detectar_bloques(self.wb[n], n, self.tabla)
                except Exception as e:                       # una hoja rara no debe frenar a las demás
                    self.avisos.append(f"No pude leer la hoja '{n}': {type(e).__name__}: {e}")
                    continue
                if bl:
                    self._hojas_bloques[n] = bl
        return self._hojas_bloques

    def grilla(self, nombre, max_col=260, max_row=30000):
        """Hoja leída a memoria (con caché: se lee una sola vez aunque la pidan varios controles)."""
        clave = (nombre, max_col, max_row)
        if clave not in self._grillas:
            self._grillas[clave] = Grilla(self.wb[nombre], nombre, max_col, max_row)
        return self._grillas[clave]

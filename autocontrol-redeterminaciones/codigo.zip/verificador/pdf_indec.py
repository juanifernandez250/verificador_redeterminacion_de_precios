# -*- coding: utf-8 -*-
"""
pdf_indec.py
-------------
Lectura del boletín "INDEC Informa" (PDF) y búsqueda de índices oficiales por código.
Una sola implementación para los controles de Ítems INDEC y de VAR.

Uso:
    b = Boletin('boletin.pdf')          # lee el PDF una sola vez
    b.meses                             # [(2025, 12), (2026, 1), ...] de izquierda a derecha
    b.buscar('42120-1', (2026, 4))      # todas las apariciones del código en el Anexo

No requiere programas externos: usa solamente la librería 'pdfplumber'.
"""
import hashlib
import json
import os
import re

from .comunes import (ErrorVerificacion, MESES_LARGOS, MESES_TXT, mes_txt, strip_accents, texto)

CUADRO_HEADER_RE = re.compile(r'^\s*Cuadro\s+(\d{1,2})\.(?!\d)')
ANEXO_ANCHOR_RE = re.compile(
    r'Informaci[oó]n para la actualizaci[oó]n de los precios de contratos de obra p[uú]blica'
)
MES_HEADER_RE = re.compile(
    r'^\s*((?:Dic|Jul|Ago|Sep|Oct|Nov|Ene|Feb|Mar|Abr|May|Jun)\*?\s*){4,}$'
)
# Un valor del INDEC siempre tiene UN decimal ('12.908,7'). A veces el PDF trae dos valores pegados, sin
# espacio ('12.908,713.073,8', o cadenas de varios: '100,012.755,512.971,5'): antes eso se leía como un
# único '713.073,8' (y además corría una columna todos los meses de esa fila). Ahora, después del decimal,
# se acepta que siga pegado OTRO número bien formado, y se cortan ahí.
_NUM = r'\d{1,3}(?:\.\d{3})*,\d'
NUM_RE = re.compile(r'-?' + _NUM + r'(?=' + _NUM + r'|(?!\d))|(?<![\w.])s(?![\w.])')
NOTA_PREFIX_RE = re.compile(r'^\(\d+\)\s*')
ART15_INCISO_RE = re.compile(r'art\.?\s*15\.?\s*inciso\s*\(?\s*([a-zA-Z])\s*\)?', re.IGNORECASE)
MES_ABREV_RE_C4 = r'(Ene|Feb|Mar|Abr|May|Jun|Jul|Ago|Sep|Oct|Nov|Dic)'

# Cuadros donde los códigos son ítems individuales de verdad compuestos (ej. "42120-22" es un
# código distinto de "42120"). En los cuadros de AGREGADOS (3, 12, 13) un código suelto seguido
# de "-N" no es un código compuesto distinto: es la lista de sub-códigos que ese agregado resume.
CUADROS_CODIGO_COMPUESTO = {2, 6, 9, 10, 11}


# ----------------------------------------------------------------------
# Lectura del PDF
# ----------------------------------------------------------------------
def leer_pdf_texto(pdf_path, progreso=True):
    """Líneas de texto del Anexo de obra pública (Cuadros 1 a 13)."""
    try:
        import pdfplumber
    except ImportError:
        raise ErrorVerificacion("Falta la librería 'pdfplumber' (la instala setup.ps1). "
                                "Ejecutá de nuevo el .bat para que la agregue.")
    nombre = os.path.basename(pdf_path)
    with pdfplumber.open(pdf_path) as pdf:
        total = len(pdf.pages)
        # Paso 1 (rápido): el Anexo está al FINAL del boletín, así que se busca de atrás para adelante
        # (unas 25 páginas en vez de 180). Se sigue hacia atrás mientras las páginas también traigan el
        # título (por si está en el encabezado de cada página); al salir de esa racha, ahí arranca.
        pagina_inicio, hit = 0, None
        for i in range(total - 1, -1, -1):
            if progreso:
                print(f"\r  {nombre}: buscando el Anexo de obra pública... página {total - i}/{total}", end='', flush=True)
            tiene = bool(ANEXO_ANCHOR_RE.search(pdf.pages[i].extract_text() or ''))
            if tiene:
                hit = i
            elif hit is not None:
                break
        if hit is not None:
            pagina_inicio = hit
        if progreso:
            print()
        # Paso 2 (más lento pero preciso): extracción con layout solo desde ahí.
        lines = []
        restantes = pdf.pages[pagina_inicio:]
        total2 = len(restantes)
        for j, p in enumerate(restantes):
            if progreso:
                print(f"\r  {nombre}: leyendo tablas del Anexo... página {j + 1}/{total2} "
                      f"({(j + 1) * 100 // total2}%)", end='', flush=True)
            lines.extend((p.extract_text(layout=True) or '').split('\n'))
        if progreso:
            print()
    return recortar_al_anexo(lines)


def recortar_al_anexo(lines):
    """El boletín completo tiene cientos de tablas 'Cuadro X.Y.Z' en otras secciones que NO son las
    que necesitamos. El anexo de obra pública (Decreto 1.295/02 / 691/16) siempre arranca con este
    título; se recorta el texto a partir de ahí."""
    for i, line in enumerate(lines):
        if ANEXO_ANCHOR_RE.search(line):
            return lines[i:]
    return lines          # si no lo encuentra, sigue con todo (boletines viejos, más cortos)


def detectar_rangos_cuadros(lines):
    marcas = []
    for i, line in enumerate(lines):
        m = CUADRO_HEADER_RE.match(line)
        if m:
            marcas.append((i, int(m.group(1))))
    rangos = {}
    for idx, (linea, n) in enumerate(marcas):
        fin = marcas[idx + 1][0] if idx + 1 < len(marcas) else len(lines)
        if n not in rangos:
            rangos[n] = (linea, fin)
        else:
            rangos[n] = (rangos[n][0], fin)
    return rangos


def detectar_fecha_publicacion(lines):
    """(año, mes) de publicación ('Agosto de 2026', en el pie de página) o None."""
    pat = re.compile(r'([A-Za-zÁÉÍÓÚáéíóú]+)\s+de\s+(\d{4})')
    for line in lines:
        m = pat.search(line)
        if m:
            mes = MESES_LARGOS.get(strip_accents(m.group(1).lower()))
            if mes:
                return int(m.group(2)), mes
    return None


def detectar_lista_meses(lines):
    """Fila de encabezados de mes ('Dic Jul Ago Sep ... Jul*') como lista de abreviaturas."""
    for line in lines:
        if MES_HEADER_RE.match(line.strip()):
            return [t.rstrip('*') for t in line.strip().split()]
    return None


def construir_mapa_columnas(lines, pub):
    """Lista de (año, mes) de cada columna de datos, de IZQUIERDA a DERECHA, asumiendo que la
    última columna es el mes de publicación o el anterior."""
    etiquetas = detectar_lista_meses(lines)
    if not etiquetas:
        return []
    ultimo_mes = MESES_TXT[etiquetas[-1].lower()[:3]]
    if pub is not None:
        pub_anio, pub_mes = pub
        anio = pub_anio if ultimo_mes <= pub_mes else pub_anio - 1
    else:
        anio = 2000            # desconocido; solo importa para pedidos explícitos de mes
    resultado = [None] * len(etiquetas)
    mes_actual, anio_actual = ultimo_mes, anio
    resultado[-1] = (anio_actual, mes_actual)
    for i in range(len(etiquetas) - 2, -1, -1):
        mes_prev = MESES_TXT[etiquetas[i].lower()[:3]]
        if mes_prev > mes_actual:
            anio_actual -= 1
        mes_actual = mes_prev
        resultado[i] = (anio_actual, mes_actual)
    return resultado


def valores_en_linea(line):
    return NUM_RE.findall(line)


# ----------------------------------------------------------------------
# Búsqueda de códigos
# ----------------------------------------------------------------------
def normalizar_patron_codigo(codigo):
    """(codigo_limpio | None, patrón). None = inciso del Art. 15 (se busca por su letra)."""
    codigo = codigo.strip()
    m = ART15_INCISO_RE.match(codigo)
    if m:
        letra = m.group(1).lower()
        # En el Cuadro 1 el renglón dice "inciso e)"; en el Cuadro 5 dice solo "a)" al principio
        # del renglón (sin la palabra "inciso", que ahí es un encabezado de columna).
        return None, r'^\s*(?:inciso\s+)?' + re.escape(letra) + r'\s*\)'
    # Nota pegada adelante, ej. "(16)29241": la nota y el código CPC son columnas separadas
    # en la tabla del INDEC -> se busca solo el código real.
    codigo = NOTA_PREFIX_RE.sub('', codigo)
    partes = re.split(r'\s*-\s*', codigo)
    if len(partes) > 1:
        return codigo, r'\s*-\s*'.join(re.escape(p) for p in partes)
    return codigo, re.escape(codigo)


def reconstruir_codigo_oficial(line, match):
    """Texto de la línea hasta el final de lo que matcheó, limpio, para mostrar el código 'tal
    cual' aparece en el INDEC (uniendo columnas: '(16)  2924   29241' -> '(16) 2924 29241')."""
    return re.sub(r'\s+', ' ', line[:match.end()].strip())


def parsear_cuadro4(lines, rango):
    """El Cuadro 4 (incisos c, m, n, q del Art.15) está TRANSPUESTO respecto de los demás: los
    meses van en FILAS y los incisos en COLUMNAS. Devuelve (columnas, filas) con
    columnas = ['c','m','n','q'] y filas = {(año, mes): [valor_c, valor_m, valor_n, valor_q]}."""
    ini, fin = rango
    columnas = []
    filas = {}
    anio_actual = None
    # el año puede venir con asterisco de dato provisorio ('2025* Ene*'): antes no se reconocía y se perdían
    # todos los meses de ese año en los boletines de feb-may 2025
    fila_re = re.compile(r'^\s*(?:(\d{4})\*?\s+)?' + MES_ABREV_RE_C4 + r'\*?\s+(.*)$', re.IGNORECASE)
    for i in range(ini, fin):
        line = lines[i]
        if not columnas:
            letras = re.findall(r'\b([a-zA-Z])\)\s', line)
            if letras:
                columnas = [x.lower() for x in letras]
                continue
        m = fila_re.match(line)
        if m and columnas:
            if m.group(1):
                anio_actual = int(m.group(1))
            mes_abrev = m.group(2).lower()[:3]
            if mes_abrev not in MESES_TXT or anio_actual is None:
                continue
            vals = valores_en_linea(m.group(3))
            if len(vals) >= len(columnas):
                filas[(anio_actual, MESES_TXT[mes_abrev])] = vals[:len(columnas)]
    return columnas, filas


def buscar_cuadro4(lines, rango, letra, ym):
    if ym is None:
        return []
    columnas, filas = parsear_cuadro4(lines, rango)
    if letra not in columnas or ym not in filas:
        return []
    val = filas[ym][columnas.index(letra)]
    return [(0, f'Cuadro 4 -- inciso {letra}) -- {mes_txt(ym)} = {val}', val,
             f'inciso {letra}) [Cuadro 4, {mes_txt(ym)}]')]


def buscar_codigo(lines, rango, codigo, offset, cuadro_num=None, ym=None):
    """Apariciones de 'codigo' en un cuadro. 'offset' = columna contando desde el final
    (0 = último mes del boletín; None = ese mes no está en el boletín).
    Devuelve [(línea, texto_línea, valor_texto, código_oficial)]."""
    ini, fin = rango
    codigo_limpio, core = normalizar_patron_codigo(codigo)
    if cuadro_num == 4 and codigo_limpio is None:
        m_letra = ART15_INCISO_RE.match(codigo.strip())
        if m_letra:
            return buscar_cuadro4(lines, rango, m_letra.group(1).lower(), ym)
    if codigo_limpio is None:
        # Inciso ("inciso e)"): sin límites de palabra estrictos ni exclusión de código compuesto.
        pat = re.compile(core, re.IGNORECASE)
    else:
        tiene_guion = bool(re.search(r'\d\s*-\s*\d', codigo_limpio))
        aplica_exclusion = (not tiene_guion) and (cuadro_num in CUADROS_CODIGO_COMPUESTO)
        # Un código sin guion (ej. "42120") en un cuadro de ítems compuestos NO debe matchear como
        # prefijo de otro ("42120-22"). En cuadros de agregados no aplica.
        sufijo_negativo = r'(?![\w.])(?!\s*-\s*\d)' if aplica_exclusion else r'(?![\w.])'
        pat = re.compile(r'(?<![\w.])' + core + sufijo_negativo)
    resultados = []
    for i in range(ini, fin):
        line = lines[i]
        m = pat.search(line)
        if m:
            vals = valores_en_linea(line)
            if offset is not None and offset >= 0 and len(vals) > offset:
                resultados.append((i, line.strip(), vals[-(offset + 1)], reconstruir_codigo_oficial(line, m)))
    return resultados


def buscar_descripcion(lines, rango, descripcion, offset, n_meses=None):
    """Para insumos que el INDEC publica SIN código (ej. Cuadro 8, 'Yesería (incluye...)'): se busca
    por el comienzo de la descripción. Como puede ocupar varias líneas, los valores se buscan en esa
    línea y las 2 siguientes; solo se acepta la línea que trae TODOS los meses del boletín."""
    if offset is None or offset < 0:
        return []
    ini, fin = rango
    clave = norm_desc(descripcion)[:20]
    if len(clave) < 8:
        return []
    for i in range(ini, fin):
        if clave in norm_desc(lines[i]):
            for j in range(i, min(i + 3, fin)):
                vals = valores_en_linea(lines[j])
                if n_meses and len(vals) != n_meses:
                    continue
                if len(vals) > offset:
                    return [vals[-(offset + 1)]]
    return []


def norm_desc(s):
    """Descripción normalizada (sin acentos, minúscula, sin espacios) para compararla aunque cambie el espaciado."""
    return re.sub(r'\s+', '', strip_accents(texto(s).lower()))


# ----------------------------------------------------------------------
# El boletín, listo para consultar
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# Anexo ya leído, guardado en disco (para no volver a buscarlo en cada análisis)
# ----------------------------------------------------------------------
# Buscar el Anexo y extraer sus tablas es lo que más tarda de un boletín (decenas de páginas con
# layout). Se hace UNA vez, al subirlo a la biblioteca, y el texto del Anexo se guarda en
# datos/anexos_indec/<huella del PDF>.json. Después, cada análisis lo carga al instante.
# La clave es la huella (SHA-1) del CONTENIDO del PDF: no importa dónde esté guardado ni cómo se llame,
# y si el PDF cambia, la huella cambia y se vuelve a leer. Solo se guarda el texto crudo del Anexo: la
# interpretación (cuadros, meses, códigos) se sigue haciendo en cada análisis, así una mejora del
# programa en esa parte se aplica también a los boletines viejos sin tener que volver a subirlos.
VERSION_ANEXO = 1        # subir si cambia leer_pdf_texto() (la forma de EXTRAER el texto)
DIR_ANEXOS = os.environ.get('VERIFICADOR_DIR_ANEXOS') or os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'datos', 'anexos_indec')


def huella_pdf(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for bloque in iter(lambda: f.read(1 << 20), b''):
            h.update(bloque)
    return h.hexdigest()


def _ruta_anexo(huella):
    return os.path.join(DIR_ANEXOS, f"{huella}.json")


def anexo_guardado(path):
    """Líneas del Anexo guardadas para ese PDF, o None si todavía no se leyó (o se leyó con otra versión)."""
    try:
        with open(_ruta_anexo(huella_pdf(path)), encoding='utf-8') as f:
            d = json.load(f)
        if d.get('version') == VERSION_ANEXO and isinstance(d.get('lines'), list):
            return d['lines']
    except (OSError, ValueError):
        pass
    return None


def guardar_anexo(path, lines):
    """Guarda el texto del Anexo (escritura atómica: nunca queda un archivo a medio escribir)."""
    try:
        os.makedirs(DIR_ANEXOS, exist_ok=True)
        destino = _ruta_anexo(huella_pdf(path))
        tmp = destino + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({'version': VERSION_ANEXO, 'nombre': os.path.basename(path), 'lines': lines}, f,
                      ensure_ascii=False)
        os.replace(tmp, destino)
    except OSError:
        pass                  # sin permiso de escritura: se sigue igual, solo que sin guardar


class Boletin:
    """Un PDF del INDEC leído UNA sola vez, con sus cuadros y meses."""

    def __init__(self, path, progreso=True, usar_guardado=True):
        self.path = path
        self.nombre = os.path.basename(path)
        lines = anexo_guardado(path) if usar_guardado else None
        self.desde_guardado = lines is not None
        if lines is None:
            lines = leer_pdf_texto(path, progreso)
        elif progreso:
            print(f"  {self.nombre}: Anexo ya detectado al subirlo (no hace falta buscarlo de nuevo).")
        self.lines = lines
        self.rangos = detectar_rangos_cuadros(self.lines)
        self.pub = detectar_fecha_publicacion(self.lines)
        self.meses = construir_mapa_columnas(self.lines, self.pub)
        if not self.meses:
            raise ErrorVerificacion(
                f"No encontré la fila de meses del Anexo de obra pública en '{self.nombre}'. "
                "¿Es el boletín 'INDEC Informa' (Anexo de precios, Cuadros 1 a 13)?")
        if not self.desde_guardado:
            guardar_anexo(path, self.lines)       # solo si era un boletín válido

    @property
    def ultimo_mes(self):
        return self.meses[-1]

    def offset(self, ym):
        """Columna del mes contando desde el final (0 = último), o None si el mes no está."""
        if ym not in self.meses:
            return None
        return (len(self.meses) - 1) - self.meses.index(ym)

    def texto_meses(self):
        return ', '.join(mes_txt(m) for m in self.meses)

    def buscar(self, codigo, ym, cuadros=None, saltear_c4_no_inciso=False):
        """Todas las apariciones del código para el mes 'ym'.
        cuadros: limitar la búsqueda a esos números de cuadro (None = todos).
        saltear_c4_no_inciso: en el Cuadro 4 (transpuesto) solo buscar incisos del Art. 15."""
        off = self.offset(ym)
        encontrados = []
        for cuadro_num, rango in sorted(self.rangos.items()):
            if cuadros is not None and cuadro_num not in cuadros:
                continue
            if saltear_c4_no_inciso and cuadro_num == 4 and normalizar_patron_codigo(codigo)[0] is not None:
                continue
            for i, linea, val, oficial in buscar_codigo(self.lines, rango, codigo, off, cuadro_num=cuadro_num, ym=ym):
                encontrados.append({'cuadro': cuadro_num, 'linea': linea, 'valor': val, 'codigo_oficial': oficial})
        return encontrados

    def valores(self, codigo, ym, cuadros=None, saltear_c4_no_inciso=False):
        """[(valor numérico, cuadro)] del código en ese mes (todas las apariciones con dato)."""
        from .comunes import num
        out = []
        for m in self.buscar(codigo, ym, cuadros=cuadros, saltear_c4_no_inciso=saltear_c4_no_inciso):
            v = num(m['valor'])
            if v is not None:
                out.append((v, m['cuadro']))
        return out

    def buscar_por_descripcion(self, descripcion, ym, cuadro=None):
        """(valor_texto, cuadro) del insumo publicado sin código, o (None, None)."""
        off = self.offset(ym)
        rangos = {cuadro: self.rangos[cuadro]} if cuadro in self.rangos else self.rangos
        for n, rng in sorted(rangos.items()):
            r = buscar_descripcion(self.lines, rng, descripcion, off, len(self.meses))
            if r:
                return r[0], n
        return None, None


def boletin_para_mes(boletines, ym, elegidos=None):
    """El boletín con el que se verifica un mes: el que el usuario asignó a ese mes (elegidos: {mes: Boletin});
    si ninguno, el boletín cuyo ÚLTIMO mes ES ese mes exactamente (el boletín de noviembre trae los índices
    de octubre: sirve para octubre, no para los meses anteriores que también aparecen en su tabla de
    referencia). Un boletín NUNCA se usa para un mes que no sea el suyo propio, aunque su Anexo muestre el
    dato de ese mes más viejo: ese dato puede haber sido revisado más tarde, así que solo vale el boletín
    publicado específicamente para ese mes."""
    if elegidos and ym in elegidos:
        return elegidos[ym]
    return next((b for b in boletines if b.ultimo_mes == ym), None)

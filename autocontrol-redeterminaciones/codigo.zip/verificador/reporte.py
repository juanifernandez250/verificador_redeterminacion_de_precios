# -*- coding: utf-8 -*-
"""
reporte.py
-----------
Todo lo que sale hacia el usuario: el Excel consolidado ("Verificacion - <archivo>.xlsx"), los
resúmenes por control y el resumen final en pantalla.

Cada control produce un Veredicto (estado + mensaje) para el resumen general.
"""
import datetime as dt
import os

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter as L

from .analisis_precios import _ubicacion, descripcion_hallazgo
from .comunes import (AMARILLO, GRIS, ROJO, VERDE, FONT, Veredicto, anchos, encabezado, fmt_es, mes_txt)
from .costos import descripcion_hallazgo_c
from .observaciones import NOMBRE_CONTROL, NOMBRE_GRAVEDAD

MAX_FILAS = 30000
SIN_COLOR = PatternFill(fill_type=None)
COLOR_ESTADO = {'OK': VERDE, 'REVISAR': ROJO, 'AVISO': AMARILLO, 'OMITIDO': GRIS, 'ERROR': ROJO}
MAX_LINEAS_DETALLE = 40


# ======================================================================
# Veredictos (uno por control)
# ======================================================================
def veredicto_items(res):
    c = res['cuenta']
    prob = c['revisar'] + c['typo'] + c['sin_match']
    t = f"Ítems INDEC {mes_txt(res['ym'])}"
    if prob:
        partes = [f"{c['revisar']} no coinciden" if c['revisar'] else '', f"{c['typo']} con posible error de tipeo en el código" if c['typo'] else '',
                  f"{c['sin_match']} no encontrados en el PDF" if c['sin_match'] else '']
        return Veredicto('items', t, 'REVISAR', f"{prob} código(s) para revisar ({', '.join(p for p in partes if p)}); {c['ok']} OK",
                         n_errores=prob, n_avisos=c['sin_datos'], datos=res)
    if c['sin_datos']:
        return Veredicto('items', t, 'AVISO', f"{c['ok']} coinciden con el INDEC; {c['sin_datos']} sin datos para comparar", n_avisos=c['sin_datos'], datos=res)
    return Veredicto('items', t, 'OK', f"Todo OK: {c['ok']} códigos coinciden con el boletín '{res['boletin']}'", datos=res)


def veredicto_var(res):
    c = res['cuenta']
    meses = ', '.join(mes_txt(m) for m, _ in res['meses'])
    t = f"VAR ({meses})"
    if c['revisar']:
        return Veredicto('var', t, 'REVISAR', f"{c['revisar']} valor(es) no coinciden con la fuente oficial; {c['ok']} OK", n_errores=c['revisar'], n_avisos=c['sin_ref'], datos=res)
    if c['sin_ref']:
        return Veredicto('var', t, 'AVISO', f"{c['ok']} OK; {c['sin_ref']} sin referencia para verificar", n_avisos=c['sin_ref'], datos=res)
    return Veredicto('var', t, 'OK', f"Todo OK: {c['ok']} valores verificados", datos=res)


def _nuevos(errores):
    n = sum(1 for h in errores if str(h.get('version', '')).startswith('NUEVO'))
    return n, len(errores) - n


def veredicto_ap(res, con_prev):
    errores = [h for h in res['hallazgos'] if h['nivel'] == 'ERROR']
    avisos = len(res['hallazgos']) - len(errores)
    t = 'Análisis de precios'
    if errores:
        extra = ''
        if con_prev:
            n, h = _nuevos(errores)
            extra = f" ({n} nuevos, {h} heredados de la versión anterior)"
        return Veredicto('ap', t, 'REVISAR', f"{len(errores)} hallazgo(s) para revisar{extra}", n_errores=len(errores), n_avisos=avisos, datos=res)
    if avisos:
        return Veredicto('ap', t, 'AVISO', f"Sin errores; {avisos} aviso(s)", n_avisos=avisos, datos=res)
    return Veredicto('ap', t, 'OK', 'Sin hallazgos: índices, precios y anticipo financiero coinciden', datos=res)


def veredicto_costos(res, con_prev):
    errores = [h for h in res['hallazgos'] if h['nivel'] == 'ERROR']
    avisos = len(res['hallazgos']) - len(errores)
    sin_vinculo = any(b['vinculo'] is None for x in res['resultados'] for b in x['bloques'])
    t = 'Planilla de costos'
    if errores:
        extra = ''
        if con_prev:
            n, h = _nuevos(errores)
            extra = f" ({n} nuevos, {h} heredados de la versión anterior)"
        return Veredicto('costos', t, 'REVISAR', f"{len(errores)} error(es) para revisar{extra}", n_errores=len(errores), n_avisos=avisos, datos=res)
    if sin_vinculo:
        return Veredicto('costos', t, 'AVISO', 'Sin errores, pero hay bloques que no se pudieron comparar con el análisis', n_avisos=avisos, datos=res)
    if avisos:
        return Veredicto('costos', t, 'AVISO', f"Sin errores; {avisos} aviso(s)", n_avisos=avisos, datos=res)
    return Veredicto('costos', t, 'OK', 'Sin errores: la planilla coincide con el análisis y sus cálculos están bien', datos=res)


# ======================================================================
# Hojas del Excel
# ======================================================================
def _hoja_hallazgos(wb, nombre, hall, cols):
    """cols: [(título, función(h) -> valor, ancho, formato)]. Agrega la columna 'Versión' si hay comparación."""
    ws = wb.create_sheet(nombre)
    con_version = any('version' in h for h in hall)
    spec = ([('Versión', lambda h: h.get('version', ''), 12, None)] if con_version else []) + cols
    encabezado(ws, 1, [c[0] for c in spec])
    orden = {'ERROR': 0, 'AVISO': 1}
    hs = sorted(hall, key=lambda h: (orden.get(h['nivel'], 2), str(h['hoja']), str(h['bloque']), h['fila'] if isinstance(h['fila'], int) else 0))
    for i, h in enumerate(hs[:MAX_FILAS], start=2):
        for j, (tit, fn, _, fm) in enumerate(spec, start=1):
            c = ws.cell(row=i, column=j, value=fn(h))
            if fm:
                c.number_format = fm
            if tit == 'Nivel':
                c.fill = ROJO if h['nivel'] == 'ERROR' else AMARILLO
    if len(hs) > MAX_FILAS:
        ws.cell(row=MAX_FILAS + 3, column=1, value=f"(se muestran los primeros {MAX_FILAS} de {len(hs)} hallazgos)")
    anchos(ws, [c[2] for c in spec])
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = f"A1:{L(len(spec))}{max(2, min(len(hs), MAX_FILAS) + 1)}"
    return ws


def _dif(h):
    vh, ve = h['valor_hoja'], h['valor_esperado']
    return (vh - ve) if isinstance(vh, (int, float)) and isinstance(ve, (int, float)) else None


def _dif_pct(h):
    d = _dif(h)
    return (h['valor_hoja'] / h['valor_esperado'] - 1) if d is not None and h['valor_esperado'] else None


def _celda(h):
    return f"{h['col']}{h['fila']}" if h['fila'] != '' and h['col'] else (h['col'] or '')


COLS_AP = [('Nivel', lambda h: h['nivel'], 8, None), ('Hoja', lambda h: h['hoja'], 14, None), ('Redet.', lambda h: h['bloque'], 8, None),
           ('Celda', _celda, 11, None), ('Nº / Código', lambda h: h['no'], 14, None), ('Insumo', lambda h: h['insumo'], 34, None),
           ('Tipo', lambda h: h['tipo'], 30, None), ('Valor en la hoja', lambda h: h['valor_hoja'], 14, '#,##0.0###'),
           ('Valor correcto', lambda h: h['valor_esperado'], 14, '#,##0.0###'), ('Diferencia', _dif, 12, '#,##0.0###'),
           ('Dif. %', _dif_pct, 9, '0.00%'), ('Causa', lambda h: h['causa'], 36, None), ('Detalle', lambda h: h['detalle'], 60, None)]

COLS_COSTOS = [('Nivel', lambda h: h['nivel'], 8, None), ('Hoja', lambda h: h['hoja'].strip(), 22, None), ('Bloque', lambda h: h['bloque'], 8, None),
               ('Celda', _celda, 10, None), ('Ítem', lambda h: h['item'], 8, None), ('Descripción', lambda h: h['desc'], 36, None),
               ('Tipo', lambda h: h['tipo'], 34, None), ('Valor en la planilla', lambda h: h['valor_hoja'], 16, '#,##0.00'),
               ('Valor correcto', lambda h: h['valor_esperado'], 16, '#,##0.00'), ('Diferencia', _dif, 14, '#,##0.00'),
               ('Dif. %', _dif_pct, 9, '0.00%'), ('Celda del análisis', lambda h: h['celda_analisis'], 26, None),
               ('Detalle', lambda h: h['detalle'], 70, None)]


def _hoja_cambios(wb, nombre, encabezados, filas, anchos_, vacio):
    ws = wb.create_sheet(nombre)
    encabezado(ws, 1, encabezados)
    for i, fila in enumerate(filas[:MAX_FILAS], start=2):
        for j, v in enumerate(fila, start=1):
            ws.cell(row=i, column=j, value=v)
    if not filas:
        ws.cell(row=2, column=1, value=vacio)
    anchos(ws, anchos_)
    ws.freeze_panes = 'A2'


def hoja_items(wb, res):
    ws = wb.create_sheet(f"Items {mes_txt(res['ym'])}")
    encabezado(ws, 1, ['Celda (Excel)', 'Código (tal cual Excel)', 'Código (tal cual INDEC)', 'Excel', 'INDEC', 'Diferencia', 'Estado'])
    for i, f in enumerate(res['filas'], start=2):
        for j, v in enumerate([f['celda'], f['codigo'], f['codigo_oficial'], f['declarado'], f['oficial'], f['dif'], f['estado']], start=1):
            ws.cell(row=i, column=j, value=v)
        ws.cell(row=i, column=6).number_format = '0.00%'
        est = ws.cell(row=i, column=7)
        if f['cat'] == 'ok':
            est.fill = VERDE
        elif f['cat'] == 'revisar':
            est.fill = ROJO
        elif f['cat'] == 'typo':
            est.fill = AMARILLO
        if f['ambiguo']:                       # código ambiguo (aparece en más de un lugar del boletín)
            for cc in range(1, 8):
                ws.cell(row=i, column=cc).fill = AMARILLO
    anchos(ws, [34, 22, 24, 14, 14, 12, 40])
    ws.freeze_panes = 'A2'


def hoja_var(wb, res):
    ws = wb.create_sheet('VAR')
    encabezado(ws, 1, ['Hoja VAR', 'Celda', 'Categoría', 'Referencia INDEC', 'Mes', 'Valor en VAR', 'Valor oficial', 'Fuente', 'Dif. (puntos)', 'Dif. (%)', 'Estado'])
    for i, f in enumerate(res['filas'], start=2):
        for j, v in enumerate([f['hoja'], f['celda'], f['categoria'], f['referencia'], f['mes'], f['valor_var'], f['oficial'], f['fuente'],
                               f['dif_pts'], f['dif_pct'], f['estado']], start=1):
            ws.cell(row=i, column=j, value=v)
        ws.cell(row=i, column=10).number_format = '0.00%'
        est = ws.cell(row=i, column=11)
        est.fill = {'ok': VERDE, 'revisar': ROJO, 'sin_ref': AMARILLO}.get(f['cat'], SIN_COLOR)
    anchos(ws, [12, 14, 30, 34, 11, 14, 14, 26, 13, 10, 48])
    ws.freeze_panes = 'A2'


def hojas_ap(wb, res, cambios, faltan, desalineadas, prev_nombre):
    ws = wb.create_sheet('AP Resumen')
    titulos = ['Hoja', 'Redet.', 'Base → Redet.', 'Insumos', 'Índices OK', 'Índices mal', 'Precios OK', 'Precios mal', 'Cadena cortada',
               'Precio final ≠ cadena correcta', 'A0 esperado (AF)', 'A0 que usan los precios', 'V0 esperado', 'Notas']
    encabezado(ws, 1, titulos)
    ws.row_dimensions[1].height = 32
    r = 2
    for x in res['resumen_agr']:
        vals = [x['hoja'], x['bloque'], f"{mes_txt(x['m_base'])} → {mes_txt(x['m_red'])}", x['insumos'], x['ind_ok'], x['ind_mal'], x['pre_ok'],
                x['pre_mal'], x['cortes'], x['acum_mal'], x['a_esp'], x['a0_ajuste'], x['v_esp'], '; '.join(x['notas'])]
        for i, v in enumerate(vals, start=1):
            c = ws.cell(row=r, column=i, value=v)
            if i in (11, 12, 13) and isinstance(v, float):
                c.number_format = '0.0000%'
        ws.cell(row=r, column=6).fill = ROJO if x['ind_mal'] else VERDE
        ws.cell(row=r, column=8).fill = ROJO if x['pre_mal'] else VERDE
        ws.cell(row=r, column=9).fill = ROJO if x['cortes'] else VERDE
        ws.cell(row=r, column=10).fill = ROJO if x['acum_mal'] else VERDE
        if x['notas']:
            ws.cell(row=r, column=14).fill = AMARILLO
        r += 1
    if prev_nombre is not None:
        r += 1
        ws.cell(row=r, column=1, value='Comparación con la versión anterior').font = Font(name=FONT, bold=True)
        r += 1
        ws.cell(row=r, column=1, value=f"Valores de redeterminaciones anteriores que cambiaron: {len(cambios or [])}").fill = ROJO if cambios else VERDE
        r += 1
        if faltan:
            ws.cell(row=r, column=1, value='Bloques de la versión anterior que ya no están: ' + '; '.join(faltan)).fill = AMARILLO
            r += 1
        if desalineadas:
            ws.cell(row=r, column=1, value=f"{desalineadas} filas con Nº distinto al de la versión anterior (posible reordenamiento).").fill = AMARILLO
    anchos(ws, [24, 9, 22, 10, 11, 11, 11, 11, 11, 14, 14, 14, 13, 60])

    _hoja_hallazgos(wb, 'AP Hallazgos', res['hallazgos'], COLS_AP)

    if res.get('formato') == 'items':          # análisis por hoja de ítem: no hay anticipo que mostrar
        wa = None
    else:
        wa = wb.create_sheet('AP Anticipo (AF)')
    if wa is not None:
        encabezado(wa, 1, ['Redet.', '¿Lo usa el análisis?', 'V1 (precio redet. anterior)', 'V0 (precio de contrato)', '% anticipo', 'A0 recalculado (A.F x V0 / V1)',
                           'A0 escrito en AF', 'A0 escrito en el análisis', 'A0 que usan los precios', 'Estado', 'Notas'])
        a0_hoja, a0_fit = {}, {}
        for x in res['resumen']:
            if x['n_redet']:
                a0_hoja.setdefault(x['n_redet'], x['a0_hoja'])
                a0_fit.setdefault(x['n_redet'], x['a0_ajuste'])
        for i, f in enumerate(res['af_filas'], start=2):
            n = f['n']
            vals = [f"R{n}", 'sí' if f['usado'] else 'no', f['V1'], f['V0'], f['pct'], f['A0_calc'], f['A0_af'], a0_hoja.get(n),
                    a0_fit.get(n) if f['usado'] else None, f['estado'], '; '.join(f['notas'])]
            for j, v in enumerate(vals, start=1):
                c = wa.cell(row=i, column=j, value=v)
                if j in (3, 4) and isinstance(v, float):
                    c.number_format = '#,##0.00'
                if j in (5, 6, 7, 8, 9) and isinstance(v, float):
                    c.number_format = '0.0000%'
            wa.cell(row=i, column=10).fill = VERDE if f['estado'] == 'OK' else (ROJO if f['estado'] == 'REVISAR' else AMARILLO)
        anchos(wa, [8, 12, 22, 22, 10, 18, 14, 16, 16, 18, 70])
        wa.freeze_panes = 'A2'

    if prev_nombre is not None:
        _hoja_cambios(wb, 'AP Cambios vs anterior', ['Hoja', 'Redet.', 'Fila', 'Qué cambió', 'Nº', 'Antes', 'Ahora'],
                      [[c['hoja'], c['bloque'], c['fila'], c['campo'], c['no'], c['antes'], c['ahora']] for c in (cambios or [])],
                      [16, 9, 8, 24, 10, 16, 16], 'Ningún valor de las redeterminaciones anteriores cambió respecto de la versión aprobada.')


def hojas_costos(wb, res, cambios, faltan, prev_nombre):
    ws = wb.create_sheet('Costos Resumen')
    encabezado(ws, 1, ['Hoja', 'Bloque', 'Columnas', 'Ítems', 'Precio = análisis', 'Precio ≠ análisis', 'Ítems sin análisis', 'No comparados', 'Parciales mal',
                       'Rubros mal', 'Cierre mal', 'El precio se toma de…', 'Notas'])
    ws.row_dimensions[1].height = 32
    r = 2
    for x in res['resultados']:
        for b in x['bloques']:
            bb = b['b']
            vals = [x['pl'].hoja.strip(), bb.etiqueta, f"{L(bb.p)}:{L(bb.c_fin)}", b['items'], b['ok'], b['mal'], b['sin_analisis'], b['sin_comparar'],
                    b['parciales_mal'], b['rubros_mal'], b['cierre_mal'], b['vinculo'].describir() if b['vinculo'] else 'no se pudo determinar', '; '.join(b['notas'])]
            for i, v in enumerate(vals, start=1):
                ws.cell(row=r, column=i, value=v)
            ws.cell(row=r, column=6).fill = ROJO if b['mal'] else VERDE
            ws.cell(row=r, column=9).fill = ROJO if b['parciales_mal'] else VERDE
            ws.cell(row=r, column=10).fill = ROJO if b['rubros_mal'] else VERDE
            ws.cell(row=r, column=11).fill = ROJO if b['cierre_mal'] else VERDE
            if b['vinculo'] is None or b['notas']:
                ws.cell(row=r, column=12 if b['vinculo'] is None else 13).fill = AMARILLO
            r += 1
    if prev_nombre is not None:
        r += 1
        ws.cell(row=r, column=1, value=f"Valores de bloques ya presentes que cambiaron: {len(cambios or [])}").fill = ROJO if cambios else VERDE
        if faltan:
            ws.cell(row=r + 1, column=1, value='Bloques de la versión anterior que ya no están: ' + '; '.join(faltan)).fill = AMARILLO
    anchos(ws, [30, 9, 12, 8, 11, 11, 11, 11, 10, 10, 10, 52, 50])

    _hoja_hallazgos(wb, 'Costos Hallazgos', res['hallazgos'], COLS_COSTOS)

    if res.get('desc_distintas'):
        _hoja_cambios(wb, 'Costos Desc. distintas', ['Hoja', 'Fila', 'Ítem', 'Descripción en la planilla', 'Bloque del ítem en el análisis', 'Parecido'],
                      [[d['hoja'].strip(), d['fila'], d['item'], d['desc'], d['celda_analisis'], d['parecido']] for d in res['desc_distintas']],
                      [22, 8, 8, 60, 30, 10], '')
        wd = wb['Costos Desc. distintas']
        for i in range(2, len(res['desc_distintas']) + 2):
            wd.cell(row=i, column=6).number_format = '0%'
        wd.cell(row=len(res['desc_distintas']) + 3, column=1,
                value='El número de ítem coincide con el del análisis pero la descripción es distinta (typos, abreviaturas). '
                      'No son errores de la redeterminación: la comparación de precios se hizo con ese bloque.')

    if prev_nombre is not None:
        _hoja_cambios(wb, 'Costos Cambios vs anterior', ['Hoja', 'Bloque', 'Fila', 'Ítem', 'Descripción', 'Qué cambió', 'Antes', 'Ahora'],
                      [[c['hoja'].strip(), c['bloque'], c['fila'], c['item'], c['desc'], c['campo'], c['antes'], c['ahora']] for c in (cambios or [])],
                      [22, 8, 8, 8, 40, 26, 16, 16], 'Ningún valor de los bloques comparados cambió respecto de la versión aprobada.')


# ======================================================================
# Reporte consolidado
# ======================================================================
ALCANCE = ("Alcance: (1) Ítems INDEC compara cada código de la hoja de índices de la contratista contra el boletín oficial. (2) VAR compara la hoja de "
           "variación de referencia contra el boletín (y la hoja interna como respaldo). (3) Análisis de precios verifica que cada insumo use los índices "
           "de la hoja INDEC del archivo, que los precios se hayan actualizado bien, la cadena entre redeterminaciones y el anticipo financiero. "
           "(4) Planilla de costos verifica que cada ítem tenga el precio del análisis y que los cálculos de la planilla estén bien. "
           "NO verifica precios base, cantidades, ni que cada insumo esté asignado al código INDEC que le corresponde.")


def hojas_observaciones(wb, obs):
    """'Observaciones' (una fila por causa) y 'Correcciones' (una fila por celda, con estado para la segunda vuelta)."""
    from openpyxl.worksheet.datavalidation import DataValidation
    ws = wb.create_sheet('Observaciones')
    encabezado(ws, 1, ['N°', 'Gravedad', 'Control', 'Observación', 'Lugares', 'Valor actual', 'Valor correcto', 'Fuente', 'Impacto directo $', 'Impacto total $',
                       'Causa', 'Qué se encontró', 'Corrección solicitada', 'Estado', 'Comentario de la empresa'])
    color = {'ERROR': ROJO, 'MENOR': AMARILLO, 'AVISO': PatternFill('solid', fgColor='DDEBF7')}
    for i, o in enumerate(obs, start=2):
        vals = [o.id, NOMBRE_GRAVEDAD[o.gravedad], NOMBRE_CONTROL.get(o.control, o.control), o.titulo, o.n, o.actual, o.correcto, o.fuente,
                o.impacto_directo, o.impacto_total, o.causa, o.descripcion, o.accion, 'Pendiente', '']
        for j, v in enumerate(vals, start=1):
            c = ws.cell(row=i, column=j, value=v)
            c.alignment = Alignment(wrap_text=True, vertical='top')
            if j in (9, 10):
                c.number_format = '#,##0.00'
        ws.cell(row=i, column=2).fill = color[o.gravedad]
    anchos(ws, [7, 16, 18, 58, 8, 16, 16, 34, 16, 16, 40, 70, 60, 13, 40])
    ws.freeze_panes = 'E2'
    ws.auto_filter.ref = f"A1:O{max(2, len(obs) + 1)}"
    dv = DataValidation(type='list', formula1='"Pendiente,Corregido,No corresponde"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add(f"N2:N{max(2, len(obs) + 1)}")

    wc = wb.create_sheet('Correcciones')
    encabezado(wc, 1, ['Obs.', 'Gravedad', 'Control', 'Hoja', 'Celda', 'Valor actual', 'Valor correcto', 'Rol', 'Nota', 'Qué corregir', 'Estado', 'Comentario de la empresa'])
    fila = 2
    for o in obs:
        for u in o.ubicaciones:
            vals = [o.id, NOMBRE_GRAVEDAD[o.gravedad], NOMBRE_CONTROL.get(o.control, o.control), u.hoja, u.celda, u.actual, u.correcto,
                    {'origen': 'Origen (corregir acá)', 'propagacion': 'Se actualiza al corregir el origen'}.get(u.rol, ''), u.nota, o.accion, 'Pendiente', '']
            for j, v in enumerate(vals, start=1):
                wc.cell(row=fila, column=j, value=v)
            wc.cell(row=fila, column=2).fill = color[o.gravedad]
            fila += 1
            if fila > MAX_FILAS + 1:
                break
    anchos(wc, [7, 16, 18, 32, 9, 20, 20, 30, 30, 60, 13, 40])
    wc.freeze_panes = 'A2'
    wc.auto_filter.ref = f"A1:L{max(2, fila - 1)}"
    dv2 = DataValidation(type='list', formula1='"Pendiente,Corregido,No corresponde"', allow_blank=True)
    wc.add_data_validation(dv2)
    dv2.add(f"K2:K{max(2, fila - 1)}")


def escribir_reporte(out_path, sesion, veredictos, r, obs=None):
    """sesion: dict con 'excel', 'pdfs', 'prev', 'parametros'. r: resultados por control."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Resumen general'
    ws['A1'] = 'Verificación de la redeterminación'
    ws['A1'].font = Font(name=FONT, bold=True, size=14)
    info = [('Archivo', os.path.basename(sesion['excel'])),
            ('Fecha del análisis', dt.datetime.now().strftime('%d/%m/%Y %H:%M')),
            ('Boletines INDEC', ', '.join(f"{b} ({m})" for b, m in sesion['pdfs']) or 'ninguno'),
            ('Versión anterior comparada', os.path.basename(sesion['prev']) if sesion['prev'] else 'ninguna')]
    info += [(k, v) for k, v in sesion['parametros']]
    row = 3
    for k, v in info:
        ws.cell(row=row, column=1, value=k).font = Font(name=FONT, bold=True)
        ws.cell(row=row, column=2, value=v)
        row += 1
    row += 1
    total_err = sum(v.n_errores for v in veredictos)
    if any(v.estado == 'ERROR' for v in veredictos):
        txt, fill = 'HAY CONTROLES QUE NO SE PUDIERON COMPLETAR (ver detalle)', ROJO
    elif total_err:
        txt, fill = f"{total_err} PUNTO(S) PARA REVISAR", ROJO
    elif any(v.estado in ('AVISO', 'OMITIDO') for v in veredictos):
        txt, fill = 'SIN ERRORES (hay avisos o controles omitidos)', AMARILLO
    else:
        txt, fill = 'SIN HALLAZGOS EN NINGUNO DE LOS CONTROLES', VERDE
    c = ws.cell(row=row, column=1, value=txt)
    c.font = Font(name=FONT, bold=True, size=12)
    c.fill = fill
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
    row += 2
    encabezado(ws, row, ['Control', 'Estado', 'Errores', 'Resultado'])
    row += 1
    for v in veredictos:
        ws.cell(row=row, column=1, value=v.titulo)
        ws.cell(row=row, column=2, value=v.estado).fill = COLOR_ESTADO.get(v.estado, GRIS)
        ws.cell(row=row, column=3, value=v.n_errores)
        ws.cell(row=row, column=4, value=v.mensaje)
        row += 1
    row += 1
    for v in veredictos:
        lineas = lineas_detalle(v, con_prev=bool(sesion['prev']))
        if not lineas:
            continue
        ws.cell(row=row, column=1, value=f"{v.titulo}: primeros {min(len(lineas), 15)} de {len(lineas)} (el detalle completo está en las hojas del control)").font = Font(name=FONT, bold=True)
        row += 1
        for ln in lineas[:15]:
            ws.cell(row=row, column=1, value=ln)
            row += 1
        row += 1
    ca = ws.cell(row=row, column=1, value=ALCANCE)
    ca.alignment = Alignment(wrap_text=True, vertical='top')
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
    ws.row_dimensions[row].height = 95
    anchos(ws, [34, 16, 10, 110])

    if obs:
        hojas_observaciones(wb, obs)
    for res in r.get('items', []):
        hoja_items(wb, res)
    if r.get('var'):
        hoja_var(wb, r['var'])
    if r.get('ap'):
        hojas_ap(wb, r['ap'], r.get('ap_cambios'), r.get('ap_faltan'), r.get('ap_desalineadas', 0), r.get('ap_prev'))
    if r.get('costos'):
        hojas_costos(wb, r['costos'], r.get('costos_cambios'), r.get('costos_faltan'), r.get('costos_prev'))
    wb.save(out_path)


# ======================================================================
# Texto para pantalla
# ======================================================================
def _agrupar_indices(lista, marca):
    """Un índice mal cargado suele repetirse en muchas hojas (mismo código, mismo valor mal): se muestra en UNA
    línea con la cantidad de lugares y los primeros; el Excel trae todas las filas."""
    grupos, salida = {}, []
    for h in lista:
        if h['tipo'] in ('Índice base', 'Índice de la redet.') and isinstance(h['valor_hoja'], float) and isinstance(h['valor_esperado'], float):
            k = (h['tipo'], h['no'], h['valor_hoja'], h['valor_esperado'])
            if k in grupos:
                grupos[k].append(h)
                continue
            grupos[k] = [h]
            salida.append(k)
        else:
            salida.append(h)
    out = []
    for x in salida:
        if isinstance(x, tuple):
            hs = grupos[x]
            if len(hs) == 1:
                out.append(marca(hs[0]) + descripcion_hallazgo(hs[0]))
                continue
            h = hs[0]
            pct = f"{(h['valor_hoja'] / h['valor_esperado'] - 1) * 100:+.2f}".replace('.', ',')
            lugares = ', '.join(_ubicacion(z).replace('PLANILLA N° 6 ', '') for z in hs[:4])
            out.append(f"{marca(h)}[{h['bloque']}]  {h['no']} {h['insumo']} — {h['tipo']}: la hoja dice {fmt_es(h['valor_hoja'], 1)}, debería ser "
                       f"{fmt_es(h['valor_esperado'], 1)} ({pct} %). Se repite en {len(hs)} lugares: {lugares}{', ...' if len(hs) > 4 else ''}")
        else:
            out.append(marca(x) + descripcion_hallazgo(x))
    return out


def lineas_detalle(v, con_prev=False):
    """Una línea por error de un control: dónde está y qué está mal."""
    d = v.datos
    if d is None:
        return []
    if v.clave == 'items':
        out = []
        for f in d['filas']:
            if f['cat'] == 'revisar':
                out.append(f"{f['celda']}  {f['codigo']}: la hoja dice {fmt_es(f['declarado'], 1)}, el INDEC dice {fmt_es(f['oficial'], 1)} "
                           f"({fmt_es(f['dif'] * 100)} %)")
            elif f['cat'] in ('typo', 'sin_match'):
                out.append(f"{f['celda']}  {f['codigo']}: {f['estado']}")
        return out
    if v.clave == 'var':
        return [f"{f['celda']}  {f['categoria']} ({f['mes']}): VAR={fmt_es(f['valor_var'], 1)}  oficial={fmt_es(f['oficial'], 1)}  ({fmt_es(f['dif_pts'], 1)} pts)  [{f['fuente']}]"
                for f in d['filas'] if f['cat'] == 'revisar']
    errores = [h for h in d['hallazgos'] if h['nivel'] == 'ERROR']
    marca = lambda h: f"[{h['version']}] " if con_prev and h.get('version') else ''
    if v.clave == 'ap':
        orden = {t: i for i, t in enumerate(['Índice base', 'Índice de la redet.', 'Nº con error', 'Nº inexistente en INDEC', 'Código con error', 'Código inexistente en INDEC',
                                             'Precio de partida ≠ precio de la redet. anterior', 'Precio del bloque', 'Precio acumulado (vs. cadena correcta)',
                                             'Anticipo financiero (A0)', 'Anticipo financiero (AF)'])}
        lista = sorted(errores, key=lambda h: (str(h['hoja']), orden.get(h['tipo'], 99), str(h['bloque']), h['fila'] if isinstance(h['fila'], int) else 0))
        return _agrupar_indices(lista, marca)
    if v.clave == 'costos':
        return [marca(h) + descripcion_hallazgo_c(h) for h in errores]
    return []


def imprimir_control(v, con_prev=False):
    """Detalle de un control, apenas termina."""
    print(f"\n{'=' * 64}\n{v.titulo.upper()}: {v.estado} -- {v.mensaje}")
    lineas = lineas_detalle(v, con_prev)
    for ln in lineas[:MAX_LINEAS_DETALLE]:
        print(f"  • {ln}")
    if len(lineas) > MAX_LINEAS_DETALLE:
        print(f"  ... y {len(lineas) - MAX_LINEAS_DETALLE} más: están todos en las hojas del reporte.")
    d = v.datos
    if d is not None and v.clave in ('ap', 'costos'):
        avisos = [h for h in d['hallazgos'] if h['nivel'] != 'ERROR']
        f = descripcion_hallazgo if v.clave == 'ap' else descripcion_hallazgo_c
        if avisos:
            print(f"  AVISOS ({len(avisos)}, no son errores):")
            for h in avisos[:8]:
                print(f"    · {f(h)}")
            if len(avisos) > 8:
                print(f"    ... y {len(avisos) - 8} más en el reporte.")
    if d is not None and v.clave == 'var':
        for n in d['notas']:
            print(f"  · {n}")


def imprimir_final(veredictos, out_path, segundos, obs=None, archivos=None):
    print("\n" + "#" * 64)
    print("RESUMEN FINAL")
    print("#" * 64)
    icono = {'OK': '[ OK ]', 'REVISAR': '[REVISAR]', 'AVISO': '[AVISO]', 'OMITIDO': '[omitido]', 'ERROR': '[ERROR]'}
    for v in veredictos:
        print(f" {icono.get(v.estado, v.estado):10} {v.titulo}: {v.mensaje}")
    total = sum(x.n_errores for x in veredictos)
    print("-" * 64)
    omitidos = sum(1 for x in veredictos if x.estado in ('OMITIDO', 'ERROR'))
    extra = f"  (ojo: {omitidos} control(es) sin ejecutar o con error)" if omitidos else ''
    print("RESULTADO: " + (f"{total} PUNTO(S) PARA REVISAR" if total else "SIN ERRORES EN LOS CONTROLES EJECUTADOS") + extra)
    if obs:
        from .observaciones import contar, impacto_total
        n = contar(obs)
        d, t = impacto_total(obs)
        print(f"OBSERVACIONES (agrupadas por causa): {n['ERROR']} error(es), {n['MENOR']} diferencia(s) menor(es), {n['AVISO']} aviso(s)")
        if d:
            print(f"IMPACTO ESTIMADO de lo cuantificable: $ {fmt_es(abs(d))} en costo directo" + (f" (≈ $ {fmt_es(abs(t))} con gastos, beneficio e impuestos)" if t else ''))
    print(f"Análisis completo en {segundos:.0f} s. Archivos generados:")
    for k, v in (archivos if archivos is not None else {'Excel de verificación': out_path}).items():
        print(f"   - {k}: {v}")
    if archivos is not None and not archivos:
        print("   (no se generó ningún archivo: elegiste no guardar ninguno)")
    print("#" * 64)

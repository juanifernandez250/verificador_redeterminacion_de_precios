# -*- coding: utf-8 -*-
"""
formulas.py
------------
Lectura de FÓRMULAS (el resto del programa lee valores). Permite ver la causa de un error, no solo el síntoma:

  1) Fórmulas inconsistentes: en una columna donde casi todas las filas tienen la misma fórmula, la fila que
     se aparta es sospechosa (la típica referencia corrida: V66 = G66*O71 cuando las vecinas hacen V64 = G64*O64).
  2) Valores tipeados: un número escrito a mano en una columna que en las demás filas es una fórmula.
  3) Origen de un dato: si una celda trae el índice con BUSCARV/VLOOKUP sobre una tabla, indica en qué celda de la
     hoja de origen está escrito el valor (que es donde hay que corregirlo).

Solo funciona con .xlsx/.xlsm (un .xls viejo no guarda las fórmulas de forma legible): en ese caso no está disponible.
Se carga una sola vez y solo si se la pide.
"""
import os
import re
from collections import Counter

import openpyxl
from openpyxl.utils import column_index_from_string as CI, get_column_letter as L

from .comunes import ErrorVerificacion, num, texto

_REF = re.compile(r"(?<![A-Za-z0-9_.])(\$?)([A-Z]{1,3})(\$?)(\d{1,7})(?![A-Za-z0-9_(])")
_VLOOKUP = re.compile(r"(?:VLOOKUP|BUSCARV)\(\s*(\$?[A-Z]{1,3}\$?\d+)\s*,\s*([^,]+?)\s*,\s*(\d+)\s*,", re.IGNORECASE)


def firma(formula, fila, col):
    """Fórmula con las referencias expresadas RELATIVAS a su celda: (plantilla, refs). Dos celdas con la misma
    firma hacen 'lo mismo' aunque estén en filas distintas."""
    txt = re.sub(r'"[^"]*"', '""', formula)
    refs = []

    def sub(m):
        cabs, cl, rabs, rw = m.groups()
        c, r = CI(cl), int(rw)
        refs.append((bool(cabs), c if cabs else c - col, bool(rabs), r if rabs else r - fila))
        return '\x00%d\x00' % (len(refs) - 1)
    return re.sub(_REF, sub, txt), tuple(refs)


def _equivalentes(a, b):
    """Dos firmas que hacen la misma cuenta con los operandos en otro orden (=F71*E71 y =E71*F71). Solo vale para
    sumas y productos: en restas, divisiones o potencias el orden cambia el resultado."""
    if a == b:
        return True
    (pa, ra), (pb, rb) = a, b
    if re.search(r'[-/^]', pa + pb):
        return False
    quitar = lambda p: sorted(re.sub('\x00\\d+\x00', '', p))
    return sorted(ra) == sorted(rb) and quitar(pa) == quitar(pb)


def render(f, fila, col):
    """Inversa de firma(): la fórmula que 'le tocaría' a la celda (fila, col)."""
    plantilla, refs = f
    out = plantilla
    for i, (cabs, cv, rabs, rv) in enumerate(refs):
        c = cv if cabs else col + cv
        r = rv if rabs else fila + rv
        out = out.replace('\x00%d\x00' % i, f"{'$' if cabs else ''}{L(max(c, 1))}{'$' if rabs else ''}{max(r, 1)}")
    return out


class Formulas:
    """El libro con fórmulas (no con los valores calculados)."""

    def __init__(self, path):
        ext = os.path.splitext(path)[1].lower()
        if ext not in ('.xlsx', '.xlsm'):
            raise ErrorVerificacion("La lectura de fórmulas solo está disponible para archivos .xlsx/.xlsm.")
        self.path = path
        self.wb = openpyxl.load_workbook(path, data_only=False)
        self._tablas = None

    # ---- celdas
    def raw(self, hoja, fila, col):
        try:
            return self.wb[hoja].cell(row=fila, column=col).value
        except KeyError:
            return None

    def es_formula(self, hoja, fila, col):
        v = self.raw(hoja, fila, col)
        return isinstance(v, str) and v.startswith('=')

    def formula(self, hoja, fila, col):
        v = self.raw(hoja, fila, col)
        return v if isinstance(v, str) and v.startswith('=') else None

    # ---- 1) y 2): filas que se apartan del patrón de su columna
    def apartadas(self, hoja, col, filas, min_formulas=5, umbral=0.6):
        """[{'fila','tipo': 'formula'|'tipeado','actual','esperado'}] de las filas cuya celda no sigue la fórmula
        que usan la mayoría de las filas de la columna. Solo se opina si hay un patrón claro (al menos
        'min_formulas' fórmulas y que el patrón mayoritario sea >= 'umbral' de las celdas con contenido)."""
        firmas, tipeadas = {}, []
        for r in filas:
            v = self.raw(hoja, r, col)
            if isinstance(v, str) and v.startswith('='):
                firmas[r] = firma(v, r, col)
            elif isinstance(v, (int, float)) and not isinstance(v, bool):
                tipeadas.append(r)
        if len(firmas) < min_formulas:
            return []
        patron, n = Counter(firmas.values()).most_common(1)[0]
        if n / (len(firmas) + len(tipeadas)) < umbral:
            return []
        out = []
        for r, f in firmas.items():
            if not _equivalentes(f, patron):
                out.append({'fila': r, 'tipo': 'formula', 'actual': self.formula(hoja, r, col), 'esperado': render(patron, r, col), 'firma': repr(f)})
        for r in tipeadas:
            out.append({'fila': r, 'tipo': 'tipeado', 'actual': self.raw(hoja, r, col), 'esperado': render(patron, r, col)})
        return sorted(out, key=lambda x: x['fila'])

    # ---- 3) origen de un dato traído con BUSCARV / VLOOKUP
    def _tablas_por_nombre(self):
        if self._tablas is None:
            self._tablas = {}
            for ws in self.wb.worksheets:
                for nombre, t in getattr(ws, 'tables', {}).items():
                    ref = t.ref if hasattr(t, 'ref') else t
                    self._tablas[str(nombre).lower()] = (ws.title, str(ref))
        return self._tablas

    def origen(self, hoja, fila, col, valores):
        """(hoja_origen, celda_origen) del dato que trae la fórmula BUSCARV de esa celda, o None.
        valores: el libro con valores calculados (para conocer la clave buscada)."""
        f = self.formula(hoja, fila, col)
        if not f:
            return None
        m = _VLOOKUP.search(f)
        if not m:
            return None
        clave_ref, rango, n = m.group(1).replace('$', ''), m.group(2).strip(), int(m.group(3))
        try:
            clave = valores[hoja][clave_ref].value
        except KeyError:
            return None
        if clave is None:
            return None
        hoja_o, ref = None, None
        t = re.match(r"^([A-Za-z_][\w. ]*)\[\s*\]$", rango)                     # TABLA[]
        if t:
            hoja_o, ref = self._tablas_por_nombre().get(t.group(1).strip().lower(), (None, None))
            desde_fila = 1                                                        # la 1ª fila de la tabla es el encabezado
        else:
            r = re.match(r"^(?:'?([^'!]+)'?!)?\$?([A-Z]{1,3})\$?(\d+):\$?([A-Z]{1,3})\$?(\d+)$", rango)
            if r:
                hoja_o = r.group(1) or hoja
                ref = f"{r.group(2)}{r.group(3)}:{r.group(4)}{r.group(5)}"
                desde_fila = 0
        if not hoja_o or not ref or hoja_o not in valores.sheetnames:
            return None
        a, b = ref.replace('$', '').split(':')
        ma, mb = re.match(r'([A-Z]+)(\d+)', a), re.match(r'([A-Z]+)(\d+)', b)
        c0, r0, r1 = CI(ma.group(1)), int(ma.group(2)), int(mb.group(2))
        ws = valores[hoja_o]
        buscada = texto(clave) if isinstance(clave, str) else clave
        for r_ in range(r0 + desde_fila, r1 + 1):
            v = ws.cell(row=r_, column=c0).value
            if (isinstance(v, str) and isinstance(buscada, str) and v.strip() == buscada.strip()) or \
                    (not isinstance(v, str) and not isinstance(buscada, str) and v is not None and num(v) == num(buscada)):
                return hoja_o, f"{L(c0 + n - 1)}{r_}"
        return None

# -*- coding: utf-8 -*-
"""
var.py  --  CONTROL 2: hoja VAR
--------------------------------
Verifica que los índices de la hoja "VAR" (cálculo de variación de referencia, Tabla III Vivienda -
Decreto 1295/02) coincidan con los valores oficiales del INDEC, comparando contra:
  1) el boletín "INDEC Informa" (PDF), la fuente autoritativa; y/o
  2) la hoja de índices del propio archivo (INDEC / Indices / Indices Seleccionados).

Formatos de planilla soportados (cada contratista arma la suya):
  - La columna de referencia al INDEC (Cuadro / código / descripción) se reconoce por su CONTENIDO
    ("Cuadro N"), no por cómo la tituló la contratista, y puede estar a la derecha o a la izquierda.
  - Si la planilla no trae esa columna, la categoría se deduce por el nombre del insumo.
  - Fechas como fecha de Excel o como texto ("oct-25", "10/2025").
  - Varios bloques de redeterminación en la misma hoja, con filas en blanco dentro del bloque.
  - Insumos sin código (ej. Cuadro 8, Yesería) se buscan por descripción.
"""
import re

from openpyxl.utils import get_column_letter as L

from .comunes import (ErrorVerificacion, TOL_INDICE, barra_progreso, fecha, mes_txt, num,
                      strip_accents, texto)
from .excel import hojas_de_datos
from .pdf_indec import ART15_INCISO_RE, NUM_RE, norm_desc, valores_en_linea


# ----------------------------------------------------------------------
# Utilidades de cuadros y códigos
# ----------------------------------------------------------------------
# "Cuadro 5", "CUADRO 11", "(cuadro 7)", "Cuadro Nº 4" (pero NO "Cuadro 1.4", que es una
# referencia interna al cuadro y no el número de cuadro del INDEC)
CUADRO_CELDA_RE = re.compile(r'^\s*\(?\s*cuadro\s*(?:n[ºo°.]*\s*)?(\d{1,2})\s*\)?\s*$', re.IGNORECASE)


def numero_de_cuadro(txt):
    m = CUADRO_CELDA_RE.match(strip_accents(txt or ''))
    return int(m.group(1)) if m else None


def norm_codigo(s):
    """Normaliza un código INDEC para compararlo: sin la nota '(5)' del
    principio, sin espacios alrededor del guion y en minúscula."""
    s = texto(s)
    s = re.sub(r'^\(\d+\)\s*', '', s)
    s = re.sub(r'\s*-\s*', '-', s)
    return s.strip().lower()


def leer_filas(ws, max_col, max_fila=6000):
    """Lee la hoja a una lista de listas (una por fila) recortando las filas
    vacías del final. Más rápido y simple que consultar celda por celda."""
    filas = []
    ultimo = 0
    limite = min(ws.max_row, max_fila)
    for r in range(1, limite + 1):
        fila = [ws.cell(row=r, column=c).value for c in range(1, max_col + 1)]
        filas.append(fila)
        if any(x is not None for x in fila):
            ultimo = r
    return filas[:ultimo]



# ----------------------------------------------------------------------
# Mapeo "nombre de categoría en VAR" -> inciso del Decreto 1295/02
# (solo se usa cuando la planilla NO trae la columna de referencia INDEC)
# ----------------------------------------------------------------------
MAPA_INCISOS = [
    (r'mano\s*de\s*obra|^m\.?\s*obra', 'a'),
    (r'alba.iler', 'b'),
    (r'pisos.*revestim|revestim.*pisos|^pisos$', 'c'),
    (r'carpinter', 'd'),
    (r'andamio', 'f'),
    (r'artefactos?\s*de?\s*iluminaci|cableado|instalaci.n\s*el.ctrica', 'g'),
    (r'ca.os?\s*(y\s*tubos\s*)?(de\s*)?pvc|instalaciones\s*varias', 'h'),
    (r'acero|hierro\s*aletado', 'm'),
    (r'^cemento', 'n'),
    (r'gastos\s*gral|gastos\s*general', 'p'),
    (r'ba.os?\s*y\s*grifer|grifer.*ba.o|artefactos.*ba.o|instalaci.n\s*sanitaria|artefactos?\s*sanitari', 'r'),
    (r'hormig.n', 's'),
    (r'^arena', 'q'),
    (r'v.lvulas?\s*de\s*bronce|llave\s*esclusa.*bronce|esclusa\s*de\s*bronce', 'u'),
    (r'electrobomba', 'v'),
]

# Categorías que NO son un índice INDEC (se calculan aparte, ej. una tasa
# de costo financiero/bancaria) -- no tiene sentido buscarlas en INDEC.
CATEGORIAS_NO_INDEC = [r'costo\s*financiero', r'ambito\s*financiero']


def inciso_para_categoria(nombre):
    n = strip_accents(nombre.strip().lower())
    for patron in CATEGORIAS_NO_INDEC:
        if re.search(patron, n):
            return 'NO_APLICA'
    for patron, letra in MAPA_INCISOS:
        if re.search(patron, n):
            return letra
    return None


# El Cuadro 1 del INDEC (IPIB) tiene solo estas 6 categorías fijas -- si una
# contratista referencia "Cuadro 1" directamente, identificamos cuál de las
# 6 es por palabras clave de su propia descripción...
CUADRO1_KEYWORDS = [
    (r'quimic', 'e'),
    (r'motor|aparatos?\s*electric|aire\s*acondicionado', 'i'),
    (r'asfalto|combustible|lubricant|petroleo|refinado', 'k'),
    (r'medidor|caudal', 't'),
    (r'membrana|impermeabiliz', 'w'),
    (r'amortiz|maquinas?\s*y\s*equipos?|^equipos?\b', 'j'),
]
# ...o, si la descripción no alcanza, por el "código" que trae ese cuadro
# (ej. 'Cuadro 3.2-24' = productos químicos). Solo se incluyen los tres que
# aparecen en planillas reales; cualquier otro queda sin identificar.
CUADRO1_CODIGOS = {'3.2-24': 'e', '3.2-31': 'i', '3.2-29': 'j'}

_LETRA_INICIAL_RE = re.compile(r'^\s*([a-zA-Z])\s*\)')


def identificar_referencia(referencia):
    """Si la contratista agregó, al lado de cada categoría, la referencia
    exacta al INDEC (Cuadro / código-o-cuadro / descripción -- como hacen
    varias plantillas de IDUV), la usamos en vez de adivinar por el nombre.

    Devuelve {'tipo': 'inciso'|'codigo'|'desc', 'clave': ..., 'cuadro': n|None}
    o None si no se pudo identificar."""
    if not referencia:
        return None
    cuadro_txt = referencia[0] if len(referencia) > 0 else ''
    codigo_txt = (referencia[1] if len(referencia) > 1 else '').strip()
    desc_txt = (referencia[2] if len(referencia) > 2 else '').strip()
    cuadro = numero_de_cuadro(cuadro_txt)

    def res(tipo, clave):
        return {'tipo': tipo, 'clave': clave, 'cuadro': cuadro}

    # Cuadro 4 / Cuadro 5 / etc.: la letra real está al principio de la descripción
    m = _LETRA_INICIAL_RE.match(desc_txt) or ART15_INCISO_RE.match(desc_txt)
    if m:
        return res('inciso', m.group(1).lower())

    # Cuadro 1 (IPIB): 6 categorías fijas
    if cuadro == 1:
        d = strip_accents(desc_txt.lower())
        for patron, letra in CUADRO1_KEYWORDS:
            if re.search(patron, d):
                return res('inciso', letra)
        m = re.search(r'3\.2-(\d+)', codigo_txt)
        if m and ('3.2-' + m.group(1)) in CUADRO1_CODIGOS:
            return res('inciso', CUADRO1_CODIGOS['3.2-' + m.group(1)])

    # Cuadro 4/5 sin la letra explícita en la descripción (ej: "Capítulo Mano
    # de obra", "Ítem Instalación eléctrica") -- la descripción OFICIAL del
    # INDEC es más confiable que el nombre que le puso la contratista.
    # OJO: solo vale para Cuadro 4/5; en Cuadro 3 la descripción larga puede
    # mencionar de paso palabras como "hormigón" sin ser ESE inciso.
    if desc_txt and cuadro in (4, 5):
        letra = inciso_para_categoria(desc_txt)
        if letra and letra != 'NO_APLICA':
            return res('inciso', letra)

    # Código puntual (Cuadro 2, 3, 6, 7, 9, 10, 11, 12, 13...), con o sin
    # nota pegada adelante -- ej: "42120-1", "(5)2695", "291"
    if codigo_txt and re.match(r'^\(?\d', codigo_txt):
        return res('codigo', codigo_txt)

    # Insumos que el INDEC publica sin código (ej. Cuadro 8, Yesería):
    # se identifican por su descripción oficial.
    if desc_txt and cuadro is not None and cuadro not in (1, 4, 5):
        return res('desc', (cuadro, desc_txt))
    return None


def texto_referencia(ref):
    """Texto corto para la columna 'Referencia INDEC' del reporte."""
    if not ref or ref.get('tipo') == 'NO_APLICA':
        return ''
    pref = f"Cuadro {ref['cuadro']} · " if ref.get('cuadro') else ''
    if ref['tipo'] == 'inciso':
        base = f"inciso ({ref['clave']})"
    elif ref['tipo'] == 'codigo':
        base = ref['clave']
    else:
        base = str(ref['clave'][1])[:45]
    if ref.get('origen') == 'nombre':
        base += ' [deducido del nombre]'
    return pref + base


# ----------------------------------------------------------------------
# Detección de hojas
# ----------------------------------------------------------------------
def _filas_con_fechas(ws, filas=200, col_max=30):
    """Filas (dentro de las primeras 'filas') que tienen 2 o más fechas."""
    out = []
    for r in range(1, min(ws.max_row, filas) + 1):
        n = 0
        for c in range(1, min(ws.max_column, col_max) + 1):
            if fecha(ws.cell(row=r, column=c).value):
                n += 1
        if n >= 2:
            out.append(r)
    return out


def detectar_hojas_var(wb):
    candidatas = []
    for n in hojas_de_datos(wb):
        nl = strip_accents(n.lower()).strip()
        if (re.search(r'(?<![a-z])var(?![a-z])', nl) or 'variaci' in nl
                or ('cat' in nl and 'obra' in nl) or 'coeficiente de variacion' in nl):
            candidatas.append(n)
    if candidatas:
        return candidatas
    # Ninguna hoja se llama como las habituales: buscamos por estructura
    # (una fila de fechas con un encabezado "Composición" arriba).
    for n in hojas_de_datos(wb):
        ws = wb[n]
        for r in _filas_con_fechas(ws):
            for rr in range(max(1, r - 4), r + 1):
                for c in range(1, min(ws.max_column, 30) + 1):
                    v = ws.cell(row=rr, column=c).value
                    if isinstance(v, str) and 'composici' in strip_accents(v.lower()):
                        candidatas.append(n)
                        break
                else:
                    continue
                break
            else:
                continue
            break
    return candidatas


def detectar_hojas_indice(wb, excluir=()):
    candidatas = []
    for n in hojas_de_datos(wb):
        if n in excluir:
            continue
        nl = n.lower()
        if 'indec' in nl or 'indic' in nl:
            candidatas.append(n)
    if not candidatas:
        # Sin nombre reconocible: buscamos una hoja que tenga una columna
        # llena de "Cuadro N" (el formato de la hoja de índices de las
        # planillas de análisis de precios).
        for n in hojas_de_datos(wb):
            if n in excluir:
                continue
            ws = wb[n]
            cuenta = {}
            for r in range(1, min(ws.max_row, 400) + 1):
                for c in range(1, min(ws.max_column, 12) + 1):
                    v = ws.cell(row=r, column=c).value
                    if isinstance(v, str) and CUADRO_CELDA_RE.match(strip_accents(v)):
                        cuenta[c] = cuenta.get(c, 0) + 1
            if cuenta and max(cuenta.values()) >= 3 and detectar_fechas_cabecera(ws):
                candidatas.append(n)
    # preferir 'indec'/'indices' crudo antes que 'seleccionados', porque acá
    # buscamos los incisos agregados (Tabla III), que suelen estar en la
    # hoja madre, no en el subconjunto de insumos seleccionados
    candidatas.sort(key=lambda n: 0 if 'selecc' not in n.lower() else 1)
    return candidatas


# ----------------------------------------------------------------------
# Parseo de la hoja VAR: detectar bloques por su fila de fechas
# ----------------------------------------------------------------------
VARIACION_REF_RE = re.compile(r'variaci.n\s+de\s+referencia', re.IGNORECASE)


def _col_referencia_por_cuadros(ws, fila_ini, fila_fin, cols_excluir, max_col):
    """Columna que contiene 'Cuadro N' en las filas de datos (la que más
    coincidencias tenga). No depende de cómo la contratista tituló esa
    columna ('Ubicación Libro INDEC', 'INDICADORES INDEC', 'INDEC'...)."""
    cuenta = {}
    for rr in range(fila_ini, min(fila_fin, ws.max_row) + 1):
        for c in range(1, max_col + 1):
            if c in cols_excluir:
                continue
            v = ws.cell(row=rr, column=c).value
            if isinstance(v, str) and CUADRO_CELDA_RE.match(strip_accents(v)):
                cuenta[c] = cuenta.get(c, 0) + 1
    if not cuenta:
        return None
    return max(cuenta.items(), key=lambda kv: (kv[1], -kv[0]))[0]


def _col_referencia_por_encabezado(ws, r, max_col):
    """Respaldo: buscar una celda de encabezado (1-2 filas arriba de las
    fechas, o en la misma fila) que hable del INDEC."""
    for r_hdr in (r - 1, r, r - 2):
        if r_hdr < 1:
            continue
        for c in range(1, max_col + 1):
            v = ws.cell(row=r_hdr, column=c).value
            if isinstance(v, str):
                t = strip_accents(v.lower())
                if 'indec' in t or 'ubicaci' in t or 'indicador' in t:
                    return c
    return None


def _cols_ref_dejan_lugar_a_etiqueta(ws, r, col_min_valor, cols_ref, filas=15):
    """¿Sigue habiendo, en alguna fila de datos, una columna con texto por fuera de 'cols_ref' antes de
    llegar a las columnas de fecha? Si 'cols_ref' tapa TODO ese espacio, es un falso positivo (ej. una
    leyenda genérica como 'Fuente INDEC' en el encabezado, que no es en realidad una columna de
    Cuadro/código/descripción): hay que descartarla para no perder la etiqueta de cada categoría."""
    if not cols_ref or col_min_valor <= 1:
        return True
    libres = [c for c in range(1, col_min_valor) if c not in cols_ref]
    if not libres:
        return False
    for rr in range(r + 1, min(ws.max_row, r + filas) + 1):
        for c in libres:
            v = ws.cell(row=rr, column=c).value
            if isinstance(v, str) and len(v.strip()) >= 2:
                return True
    return False


def parsear_bloques_var(ws):
    """Devuelve una lista de bloques: cada uno es
    {'fila_fechas': r, 'columnas': {col: (año, mes)}, 'categorias': [...]}
    La etiqueta de cada categoría puede estar en columnas distintas según
    la contratista (columna A, B o C) -- se detecta sola tomando el último
    texto encontrado antes de llegar a las columnas de valores.

    Si el bloque trae la referencia al INDEC (Cuadro / código / descripción
    oficial) la capturamos también: es mucho más confiable que adivinar por
    el nombre que le puso la contratista a cada insumo. La columna se
    reconoce por su CONTENIDO ('Cuadro N'), no por el título."""
    bloques = []
    max_row = ws.max_row
    max_col = min(ws.max_column, 30)
    for r in range(1, max_row + 1):
        columnas_fecha = {}
        for c in range(1, max_col + 1):
            f = fecha(ws.cell(row=r, column=c).value)
            if f:
                columnas_fecha[c] = f
        if len(columnas_fecha) < 2:
            continue
        col_min_valor = min(columnas_fecha.keys())

        col_ref = _col_referencia_por_cuadros(ws, r + 1, r + 80, set(columnas_fecha), max_col)
        if col_ref is None:
            col_ref = _col_referencia_por_encabezado(ws, r, max_col)
        cols_ref = {col_ref, col_ref + 1, col_ref + 2} if col_ref else set()
        if not _cols_ref_dejan_lugar_a_etiqueta(ws, r, col_min_valor, cols_ref):
            col_ref, cols_ref = None, set()

        categorias = []
        rr = r + 1
        sin_valores_seguidas = 0
        limite = min(max_row, r + 250)
        while rr <= limite:
            textos = []
            n_fechas_fila = 0
            for c in range(1, max_col + 1):
                v = ws.cell(row=rr, column=c).value
                if isinstance(v, str) and v.strip():
                    textos.append(v.strip())
                if fecha(v):
                    n_fechas_fila += 1
            # fin del bloque: siguiente encabezado de fechas, fila de
            # "Variación de referencia" o fila "Total"
            if n_fechas_fila >= 2:
                break
            if any(VARIACION_REF_RE.search(strip_accents(t)) for t in textos):
                break

            label = None
            for c in range(1, col_min_valor):
                if c in cols_ref:
                    continue
                v = ws.cell(row=rr, column=c).value
                if isinstance(v, str) and len(v.strip()) >= 2:
                    label = v.strip()
            if label is not None and label.lower().startswith('total'):
                break

            valores = {}
            for c in columnas_fecha:
                v = num(ws.cell(row=rr, column=c).value)
                if v is not None:
                    valores[c] = v

            if label is None or not valores:
                sin_valores_seguidas += 1
                if sin_valores_seguidas >= 2:
                    break
                rr += 1
                continue
            sin_valores_seguidas = 0

            referencia = None
            if col_ref:
                cuadro_txt = texto(ws.cell(row=rr, column=col_ref).value)
                codigo_txt = texto(ws.cell(row=rr, column=col_ref + 1).value)
                desc_txt = texto(ws.cell(row=rr, column=col_ref + 2).value)
                if cuadro_txt or codigo_txt or desc_txt:
                    referencia = [cuadro_txt, codigo_txt, desc_txt]
            categorias.append({'fila': rr, 'nombre': label, 'valores': valores,
                               'referencia': referencia})
            rr += 1
        if categorias:
            bloques.append({'fila_fechas': r, 'columnas': columnas_fecha, 'categorias': categorias})
    return bloques


# ----------------------------------------------------------------------
# Hoja de índices INTERNA del archivo (INDEC / Indices / ...)
# ----------------------------------------------------------------------
INCISO_RE = re.compile(r'^\s*([a-z])\s*\)')


def _extraer_letra_inciso(v):
    """Reconoce tanto el formato 'e)' (como en el PDF) como 'Art.15 Inciso (e)'
    / 'Art 15 inciso (e)' (como usan varias contratistas en su hoja interna
    de índices)."""
    if not isinstance(v, str):
        return None
    v = v.strip()
    m = INCISO_RE.match(v)
    if m:
        return m.group(1).lower()
    m = ART15_INCISO_RE.match(v)
    if m:
        return m.group(1).lower()
    return None


def detectar_fechas_cabecera(ws, filas_busqueda=12, col_max=40):
    columnas = {}
    for r in range(1, filas_busqueda + 1):
        for c in range(1, min(ws.max_column, col_max) + 1):
            f = fecha(ws.cell(row=r, column=c).value)
            if f:
                columnas[c] = f
    return columnas


class IndiceInterno:
    """Índice de la hoja de índices del propio archivo. Se arma UNA sola vez
    (sin límite de filas) y permite buscar el valor de un mes por:
      - código puntual      (ej. '42120-1', '(5)2695')
      - letra de inciso     (ej. 'e' -> 'e) Productos químicos')
      - cuadro + descripción (para los insumos sin código, ej. Cuadro 8)
    La hoja repite el mismo índice en muchos insumos (todos los que usan
    'Aberturas de aluminio', por ejemplo), así que para cada clave se
    guardan todas las filas y se usa la primera que tenga el mes buscado."""

    def __init__(self, ws, nombre):
        self.nombre = nombre
        self.fechas = detectar_fechas_cabecera(ws)
        self.por_codigo = {}
        self.por_letra = {}
        self.por_desc = {}
        self.n_filas = 0
        if self.fechas:
            self._construir(ws)

    def _construir(self, ws):
        max_col = min(ws.max_column, 40)
        filas = leer_filas(ws, max_col)
        # columna 'INDICE' (Cuadro N): la que más celdas 'Cuadro N' tenga
        cuenta = {}
        for fila in filas:
            for c, v in enumerate(fila, start=1):
                if c in self.fechas:
                    continue
                if isinstance(v, str) and CUADRO_CELDA_RE.match(strip_accents(v)):
                    cuenta[c] = cuenta.get(c, 0) + 1
        col_cuadro = max(cuenta.items(), key=lambda kv: (kv[1], -kv[0]))[0] if cuenta else None

        # respaldo (hojas sin columna 'Cuadro N'): la columna de descripción
        # es la que tenga más textos con forma de inciso
        col_desc_legacy = None
        if col_cuadro is None:
            mejor = 0
            for c in range(1, max_col + 1):
                n = sum(1 for fila in filas[:300] if c <= len(fila) and _extraer_letra_inciso(fila[c - 1]))
                if n > mejor:
                    mejor, col_desc_legacy = n, c

        cols_valor = sorted(self.fechas)
        for i, fila in enumerate(filas, start=1):
            valores = {}
            for c in cols_valor:
                if c <= len(fila):
                    n = num(fila[c - 1])
                    if n is not None:
                        valores.setdefault(self.fechas[c], n)
            if not valores:
                continue
            self.n_filas += 1
            info = {'fila': i, 'valores': valores}

            # códigos: todo texto corto de las primeras columnas
            for c in range(1, min(len(fila), 12) + 1):
                v = fila[c - 1]
                if c in self.fechas or v is None:
                    continue
                t = texto(v)
                if t and len(t) <= 30:
                    self.por_codigo.setdefault(norm_codigo(t), []).append(info)

            if col_cuadro is not None:
                desc = texto(fila[col_cuadro + 1]) if col_cuadro + 1 < len(fila) else ''
                cuadro = numero_de_cuadro(texto(fila[col_cuadro - 1]))
                letra = _extraer_letra_inciso(desc)
                if letra is None and cuadro in (4, 5) and desc:
                    # Hay planillas que en la hoja de índices escriben solo
                    # 'Ítem Instalación eléctrica' (sin la letra 'g)'):
                    # la letra se deduce de la descripción oficial.
                    l2 = inciso_para_categoria(desc)
                    if l2 and l2 != 'NO_APLICA':
                        letra = l2
                if desc:
                    self.por_desc.setdefault((cuadro, norm_desc(desc)[:40]), []).append(info)
            else:
                letra = None
                if col_desc_legacy and col_desc_legacy <= len(fila):
                    letra = _extraer_letra_inciso(fila[col_desc_legacy - 1])
            if letra:
                self.por_letra.setdefault(letra, []).append(info)

    @staticmethod
    def _primero_con_mes(infos, ym):
        for info in infos or []:
            v = info['valores'].get(ym)
            if v is not None:
                return v
        return None

    def buscar(self, tipo, clave, ym):
        if tipo == 'inciso':
            return self._primero_con_mes(self.por_letra.get(clave), ym)
        if tipo == 'codigo':
            return self._primero_con_mes(self.por_codigo.get(norm_codigo(clave)), ym)
        if tipo == 'desc':
            cuadro, desc = clave
            k = norm_desc(desc)[:40]
            v = self._primero_con_mes(self.por_desc.get((cuadro, k)), ym)
            if v is None:
                v = self._primero_con_mes(self.por_desc.get((None, k)), ym)
            return v
        return None


# ----------------------------------------------------------------------
# Preparación (sin PDF) y verificación
# ----------------------------------------------------------------------
class PrepVar:
    """Lo que se detectó en el Excel para el control de VAR."""

    def __init__(self, hojas_var, hojas_indice, indices_internos, datos_por_hoja, notas):
        self.hojas_var = hojas_var
        self.hojas_indice = hojas_indice
        self.indices_internos = indices_internos
        self.datos_por_hoja = datos_por_hoja          # {hoja VAR: [bloques]}
        self.notas = notas
        self.meses_var = set()
        for bloques in datos_por_hoja.values():
            for b in bloques:
                self.meses_var.update(b['columnas'].values())


def preparar_var(wb, hojas_var=None):
    """Detecta las hojas VAR y de índices y lee los bloques de la hoja VAR.
    hojas_var: lista de nombres si el usuario las eligió (si no, se detectan)."""
    hojas_var = hojas_var or detectar_hojas_var(wb)
    if not hojas_var:
        raise ErrorVerificacion("No encontré ninguna hoja de variación de referencia (VAR, Cat.de obra, etc.) en este archivo.")
    notas = []
    hojas_indice = detectar_hojas_indice(wb, excluir=hojas_var)
    indices_internos = []
    for h in hojas_indice:
        idx = IndiceInterno(wb[h], h)
        if not idx.fechas:
            notas.append(f"la hoja '{h}' no tiene fechas en su encabezado y se ignora como referencia")
            continue
        indices_internos.append(idx)
    datos = {hv: parsear_bloques_var(wb[hv]) for hv in hojas_var}
    prep = PrepVar(hojas_var, hojas_indice, indices_internos, datos, notas)
    if not prep.meses_var:
        raise ErrorVerificacion("No encontré ninguna fecha en la hoja VAR para saber qué mes comparar.")
    return prep


def clave_categoria(nombre):
    """Nombre de una categoría de la VAR normalizado (para asignarle un índice a mano y reconocerla en
    otras redeterminaciones aunque cambien mayúsculas, tildes o espacios)."""
    return re.sub(r'\s+', ' ', strip_accents(str(nombre or '')).lower()).strip(' .:-')


def aplicar_referencias_manuales(prep, asignadas):
    """Referencias al INDEC que el ADMINISTRADOR asignó a mano a categorías de la VAR que el programa no
    reconocía (o reconocía mal). asignadas: {clave_categoria: {'cuadro': n, 'codigo': '...', 'desc': '...',
    'no_aplica': bool}}. Tiene prioridad sobre lo que dice la planilla. Devuelve cuántas aplicó."""
    if not asignadas:
        return 0
    n = 0
    for bloques in prep.datos_por_hoja.values():
        for b in bloques:
            for cat in b['categorias']:
                a = asignadas.get(clave_categoria(cat['nombre']))
                if not a:
                    continue
                n += 1
                cat['manual'] = True
                if a.get('no_aplica'):
                    cat['no_aplica'] = True
                    continue
                cat['referencia'] = [f"Cuadro {a['cuadro']}" if a.get('cuadro') else '',
                                     str(a.get('codigo') or '').strip(), str(a.get('desc') or '').strip()]
    return n


def _buscar_en_boletin(boletin, ref, ym):
    """(valor_texto, cuadro) o (None, None). Si la planilla dice en qué cuadro está el índice, se
    busca primero en ESE cuadro y solo si no aparece se prueba en los demás."""
    if ref['tipo'] == 'desc':
        cuadro, desc = ref['clave']
        return boletin.buscar_por_descripcion(desc, ym, cuadro)
    codigo = f"Art.15 Inciso ({ref['clave']})" if ref['tipo'] == 'inciso' else ref['clave']
    matches = []
    if ref.get('cuadro') in boletin.rangos:
        matches = boletin.buscar(codigo, ym, cuadros={ref['cuadro']}, saltear_c4_no_inciso=True)
    if not matches:
        matches = boletin.buscar(codigo, ym, saltear_c4_no_inciso=True)
    if matches:
        return matches[0]['valor'], matches[0]['cuadro']
    return None, None


def elegir_objetivos(prep, boletines, meses_boletin):
    """Qué meses de la VAR se verifican y contra qué boletín.
    meses_boletin: [(boletín, mes)] lo que eligió el usuario para cada PDF (por defecto su último mes).
    Se verifica el mes de cada boletín que exista en la hoja VAR (solo ese mes: los de
    redeterminaciones anteriores ya se verificaron en su momento). Si ninguno está en la VAR, se
    verifica el último mes de la VAR contra cualquier boletín que lo traiga (o solo contra la hoja
    interna). Devuelve ([(mes, boletín|None)], notas)."""
    objetivos, notas = [], []
    for b, ym in meses_boletin:
        if ym in prep.meses_var:
            objetivos.append((ym, b))
        else:
            ultimo = max(prep.meses_var)
            notas.append(f"La hoja VAR no tiene el mes {mes_txt(ym)} del boletín '{b.nombre}' "
                         f"(su último mes es {mes_txt(ultimo)}): ese boletín no se usa para la VAR.")
    if not objetivos:
        ultimo = max(prep.meses_var)
        b = next((b for b in boletines if b.ultimo_mes == ultimo), None)
        objetivos = [(ultimo, b)]
        if meses_boletin:
            notas.append(f"Se compara el último mes de la hoja VAR ({mes_txt(ultimo)}); "
                         + (f"contra el boletín '{b.nombre}'." if b else "ningún boletín lo trae: solo contra la hoja interna del archivo."))
    return objetivos, notas


def verificar_var(prep, boletines, meses_boletin, progreso=True):
    """Compara la hoja VAR contra los boletines (fuente autoritativa) y contra la hoja interna."""
    objetivos, notas = elegir_objetivos(prep, boletines, meses_boletin)
    notas = list(prep.notas) + notas
    filas = []
    for ym, boletin in objetivos:
        # (hoja, categoría, columna del mes, valor) SOLO para este mes, sin repetir una categoría
        # que aparezca en más de un bloque de la hoja VAR
        a_procesar, vistas = [], set()
        for hv in prep.hojas_var:
            for b in prep.datos_por_hoja[hv]:
                for cat in b['categorias']:
                    for c, valor_var in cat['valores'].items():
                        if b['columnas'][c] != ym:
                            continue
                        clave = (hv, cat['nombre'].strip().lower(), tuple(cat.get('referencia') or ()))
                        if clave in vistas:
                            continue
                        vistas.add(clave)
                        a_procesar.append((hv, cat, c, valor_var))
        for n, (hv, cat, c, valor_var) in enumerate(a_procesar, start=1):
            if progreso:
                barra_progreso(n, len(a_procesar), prefijo=f'  VAR {mes_txt(ym)}')
            otros = [b for b in boletines if b is not boletin and b.ultimo_mes == ym]
            filas.append(_verificar_categoria(prep, boletin, otros, ym, hv, cat, c, valor_var))
    cuenta = {k: sum(1 for f in filas if f['cat'] == k) for k in ('ok', 'revisar', 'sin_ref', 'no_aplica')}
    return {'filas': filas, 'cuenta': cuenta, 'notas': notas,
            'meses': [(ym, b.nombre if b else None) for ym, b in objetivos],
            'hojas_var': prep.hojas_var, 'hojas_indice': prep.hojas_indice}


def _valor_en_boletin(boletin, ref, ym):
    """(valor, cuadro) según la referencia (código / inciso / descripción), o None."""
    txt, cuadro = _buscar_en_boletin(boletin, ref, ym)
    v = num(txt) if txt is not None else None
    return (v, cuadro) if v is not None else None


def _descripcion_de_linea(lines, i):
    """Texto de la fila (sin los números). Si la descripción quedó en la línea de arriba, se toma de ahí."""
    t = re.sub(r'\s+', ' ', NUM_RE.sub('', lines[i])).strip(' -')
    if len(t) < 6 and i > 0:
        t = (re.sub(r'\s+', ' ', NUM_RE.sub('', lines[i - 1])).strip(' -') + ' ' + t).strip()
    return t[:60]


def _buscar_por_valor(boletin, valor, ym, cuadro=None):
    """Para categorías cuya planilla no trae código (solo 'cuadro N', o nada): busca en el boletín la fila
    cuyo valor de ese mes coincide con el de la VAR. Devuelve (cuadro, descripción, aviso) o None.
    Se mira primero el cuadro que dice la planilla y, si ahí no está, los demás."""
    off = boletin.offset(ym)
    if off is None:
        return None

    def en(cuadros):
        for cu in cuadros:
            if cu == 4 or cu not in boletin.rangos:          # el Cuadro 4 está transpuesto (meses en filas)
                continue
            ini, fin = boletin.rangos[cu]
            for i in range(ini, fin):
                vals = valores_en_linea(boletin.lines[i])
                if len(vals) != len(boletin.meses):           # solo filas completas (con todos los meses)
                    continue
                v = num(vals[-(off + 1)])
                if v is not None and abs(v - valor) <= TOL_INDICE:
                    return cu, _descripcion_de_linea(boletin.lines, i)
        return None
    if cuadro in boletin.rangos:
        hit = en([cuadro])
        if hit:
            return hit[0], hit[1], ''
    hit = en(sorted(boletin.rangos))
    if hit:
        return hit[0], hit[1], (f" (la planilla dice Cuadro {cuadro})" if cuadro else '')
    return None


def _cuadro_de_referencia(referencia):
    return numero_de_cuadro(referencia[0]) if referencia else None


def _verificar_categoria(prep, boletin, otros, ym, hv, cat, col, valor_var):
    """boletin: el de este mes (octubre -> el boletín de noviembre). otros: los demás boletines que también traen
    ese mes; SOLO se usan para avisar que traen otro valor, nunca para dar por bueno un dato."""
    letra_nombre = inciso_para_categoria(cat['nombre'])
    solo_cuadro = None
    if cat.get('no_aplica'):
        letra_nombre = 'NO_APLICA'           # el administrador indicó que no es un índice del INDEC
    elif cat.get('manual'):
        letra_nombre = None                  # se usa SOLO la referencia asignada a mano, no el nombre
    if letra_nombre == 'NO_APLICA':
        ref = {'tipo': 'NO_APLICA'}
    else:
        # ¿qué índice del INDEC es? -> 1º por la referencia que escribió la contratista (columna
        # Cuadro/código/descripción); 2º por el valor (si solo dice el cuadro); 3º por el nombre
        ref = identificar_referencia(cat.get('referencia'))
        if ref is None:
            solo_cuadro = _cuadro_de_referencia(cat.get('referencia'))

    fila = {'hoja': hv, 'categoria': cat['nombre'], 'referencia': texto_referencia(ref) or (f"Cuadro {solo_cuadro}" if solo_cuadro else ''),
            'mes': mes_txt(ym), 'ym': ym, 'celda': f"{hv}!{L(col)}{cat['fila']}", 'valor_var': valor_var, 'oficial': None,
            'fuente': None, 'dif_pts': None, 'dif_pct': None, 'cat': '', 'estado': '',
            'boletin': boletin.nombre if boletin is not None else None, 'cuadro': None, 'otro': None,
            'manual': bool(cat.get('manual'))}
    if ref is not None and ref['tipo'] == 'NO_APLICA':
        return dict(fila, cat='no_aplica', estado='NO ES ÍNDICE INDEC (no se verifica)')

    fuentes = [boletin] if boletin is not None else []
    if ref is None:
        for b in fuentes:
            hit = _buscar_por_valor(b, valor_var, ym, solo_cuadro)
            if hit:
                cu, desc, aviso = hit
                return dict(fila, referencia=f"Cuadro {cu}: {desc}", oficial=valor_var, cuadro=cu, fuente=f"PDF INDEC (Cuadro {cu}) [identificado por valor{aviso}]",
                            dif_pts=0.0, dif_pct=0.0, cat='ok', estado='OK')
        if letra_nombre:
            ref = {'tipo': 'inciso', 'clave': letra_nombre, 'cuadro': None, 'origen': 'nombre'}
            fila['referencia'] = texto_referencia(ref)
    if ref is None:
        return dict(fila, cat='sin_ref', estado="No reconocí a qué código/inciso del INDEC corresponde esta categoría")

    # se compara con el boletín de ESTE mes
    oficial, fuente, cuadro = None, None, None
    r = _valor_en_boletin(boletin, ref, ym) if boletin is not None else None
    if r:
        oficial, fuente, cuadro = r[0], f"PDF INDEC (Cuadro {r[1]})", r[1]
    # si no está en el PDF (o no hay PDF), la hoja interna del archivo
    if oficial is None:
        for idx in prep.indices_internos:
            v = idx.buscar(ref['tipo'], ref['clave'], ym)
            if v is not None:
                oficial, fuente = v, f"Hoja interna ({idx.nombre})"
                break
    if oficial is None:
        desc_ref = texto_referencia(ref) or cat['nombre']
        msg = f"Sin referencia para '{desc_ref}' en el mes {mes_txt(ym)}"
        msg += " (ni en el PDF ni en el archivo)" if boletin is not None else " en este archivo -- probá con el PDF del INDEC"
        return dict(fila, cat='sin_ref', estado=msg)

    dif_pct = (valor_var - oficial) / oficial if oficial != 0 else None
    ok = abs(valor_var - oficial) <= TOL_INDICE
    otro = None
    if not ok and fuente.startswith('PDF'):
        for b2 in otros:                            # solo informativo
            r2 = _valor_en_boletin(b2, ref, ym)
            if r2:
                fuente += f" | ojo: '{b2.nombre}' también trae {mes_txt(ym)}: {r2[0]:g}"
                otro = (b2.nombre, r2[0])
                break
    return dict(fila, cuadro=cuadro, otro=otro, oficial=oficial, fuente=fuente, dif_pts=round(valor_var - oficial, 4), dif_pct=dif_pct,
                cat='ok' if ok else 'revisar', estado='OK' if ok else 'REVISAR')

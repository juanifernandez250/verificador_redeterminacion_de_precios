# -*- coding: utf-8 -*-
"""
cache_anterior.py
------------------
Lo que se analiza de la VERSIÓN ANTERIOR (aprobada) para comparar, guardado en disco.

La versión anterior no cambia más, pero antes se abría y se analizaba entera en cada análisis de la
redeterminación nueva. Ahora el resultado de ese análisis se guarda en datos/cache_anteriores/ y la
próxima vez se carga al instante (sin siquiera abrir ese Excel).

Se vuelve a calcular solo si cambia algo que podría cambiar el resultado:
  - el CONTENIDO del Excel anterior (huella SHA-1 del archivo, no su nombre ni su fecha), o
  - el CÓDIGO del programa (huella de todos los .py de esta carpeta): una versión nueva del
    programa nunca usa resultados calculados por una versión vieja.
"""
import glob
import hashlib
import os
import pickle

DIR_CACHE = os.environ.get('VERIFICADOR_DIR_CACHE_ANTERIORES') or os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'datos', 'cache_anteriores')

_FIRMA = None
_HUELLAS = {}


def firma_codigo():
    """Huella del código del programa (cambia con cualquier cambio en verificador/*.py)."""
    global _FIRMA
    if _FIRMA is None:
        h = hashlib.sha1()
        for p in sorted(glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), '*.py'))):
            h.update(os.path.basename(p).encode())
            with open(p, 'rb') as f:
                h.update(f.read())
        _FIRMA = h.hexdigest()
    return _FIRMA


def huella_archivo(path):
    """SHA-1 del contenido, recordada por (ruta, tamaño, fecha) para no releer el archivo cada vez."""
    try:
        st = os.stat(path)
    except OSError:
        return None
    clave = (os.path.abspath(path), st.st_size, st.st_mtime)
    if clave not in _HUELLAS:
        h = hashlib.sha1()
        with open(path, 'rb') as f:
            for bloque in iter(lambda: f.read(1 << 20), b''):
                h.update(bloque)
        _HUELLAS[clave] = h.hexdigest()
    return _HUELLAS[clave]


def _ruta(path, tipo, extra):
    hx = huella_archivo(path)
    if hx is None:
        return None
    k = hashlib.sha1(f"{hx}|{firma_codigo()}|{tipo}|{extra}".encode('utf-8')).hexdigest()
    return os.path.join(DIR_CACHE, f"{tipo}_{k}.pkl")


def cargar(path, tipo, extra=''):
    ruta = _ruta(path, tipo, extra)
    if not ruta or not os.path.exists(ruta):
        return None
    try:
        with open(ruta, 'rb') as f:
            return pickle.load(f)
    except Exception:
        return None                     # archivo dañado o de otra versión de Python: se recalcula


def guardar(path, tipo, extra, obj):
    ruta = _ruta(path, tipo, extra)
    if not ruta:
        return
    try:
        os.makedirs(DIR_CACHE, exist_ok=True)
        tmp = ruta + '.tmp'
        with open(tmp, 'wb') as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(tmp, ruta)
    except Exception:
        try:
            os.remove(ruta + '.tmp')
        except OSError:
            pass                        # no se pudo guardar: se sigue igual, solo que sin guardar

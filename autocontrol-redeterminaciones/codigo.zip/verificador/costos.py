# -*- coding: utf-8 -*-
"""
costos.py  --  CONTROL 4: planilla de costos
---------------------------------------------
Verifica la PLANILLA DE COSTOS de una redeterminación (la base y cada redeterminación):
  1) que cada ítem tenga el precio que le corresponde según el ANALISIS DE PRECIOS. El programa ubica el
     bloque de cada ítem en el análisis (por número y descripción) y aprende, mirando todos los ítems, de
     qué fila y columna sale el precio de cada bloque; los ítems que se desvían son el error.
  2) que los cálculos de la planilla estén bien: parcial = cantidad x precio, subtotal de cada rubro,
     total de costo, gastos generales / beneficio / impuestos y total final.
  3) (opcional) contra la VERSION ANTERIOR aprobada: marca cada error como NUEVO o HEREDADO.
No revisa los índices ni el análisis de precios (para eso está el control 3).

Las columnas se reconocen por su contenido (parcial = cantidad x precio), no por su título.

Funciones principales:
    detectar_planillas(ctx, hoja=None)                       -> (planillas, hojas_de_analisis)
    analizar_costos(ctx, planillas, hojas_analisis, sel...)  -> resultado
    comparar_versiones_costos(act, ant)                      -> (cambios, faltan)
"""
import re
from collections import Counter

from openpyxl.utils import get_column_letter as L

from .comunes import (TOL_PRECIO_ABS, TOL_PRECIO_REL, ErrorVerificacion, barra_progreso, fmt_es, num,
                      strip_accents, texto)
from .excel import Grilla, hojas_de_datos
from .seleccion import bloque_seleccionado

TOL_PARCIAL_ABS = TOL_PRECIO_ABS          # un centavo
TOL_PARCIAL_REL = TOL_PRECIO_REL


# ======================================================================
# PLANILLA DE COSTOS: lectura (ítems, rubros y bloques de redeterminación)
# ======================================================================
ID_RE = re.compile(r'^\d{1,3}(\.\d{1,3})*$')


def id_texto(v):
    """'1.1' si la celda es un número de ítem (texto o número); si no, None.
    El separador puede ser punto o coma ('13.20' = '13,20') y el número puede terminar en punto ('1.' = '1')."""
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        s = str(int(v)) if float(v) == int(v) else repr(float(v))
    else:
        s = re.sub(r'\s*[.,]\s*', '.', str(v).strip()).rstrip('.')
    return s if ID_RE.match(s) else None


class BloquePl:
    """Un bloque de precios de la planilla: base o una redeterminación (columnas precio unitario -> parcial -> ...)."""
    def __init__(self, hoja, p, t, c_fin):
        self.hoja, self.p, self.t, self.c_fin = hoja, p, t, c_fin
        self.n_redet = None
        self.titulo = ''
        self.seleccionado = True
        self.col_amount = None        # columna donde están los subtotales de rubro / totales
        self.pct_cols = []

    @property
    def col_ini(self):
        return self.p

    @property
    def c_precio(self):
        return self.c_fin

    @property
    def etiqueta(self):
        return 'Base' if self.n_redet == 0 else f"R{self.n_redet}"


class Planilla:
    def __init__(self, hoja):
        self.hoja = hoja
        self.grilla = None
        self.idc = None
        self.qc = None
        self.items = []          # hojas del árbol: {'r','id','desc','unidad','cant'}
        self.padres = []         # rubros / subrubros: {'r','id','desc','hijos':[filas hoja]}
        self.bloques = []
        self.ultima_fila_item = 0
        self.desc_distintas = []      # ítems que se vincularon con el análisis por número aunque la descripción difiere

    def por_id(self):
        return {x['id']: x for x in self.items}


_RE_TIT_REDET = re.compile(r'(\d+)\s*[º°o]?\s*\.?\s*redet|redet\w*\s*(?:n\s*[º°o]?\s*)?(\d+)', re.IGNORECASE)


def _numero_redet_titulo(txt):
    m = _RE_TIT_REDET.search(strip_accents(txt))
    if m:
        return int(m.group(1) or m.group(2))
    return None


def leer_planilla(grilla, nombre_hoja):
    """Reconoce la planilla por su CONTENIDO: una columna de números de ítem con descripción al lado y
    pares de columnas (precio unitario -> parcial) donde parcial = cantidad x precio. Devuelve Planilla o None."""
    g = grilla
    max_r = min(g.nrows, 3000)
    max_c = min(g.ncols, 260)
    cuenta = {}
    for c in range(1, 7):
        n = 0
        for r in range(1, max_r + 1):
            if id_texto(g.v(r, c)) and isinstance(g.v(r, c + 1), str):
                n += 1
        cuenta[c] = n
    idc = max(cuenta, key=lambda c: cuenta[c])
    if cuenta[idc] < 5:
        return None
    filas = []
    vistos = set()
    for r in range(1, max_r + 1):
        i = id_texto(g.v(r, idc))
        d = g.v(r, idc + 1)
        if i and isinstance(d, str):
            if isinstance(g.v(r, idc), float):          # 1.10 escrito como número queda 1.1: se corrige por orden
                while i in vistos:
                    i += '0'
            vistos.add(i)
            filas.append({'r': r, 'id': i, 'desc': d.strip()})
    candidatas = [x for x in filas if '.' in x['id']]
    if len(candidatas) < 5:
        return None
    # -- cantidad y pares (precio unitario, parcial)
    nums = {x['r']: {c: g.n(x['r'], c) for c in range(1, max_c + 1)} for x in candidatas}
    mejor = None
    for q in range(idc + 1, idc + 9):
        pares = []
        for p in range(q + 1, max_c):
            for t in range(p + 1, min(p + 4, max_c + 1)):
                ok = tot = 0
                for x in candidatas:
                    d = nums[x['r']]
                    qq, pp, tt = d.get(q), d.get(p), d.get(t)
                    if qq and pp and tt is not None:
                        tot += 1
                        if abs(tt - qq * pp) <= TOL_PARCIAL_ABS + TOL_PARCIAL_REL * abs(tt):
                            ok += 1
                if tot >= 5 and ok / tot >= 0.8:
                    pares.append((p, t, ok / tot, tot))
        if pares and (mejor is None or len(pares) > len(mejor[1])):
            mejor = (q, pares)
    if not mejor:
        return None
    q, pares = mejor
    pl = Planilla(nombre_hoja)
    pl.grilla, pl.idc, pl.qc = g, idc, q
    por_p = {}
    for p, t, fr, tot in pares:
        if tot >= 0.6 * len(candidatas):
            por_p.setdefault(p, t)
    if not por_p:
        return None
    for x in candidatas:
        cant = g.n(x['r'], q)
        if cant is None or cant == 0:
            continue
        x['cant'] = cant
        x['unidad'] = texto(g.v(x['r'], idc + 2))
        pl.items.append(x)
    hojas_ids = {x['id'] for x in pl.items}
    for x in filas:
        if x['id'] in hojas_ids:
            continue
        hijos = [y for y in pl.items if y['id'].startswith(x['id'] + '.')]
        pl.padres.append({'r': x['r'], 'id': x['id'], 'desc': x['desc'], 'hijos': hijos})
    pl.ultima_fila_item = max((x['r'] for x in pl.items), default=0)
    # Cada rubro abarca las filas que le siguen hasta el próximo rubro del mismo nivel o superior. Se define por POSICIÓN
    # (no por número) para que un ítem con el número mal escrito ('13,8') siga contando en su rubro.
    pl.padres.sort(key=lambda p: p['r'])
    filas_padre = {p['r'] for p in pl.padres}
    for k, p in enumerate(pl.padres):
        nivel = p['id'].count('.')
        fin = pl.ultima_fila_item + 1
        for q in pl.padres[k + 1:]:
            if q['id'].count('.') <= nivel:
                fin = q['r']
                break
        p['rango'] = (p['r'] + 1, fin - 1)
    pl.filas_padre = filas_padre
    # -- bloques: uno por columna de precio unitario, ordenados de izquierda a derecha
    ps = sorted(por_p)
    for k, p in enumerate(ps):
        c_fin = (ps[k + 1] - 1) if k + 1 < len(ps) else min(max_c, por_p[p] + 4)
        pl.bloques.append(BloquePl(nombre_hoja, p, por_p[p], c_fin))
    # -- numeración: por el título ("REDETERMINACION N° 2") si está; si no, por orden (el primero es la base)
    primera = min(x['r'] for x in pl.items)
    for k, b in enumerate(pl.bloques):
        # El título suele estar encima del precio unitario, pero muchas planillas lo escriben en el borde
        # izquierdo del bloque (sobre la columna "N°", varias columnas antes del precio: ej. Proalsa,
        # "…(4° REDET. PRECIOS)" en AG con el precio en AK). Primero se busca cerca del precio y después
        # hacia la izquierda, sin pasar la columna de precio del bloque anterior.
        tope = pl.bloques[k - 1].p + 1 if k > 0 else 1
        fin = min(b.p + 3, pl.bloques[k + 1].p - 1) if k + 1 < len(pl.bloques) else b.p + 3
        columnas = [b.p] + list(range(b.p + 1, fin + 1)) + list(range(b.p - 1, max(tope, b.p - 8) - 1, -1))
        for c in columnas:
            if b.titulo:
                break
            for r in range(max(1, primera - 15), primera):
                v = g.v(r, c)
                if isinstance(v, str) and v.strip():
                    n = _numero_redet_titulo(v)
                    if n is not None:
                        b.titulo, b.n_redet = v.strip(), n
                        break
    if pl.bloques and pl.bloques[0].n_redet is None:
        pl.bloques[0].n_redet = 0                 # el primer bloque sin título de redeterminación es la base
    usados = {b.n_redet for b in pl.bloques if b.n_redet is not None}
    sig = 1
    for b in pl.bloques:
        if b.n_redet is None:
            while sig in usados:
                sig += 1
            b.n_redet = sig
            usados.add(sig)
    return pl

# ======================================================================
# VÍNCULO CON EL ANÁLISIS DE PRECIOS: ¿cada ítem tiene el precio que le corresponde?
# ======================================================================
KW_PRECIO = ('costo', 'precio', 'total', 'neto', 'unitario', 'directo')


def norm_tokens(s):
    s = strip_accents(str(s).lower())
    return re.sub(r'[^a-z0-9 ]+', ' ', s).split()


def _mismo_texto(a, b):
    """¿Dos descripciones son la misma (sin importar mayúsculas, acentos, espacios ni signos)?"""
    return bool(norm_tokens(a)) and norm_tokens(a) == norm_tokens(b)


def similitud(a, b):
    A, B = set(norm_tokens(a)), set(norm_tokens(b))
    if not A or not B:
        return 0.0
    return len(A & B) / min(len(A), len(B))


class Ancla:
    def __init__(self, hoja, fila, col, sim, confirmada):
        self.hoja, self.fila, self.col, self.sim, self.confirmada = hoja, fila, col, sim, confirmada
        self.id_analisis = None        # si se ubicó por DESCRIPCIÓN porque el número no coincide: el número que tiene en el análisis


_ITEM_ROTULO_RE = re.compile(r'^\s*[íi]tem\s*(?:n\s*[º°o]?\s*)?[:.\-]?\s*(\d+(?:\s*[.,]\s*\d+)*)\s*[.:\-]?\s*(.*)$', re.IGNORECASE)


def id_de_celda_analisis(v):
    """(número de ítem, texto que sigue) de una celda del análisis de precios. Acepta la celda con el número solo
    ('1.2', '3.1.5', '3,1,2') o con el rótulo pegado ('ITEM: 1.2', 'Ítem Nº 1.2 - Desmonte'), como la escriben varias
    empresas. También tolera signos al final del número ('3.1.5-', '3.1.5)', '3.1.5:')."""
    i = id_texto(v)
    if i:
        return i, ''
    if isinstance(v, str):
        i = id_texto(re.sub(r'[\s\-:;)\]]+$', '', v.strip()))
        if i:
            return i, ''
    if isinstance(v, str):
        m = _ITEM_ROTULO_RE.match(strip_accents(v))
        if m:
            i = id_texto(m.group(1))
            if i:
                return i, m.group(2).strip()
    return None, ''


def buscar_anclas(grillas, pl):
    """Ubica el bloque de cada ítem de la planilla dentro del análisis: la celda con el número de ítem y, en esa
    fila, un texto parecido a la descripción. Si la descripción no se parece pero el número es inequívoco, se
    acepta como 'no confirmada' (y se avisa)."""
    por_id = {}
    for x in pl.items:
        por_id.setdefault(x['id'], []).append(x)
    cand = {}
    encabezados = []                 # (hoja, fila, col, número, texto) de cada número de ítem del análisis (para la 2.ª pasada)
    for n, g in grillas.items():
        for r in range(1, g.nrows + 1):
            fila = g.filas[r - 1]
            for c in range(1, min(8, len(fila)) + 1):
                v = fila[c - 1]
                i, resto = id_de_celda_analisis(v)
                if not i:
                    continue
                encabezados.append((n, r, c, i, resto))
                variantes = {i}
                if isinstance(v, float):
                    variantes.add(i + '0')
                if i.endswith('0'):
                    variantes.add(i.rstrip('0'))
                for cid in variantes:
                    for x in por_id.get(cid, []):
                        mejor, hay_texto = 0.0, False
                        if len(resto) > 3 or _mismo_texto(resto, x['desc']):   # 'Ítem 1.2 - Desmonte': descripción en la misma celda
                            hay_texto = True
                            mejor = similitud(resto, x['desc'])
                        # la descripción suele estar a la derecha, en la misma fila o debajo; algunas empresas la
                        # ponen en la fila de ARRIBA del número (ej. San Benito: 'Desmonte y Compactación' / 'ITEM: 1.2')
                        for rr in (r, r + 1, r + 2, r - 1, r - 2):
                            for cc in range(max(1, c - 1), c + 8):
                                if rr == r and cc == c:
                                    continue
                                t = g.v(rr, cc)
                                # textos cortos ('M 1', 'B 2': nombres de mobiliario, tipos de abertura...) solo si son
                                # IGUALES a la descripción de la planilla; si no, podrían ser una unidad o un rótulo cualquiera
                                if isinstance(t, str) and (len(t.strip()) > 3 or _mismo_texto(t, x['desc'])) \
                                        and not id_de_celda_analisis(t)[0]:
                                    hay_texto = True
                                    mejor = max(mejor, similitud(t, x['desc']))
                        if hay_texto:
                            cand.setdefault(x['r'], []).append(Ancla(n, r, c, mejor, mejor >= 0.6))
    # Si un ítem aparece con la misma descripción en varias hojas, gana la que tiene MENOS ítems (la hoja
    # propia del ítem) sobre un listado general (Materiales, Plan de trabajo...).
    n_items = Counter()
    for lista in cand.values():
        for hoja in {a.hoja for a in lista}:
            n_items[hoja] += 1
    anclas = {}                      # por FILA de la planilla: dos filas con el mismo número de ítem pueden ser análisis distintos
    for r_pl, lista in cand.items():
        lista.sort(key=lambda a: (-round(a.sim, 2), n_items[a.hoja], a.hoja, a.fila))
        a = lista[0]
        if a.confirmada or a.sim >= 0.25:
            anclas[r_pl] = a
    # Números repetidos con descripciones casi iguales: si dos filas quedaron con el mismo bloque, se reparten en orden.
    for cid, xs in por_id.items():
        if len(xs) < 2 or any(x['r'] not in anclas for x in xs):
            continue
        if len({(anclas[x['r']].hoja, anclas[x['r']].fila) for x in xs}) >= len(xs):
            continue
        base = anclas[xs[0]['r']]
        posibles = sorted({a.fila for x in xs for a in cand[x['r']] if a.hoja == base.hoja and a.sim >= base.sim - 0.05})
        if len(posibles) == len(xs):
            for x, fila_b in zip(sorted(xs, key=lambda y: y['r']), posibles):
                a = next(a for a in cand[x['r']] if a.hoja == base.hoja and a.fila == fila_b)
                anclas[x['r']] = a
    _anclas_por_descripcion(grillas, pl, anclas, encabezados)
    return anclas


SIM_POR_DESCRIPCION = 0.9


def _anclas_por_descripcion(grillas, pl, anclas, encabezados):
    """2.ª pasada para los ítems que NO se encontraron por número: hay planillas en las que el análisis numera distinto
    (ej. el 9.5.1 de la planilla es el 9.5.2.1 del análisis, o el 32.2 es el 13.2). Se acepta el análisis cuya
    descripción, en la MISMA fila que su número, es prácticamente igual a la del ítem, y solo si no hay duda. Si el ítem
    se repite en la planilla (varias secciones) y el análisis también, se emparejan en orden (1.º con 1.º, ...).
    El precio se controla igual y se avisa que el número no coincide."""
    faltan = [x for x in pl.items if x['r'] not in anclas and len(norm_tokens(x['desc'])) >= 2]
    if not faltan or not encabezados:
        return
    usadas = {(a.hoja, a.fila) for a in anclas.values()}
    uso_hoja = Counter(a.hoja for a in anclas.values())

    def parecido(t, desc):
        a, b = set(norm_tokens(t)), set(norm_tokens(desc))
        return len(a & b) / max(len(a), len(b)) if a and b else 0.0

    grupos = {}                                          # el mismo ítem repetido en la planilla = un grupo
    for x in faltan:
        grupos.setdefault(' '.join(norm_tokens(x['desc'])), []).append(x)
    for desc, xs in grupos.items():
        cands = []
        for n, r, c, i, resto in encabezados:
            if (n, r) in usadas:
                continue
            g = grillas[n]
            textos = [resto] if len(resto) > 3 else []
            textos += [g.v(r, cc) for cc in range(c + 1, c + 8) if isinstance(g.v(r, cc), str) and len(g.v(r, cc).strip()) > 3]
            p = max((parecido(t, xs[0]['desc']) for t in textos), default=0.0)
            if p >= SIM_POR_DESCRIPCION:
                cands.append((n, r, c, i, p))
        if not cands:
            continue
        # entre copias en varias hojas, la hoja donde están los demás ítems; dentro de ella, de arriba hacia abajo
        mejor_hoja = max({k[0] for k in cands}, key=lambda h: uso_hoja[h])
        cands = sorted((k for k in cands if k[0] == mejor_hoja), key=lambda k: k[1])
        if len(cands) != len(xs):
            continue                                     # no se sabe cuál va con cuál: no se adivina
        for x, (n, r, c, i, p) in zip(sorted(xs, key=lambda y: y['r']), cands):
            a = Ancla(n, r, c, p, True)
            a.id_analisis = i
            anclas[x['r']] = a
            usadas.add((n, r))

def etiqueta_fila(g, r, hasta_col):
    """Rótulo de una fila del análisis: el texto más largo a la izquierda de la celda del valor."""
    mejor = ''
    fila = g.filas[r - 1] if 1 <= r <= g.nrows else []
    for c in range(min(hasta_col - 1, len(fila))):
        v = fila[c]
        if isinstance(v, str) and len(v.strip()) > len(mejor) and num(v) is None:
            mejor = v.strip()
    return ' '.join(norm_tokens(mejor))


def _extensiones(anclas):
    por_hoja = {}
    for a in anclas.values():
        por_hoja.setdefault(a.hoja, []).append(a.fila)
    for n in por_hoja:
        por_hoja[n].sort()
    return por_hoja


def extension(por_hoja, grillas, a):
    sig = [x for x in por_hoja[a.hoja] if x > a.fila]
    return a.fila, (sig[0] - 1 if sig else min(grillas[a.hoja].nrows, a.fila + 400))


class Vinculo:
    """Resultado del aprendizaje para un bloque: de qué celda del análisis sale el precio."""
    def __init__(self):
        self.col = None
        self.etiqueta = ''
        self.offset = None
        self.ref = None                # (rótulo, desplazamiento): la celda está N filas antes/después de la fila con ese rótulo
        self.modo = 'u'                # 'u': la planilla toma la celda tal cual | 't': la celda es el total y el precio = celda / cantidad
        self.ocurrencia = None         # si el rótulo se repite en el bloque (ej. dos «sub total»): ('ini', k) = el k-ésimo
                                       # desde arriba, ('fin', k) = el k-ésimo desde abajo. None = el primero (como antes)
        self.tol = 0.0
        self.cobertura = 0.0
        self.n_muestra = 0

    def describir(self):
        if self.col is None:
            return 'sin vínculo'
        if self.ref:
            lab, d = self.ref
            r = f"{abs(d)} fila(s) {'arriba' if d < 0 else 'abajo'} de «{lab}»"
        else:
            r = f"fila «{self.etiqueta}»" if self.etiqueta else f"{self.offset:+d} filas del número de ítem"
            if self.etiqueta and self.ocurrencia and self.ocurrencia != ('ini', 1):
                lado, k = self.ocurrencia
                r += f" (la {k}.ª {'desde arriba' if lado == 'ini' else 'desde abajo'} del bloque)"
        return f"{r}, columna {L(self.col)}" + (" (÷ cantidad)" if self.modo == 't' else '')


def _celdas_iguales(g, ra, rb, v, tol):
    out = []
    for r in range(ra, rb + 1):
        fila = g.filas[r - 1]
        for c in range(1, len(fila) + 1):
            x = fila[c - 1]
            if isinstance(x, (int, float)) and not isinstance(x, bool) and abs(x - v) <= tol:
                out.append((r, c))
    return out


def _ocurrencias(ga, ra, rb, c, lab, r):
    """Posición de la fila r entre las filas del bloque con el mismo rótulo: (k desde arriba, k desde abajo)."""
    filas = [rr for rr in range(ra, rb + 1) if etiqueta_fila(ga, rr, c) == lab]
    if r not in filas:
        return 1, 1
    i = filas.index(r)
    return i + 1, len(filas) - i


def aprender_vinculo(pl, b, anclas, grillas, por_hoja):
    """Aprende, mirando los ítems de una muestra, en qué fila (rótulo) y columna del bloque del análisis está el valor
    que la planilla usa como precio de este bloque."""
    g = pl.grilla
    items = []
    for x in pl.items:
        a = anclas.get(x['r'])
        v = g.n(x['r'], b.p)
        if a is not None and v:
            items.append((x, a, v))
    if len(items) < 3:
        return None
    paso = max(1, len(items) // 80)
    muestra = items[::paso]
    for tol in (0.006, 0.51):                    # exacto al centavo; o la planilla redondea a pesos enteros
        cuenta = Counter()
        for x, a, v in muestra:
            ga = grillas[a.hoja]
            ra, rb = extension(por_hoja, grillas, a)
            claves = set()
            for modo, objetivo, t_ in (('u', v, tol), ('t', v * x['cant'], tol * abs(x['cant']))):
                for r, c in _celdas_iguales(ga, ra, rb, objetivo, max(t_, 1e-9 * abs(objetivo))):
                    lab = etiqueta_fila(ga, r, c)
                    if lab:
                        # el mismo rótulo puede repetirse en el bloque (ej. «sub total» de equipos y de mano de obra):
                        # se aprende también CUÁL de ellos es, contado desde arriba y desde abajo (gana el que sea parejo)
                        k_ini, k_fin = _ocurrencias(ga, ra, rb, c, lab, r)
                        claves.add((c, lab, ('occ', 'ini', k_ini), modo))
                        claves.add((c, lab, ('occ', 'fin', k_fin), modo))
                        continue
                    claves.add((c, '', r - a.fila, modo))
                    # fila sin rótulo: también se la ubica por la fila con rótulo más cercana (hasta 3 arriba o
                    # abajo). Ej. San Benito: el costo del ítem está en la fila SIN rótulo que queda justo arriba de
                    # "COEF.PASE"; cada ítem tiene distinta cantidad de renglones, así que la distancia al número
                    # de ítem varía, pero la distancia a ese rótulo no.
                    for d in (1, -1, 2, -2, 3, -3):
                        rr = r + d
                        if ra <= rr <= rb:
                            lab_ref = etiqueta_fila(ga, rr, c)
                            if lab_ref:
                                claves.add((c, '', ('ref', lab_ref, -d), modo))
            for k in claves:
                cuenta[k] += 1
        if not cuenta:
            continue
        def puntaje(kv):
            (c, lab, off, modo), n = kv
            es_ref = isinstance(off, tuple) and off[0] == 'ref'
            occ = off[1:] if isinstance(off, tuple) and off[0] == 'occ' else None
            # a igual cantidad de aciertos: primero el rótulo, y entre las dos formas de contar sus repeticiones, la
            # primera desde arriba (lo de siempre) antes que la cuenta desde abajo
            return (n, any(k in lab for k in KW_PRECIO), bool(lab), es_ref, modo == 'u',
                    -abs(off[2]) if es_ref else 0, len(lab), -c, occ == ('ini', 1), occ is not None and occ[0] == 'ini')
        (c, lab, off, modo), n = max(cuenta.items(), key=puntaje)
        if n / len(muestra) >= 0.5:
            vin = Vinculo()
            vin.col, vin.etiqueta, vin.modo, vin.tol = c, lab, modo, tol
            if isinstance(off, tuple) and off[0] == 'occ':
                vin.ocurrencia = (off[1], off[2])
                off = None
            if isinstance(off, tuple):
                vin.ref = (off[1], off[2])
            else:
                vin.offset = off
            vin.cobertura, vin.n_muestra = n / len(muestra), len(muestra)
            return vin
    return None


def valor_vinculado(ga, ra, rb, vin, ancla):
    """(valor, fila) de la celda vinculada dentro del bloque de un ítem; (None, None) si no existe esa fila."""
    if vin.ref:
        lab_ref, d = vin.ref
        for rr in range(ra, rb + 1):
            if etiqueta_fila(ga, rr, vin.col) == lab_ref:
                r = rr + d
                if ra <= r <= rb:
                    x = ga.n(r, vin.col)
                    if x is not None:
                        return x, r
        return None, None
    if vin.etiqueta:
        filas = [r for r in range(ra, rb + 1) if etiqueta_fila(ga, r, vin.col) == vin.etiqueta and ga.n(r, vin.col) is not None]
        if not filas:
            return None, None
        r = filas[0]
        if vin.ocurrencia:
            lado, k = vin.ocurrencia
            if k <= len(filas):
                r = filas[k - 1] if lado == 'ini' else filas[-k]
        return ga.n(r, vin.col), r
    r = ancla.fila + vin.offset
    if ra <= r <= rb:
        x = ga.n(r, vin.col)
        return x, r
    return None, None


def hallazgo_c(**kw):
    base = {'hoja': '', 'bloque': '', 'fila': '', 'col': '', 'item': '', 'desc': '', 'tipo': '', 'valor_hoja': None,
            'valor_esperado': None, 'celda_analisis': '', 'detalle': '', 'nivel': 'ERROR', 'causa': '', 'impacto': None}
    base.update(kw)
    return base


def comparar_bloque(pl, b, anclas, grillas, por_hoja, hallazgos):
    """Compara, ítem por ítem, el precio de la planilla en este bloque con el del análisis."""
    g = pl.grilla
    res = {'items': len(pl.items), 'ok': 0, 'mal': 0, 'sin_analisis': 0, 'sin_comparar': 0, 'vinculo': None,
           'desc_distinta': 0}
    vin = aprender_vinculo(pl, b, anclas, grillas, por_hoja)
    res['vinculo'] = vin
    if vin is None:
        n_anclas = sum(1 for x in pl.items if x['r'] in anclas)
        if n_anclas < max(3, len(pl.items) // 2):
            motivo = (f"no encontré en el análisis de precios dónde empieza cada ítem (ubiqué {n_anclas} de {len(pl.items)}): "
                      "busco el número de ítem de la planilla (ej. '1.2' o 'ITEM: 1.2') junto a su descripción")
        else:
            motivo = ("ubiqué cada ítem en el análisis de precios, pero sus precios unitarios de esta columna no aparecen "
                      "en un mismo lugar del análisis para la mayoría de los ítems")
        hallazgos.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=pl.items[0]['r'], col=L(b.p), tipo='Bloque sin vínculo con el análisis',
                                    nivel='AVISO', detalle=f"No se pudo comparar este bloque de la planilla de costos con el análisis de precios: {motivo}. "
                                                           "NO quiere decir que haya un error en la planilla; quiere decir que este control no se hizo "
                                                           "y hay que revisar a mano que los precios de la planilla sean los del análisis. "
                                                           "Si se repite con planillas de esta empresa, pasar el archivo para que el programa aprenda su formato."))
        return res
    if vin.tol > 0.1:
        hallazgos.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=pl.items[0]['r'], col=L(b.p), tipo='Precios redondeados', nivel='AVISO',
                                    detalle="Los precios de este bloque coinciden con el análisis solo redondeando a pesos enteros; se compara con esa tolerancia."))
    for x in pl.items:
        v = g.n(x['r'], b.p)
        a = anclas.get(x['r'])
        if a is None:
            res['sin_analisis'] += 1
            if b is pl.bloques_sel[0]:            # se informa una sola vez por ítem
                hallazgos.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=x['r'], col=L(b.p), item=x['id'], desc=x['desc'], valor_hoja=v,
                                            tipo='Ítem sin análisis de precios', nivel='AVISO',
                                            detalle='No encontré en el análisis el bloque de este ítem (por número y descripción): este precio no se pudo verificar.'))
            continue
        if a.id_analisis and b is pl.bloques_sel[0]:
            hallazgos.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=x['r'], col='A', item=x['id'], desc=x['desc'],
                                        valor_hoja=x['id'], valor_esperado=a.id_analisis, tipo='Número de ítem distinto en el análisis',
                                        nivel='AVISO', celda_analisis=f"{a.hoja}!{L(a.col)}{a.fila}",
                                        detalle=f"En el análisis de precios este ítem figura con el número {a.id_analisis} "
                                                f"({a.hoja}!{L(a.col)}{a.fila}), con la misma descripción. Se tomó ese análisis para "
                                                "controlar el precio; conviene que la numeración coincida."))
        if not a.confirmada and b is pl.bloques_sel[0]:
            # no es un hallazgo (no está en las columnas del bloque analizado): se guarda aparte, para una hoja del reporte
            res['desc_distinta'] += 1
            pl.desc_distintas.append({'hoja': pl.hoja, 'fila': x['r'], 'item': x['id'], 'desc': x['desc'], 'celda_analisis': f"{a.hoja}!{L(a.col)}{a.fila}",
                                      'parecido': a.sim})
        ga = grillas[a.hoja]
        ra, rb = extension(por_hoja, grillas, a)
        e, fila_e = valor_vinculado(ga, ra, rb, vin, a)
        if e is not None and vin.modo == 't' and x['cant']:
            e = e / x['cant']                       # el análisis trae el total de la cantidad: precio unitario = total / cantidad
        if e is None:
            res['sin_comparar'] += 1
            hallazgos.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=x['r'], col=L(b.p), item=x['id'], desc=x['desc'], valor_hoja=v,
                                        tipo='No se pudo comparar con el análisis', nivel='AVISO', celda_analisis=f"{a.hoja}!{L(a.col)}{a.fila}",
                                        detalle=f"El bloque de este ítem en el análisis no tiene la fila «{vin.etiqueta or 'del precio'}»."))
            continue
        tol = max(vin.tol, 1e-9 * abs(e))
        if not v:
            if abs(e) > tol:
                res['mal'] += 1
                hallazgos.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=x['r'], col=L(b.p), item=x['id'], desc=x['desc'], valor_hoja=v or 0.0,
                                            valor_esperado=e, tipo='Ítem sin precio en la planilla', celda_analisis=f"{a.hoja}!{L(vin.col)}{fila_e}",
                                            detalle='La planilla no tiene precio para este ítem y el análisis sí.'))
            else:
                res['ok'] += 1
            continue
        if abs(v - e) <= tol:
            res['ok'] += 1
            continue
        res['mal'] += 1
        pista = ''
        otros = [(r, c) for r, c in _celdas_iguales(ga, ra, rb, v, tol)]
        if otros:
            r2, c2 = otros[0]
            lab = etiqueta_fila(ga, r2, c2)
            pista = f"El valor de la planilla coincide con {a.hoja}!{L(c2)}{r2}" + (f" (fila «{lab}»)" if lab else '') + ", que no es la fila que usa el resto de la planilla."
        hallazgos.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=x['r'], col=L(b.p), item=x['id'], desc=x['desc'], valor_hoja=v, valor_esperado=e,
                                    tipo='Precio distinto al del análisis', celda_analisis=f"{a.hoja}!{L(vin.col)}{fila_e}", impacto=(v - e) * x['cant'],
                                    detalle=pista or (f"Según el análisis (fila «{vin.etiqueta}»)." if vin.etiqueta else '')))
    return res


# ======================================================================
# ARITMÉTICA DE LA PLANILLA: parciales, subtotales de rubro, total de costo, gastos, beneficio, impuestos, total
# ======================================================================
ADD_RE = re.compile(r'gastos|beneficio|utilidad|\biva\b|iibb|ingresos brutos|impuesto|imprevisto|ganancia|tasa|\bgg\b')
SUBT_RE = re.compile(r'total|subtotal|sub total|costo|precio')


def _tol(x):
    return TOL_PARCIAL_ABS + TOL_PARCIAL_REL * abs(x)


def rotulo_crudo(pl, r, hasta_col=None):
    """El mismo rótulo que etiqueta_izq, pero tal cual está escrito (con '%', paréntesis y decimales)."""
    g = pl.grilla
    mejor = ''
    for c in range(1, max(pl.bloques[0].p, (hasta_col or 0) - 1) + 1):
        v = g.v(r, c)
        if isinstance(v, str) and len(v.strip()) > len(mejor) and num(v) is None:
            mejor = v.strip()
    return mejor


def etiqueta_izq(pl, r, hasta_col=None):
    """Rótulo de una fila de cierre: el texto más largo a la izquierda de la columna de importes (por defecto, hasta la
    primera columna de precios). Algunas planillas ponen el rótulo ('Costo', 'Beneficio', 'TOTAL') entre las columnas
    de precios, a la izquierda de los importes: por eso se busca hasta la columna del importe."""
    g = pl.grilla
    mejor = ''
    for c in range(1, max(pl.bloques[0].p, (hasta_col or 0) - 1) + 1):          # incluye la columna del precio de la base
        v = g.v(r, c)
        if isinstance(v, str) and len(v.strip()) > len(mejor) and num(v) is None:
            mejor = v.strip()
    return ' '.join(norm_tokens(mejor))


def controlar_aritmetica(pl, b, hallazgos):
    """Controles de cálculo de un bloque. Devuelve dict con contadores."""
    g = pl.grilla
    res = {'parciales_mal': 0, 'rubros_mal': 0, 'cierre_mal': 0, 'cierre_ok': False, 'notas': []}
    H = lambda **kw: hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, **kw)

    # 1) parcial = cantidad x precio unitario
    for x in pl.items:
        pp, tt = g.n(x['r'], b.p), g.n(x['r'], b.t)
        if not pp:
            continue
        esp = x['cant'] * pp
        if tt is None or abs(tt - esp) > _tol(esp):
            res['parciales_mal'] += 1
            hallazgos.append(H(fila=x['r'], col=L(b.t), item=x['id'], desc=x['desc'], tipo='Parcial ≠ cantidad × precio unitario',
                               valor_hoja=tt, valor_esperado=esp, impacto=(tt - esp) if tt is not None else None, detalle=f"{x['cant']:g} × {pp:,.2f}".replace(',', '§').replace('.', ',').replace('§', '.')))

    # 2) subtotal de cada rubro = suma de sus ítems (la columna donde están se aprende de los datos)
    padres = [p for p in pl.padres if p['hijos']]
    if not padres:
        return res

    def filas_del_rubro(p):
        a0, a1 = p['rango']
        return [r for r in range(a0, a1 + 1) if r not in pl.filas_padre and g.n(r, b.t) is not None]

    suma = {p['id']: sum(g.n(r, b.t) for r in filas_del_rubro(p)) for p in padres}
    cuenta = Counter()
    for p in padres:
        for c in range(b.p, b.c_fin + 1):
            v = g.n(p['r'], c)
            if v is not None and abs(v - suma[p['id']]) <= _tol(suma[p['id']]) and suma[p['id']]:
                cuenta[c] += 1
    if cuenta:
        b.col_amount = cuenta.most_common(1)[0][0]
    else:
        b.col_amount = b.t
    for p in padres:
        v = g.n(p['r'], b.col_amount)
        if v is None:
            continue
        if abs(v - suma[p['id']]) > _tol(suma[p['id']]):
            res['rubros_mal'] += 1
            hallazgos.append(H(fila=p['r'], col=L(b.col_amount), item=p['id'], desc=p['desc'], tipo='Subtotal de rubro ≠ suma de sus ítems',
                               valor_hoja=v, valor_esperado=suma[p['id']], detalle='Suma de los parciales de sus ítems.'))

    # 3) cierre: total de costo, gastos generales, beneficio, impuestos, subtotales y total
    top = [p for p in padres if '.' not in p['id']]
    if not top:
        return res
    a = b.col_amount
    tope_costo = sum(g.n(p['r'], a) if g.n(p['r'], a) is not None else suma[p['id']] for p in top)
    filas_cierre = []
    for r in range(pl.ultima_fila_item + 1, min(g.nrows, pl.ultima_fila_item + 60) + 1):
        lab = etiqueta_izq(pl, r, a)
        amount = g.n(r, a)
        if lab and amount is not None:
            pct = None
            for c in range(b.p, b.c_fin + 1):
                x = g.n(r, c)
                if c != a and x is not None and 0 < x < 0.6:
                    pct = x
                    break
            if pct is None:
                pct = _pcts_del_rotulo(rotulo_crudo(pl, r, a))    # "BENEFICIO (10 %)": el porcentaje escrito en el rótulo
            filas_cierre.append((r, lab, amount, pct))
    if not filas_cierre:
        res['notas'].append('no reconocí el cierre de la planilla (total de costo, gastos, beneficio, impuestos, total)')
        return res
    # total de costo: la primera fila de cierre que se parece a "costo/total" y no es un adicional con porcentaje
    i0 = next((i for i, (r, lab, m, pct) in enumerate(filas_cierre) if SUBT_RE.search(lab) and pct is None), None)
    if i0 is None:
        res['notas'].append('no encontré el total de costo')
        return res
    r0, lab0, m0, _ = filas_cierre[i0]
    if abs(m0 - tope_costo) > _tol(tope_costo):
        res['cierre_mal'] += 1
        hallazgos.append(H(fila=r0, col=L(a), item='', desc=lab0.upper(), tipo='Total de costo ≠ suma de los rubros', valor_hoja=m0, valor_esperado=tope_costo,
                           detalle='Suma de los subtotales de rubro.'))
    base, ref, acum = m0, m0, m0
    hubo_adicional = False
    for r, lab, m, pct in filas_cierre[i0 + 1:]:
        es_adicional = ADD_RE.search(lab) or not SUBT_RE.search(lab)
        if pct is not None and es_adicional:     # cualquier fila con % y monto que no sea un subtotal
            # pct puede ser un número o, si vino del rótulo, la lista de porcentajes escritos ahí
            # ("IIBB 3.5 % + IVA 10.5% (14%)"): vale cualquiera de ellos o su suma
            tasas = pct if isinstance(pct, tuple) else (pct,)
            candidatos = {t * x for t in tasas for x in (ref, base, acum)}
            if not any(abs(m - c) <= _tol(c) for c in candidatos):
                t0 = tasas[-1]
                res['cierre_mal'] += 1
                hallazgos.append(H(fila=r, col=L(a), item='', desc=lab.upper(), tipo='Adicional ≠ porcentaje × base', valor_hoja=m, valor_esperado=t0 * ref,
                                   detalle=f"{t0:.2%} de {ref:,.2f}".replace(',', '§').replace('.', ',').replace('§', '.') +
                                           (f" (el monto equivale al {m / ref:.2%})".replace('.', ',') if ref else '')))
            acum += m
            hubo_adicional = True
        elif ADD_RE.search(lab) and not SUBT_RE.search(lab):
            # adicional sin porcentaje en ningún lado: no se puede controlar su tasa, pero SÍ suma
            acum += m
            hubo_adicional = True
        elif SUBT_RE.search(lab):
            if abs(m - acum) > _tol(acum):
                res['cierre_mal'] += 1
                hallazgos.append(H(fila=r, col=L(a), item='', desc=lab.upper(), tipo='Subtotal / total ≠ suma acumulada', valor_hoja=m, valor_esperado=acum,
                                   detalle='Total de costo más los adicionales anteriores.'))
                acum = m
            ref = m
            # el TOTAL final cierra la planilla: lo que haya más abajo (cuentas auxiliares, ej. un
            # "COSTO COSTO / TOTAL" de materiales y mano de obra aparte) no es parte del cierre
            if hubo_adicional and re.match(r'\s*total\b', lab, re.IGNORECASE) and 'costo' not in lab.lower():
                break
    res['cierre_ok'] = res['cierre_mal'] == 0
    res['cierre'] = filas_cierre
    res['pcts'] = {lab: (pct[-1] if isinstance(pct, tuple) else pct) for r, lab, m, pct in filas_cierre if pct is not None}
    return res


_PCT_ROTULO = re.compile(r'(\d{1,2}(?:[.,]\d+)?)\s*%')


def _pcts_del_rotulo(lab):
    """Porcentajes escritos en el rótulo de un adicional: 'BENEFICIO (10 %)' -> (0.10,);
    'IMPUESTOS IIBB 3.5 % + IVA 10.5% (14%)' -> (0.035, 0.105, 0.14, 0.28). Se agrega la suma de los
    distintos, por si el rótulo da las partes y no el total. None si no hay ninguno."""
    vals = []
    for x in _PCT_ROTULO.findall(lab or ''):
        v = float(x.replace(',', '.')) / 100
        if 0 < v < 0.6 and v not in vals:
            vals.append(v)
    if not vals:
        return None
    if len(vals) > 1:
        # si uno ya es la suma de los demás ("IIBB 3.5 % + IVA 10.5% (14%)") ese es el total; si no, se agrega la suma
        mayor = max(vals)
        if abs(mayor - (sum(vals) - mayor)) > 1e-9:
            vals.append(sum(vals))
        vals.sort()                                   # el último (el mayor) es el que se muestra como esperado
    return tuple(vals)


def filas_con_numero_invalido(pl, hallazgos, b):
    """Filas dentro de un rubro que tienen parcial pero cuyo número de ítem no es válido ('13,8', una fecha, vacío...):
    cuentan en el subtotal del rubro pero no se pueden controlar contra el análisis."""
    g = pl.grilla
    validas = {x['r'] for x in pl.items}
    vistas = set()
    for p in pl.padres:
        if '.' in p['id'] or not p['hijos']:
            continue
        a0, a1 = p['rango']
        for r in range(a0, a1 + 1):
            if r in pl.filas_padre or r in validas or r in vistas:
                continue
            if g.n(r, b.t) is None or not g.n(r, b.t):
                continue
            vistas.add(r)
            raw = g.v(r, pl.idc)
            desc = g.v(r, pl.idc + 1)
            hallazgos.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=r, col=L(b.t), item=texto(raw) or '(vacío)', desc=texto(desc), tipo='Ítem con número inválido',
                                        nivel='AVISO', valor_hoja=g.n(r, b.t),
                                        detalle=f"Tiene parcial y cuenta en el subtotal del rubro {p['id']}, pero su número de ítem no es válido: no se pudo controlar contra el análisis."))




# ======================================================================
# PIPELINE: detectar planillas, analizar, comparar con la versión anterior
# ======================================================================
def detectar_planillas(ctx, hoja=None):
    """Planillas de costos del libro, la más completa primero, y las hojas de análisis de precios donde
    se buscan los ítems. hoja: nombre de la hoja de la planilla si el usuario la indicó.
    - Las hojas ocultas (versiones viejas) no se usan salvo que se pidan por nombre o no haya otra.
    - Una hoja de análisis por ítem puede parecerse a una planilla (tiene subítems, cantidades y parciales):
      solo se ofrecen como planilla las que tienen tantos bloques e ítems como la principal."""
    wb = ctx.wb
    han = list(ctx.hojas_bloques)                       # hojas de análisis = las que tienen bloques de índices

    def buscar(incluir_ocultas):
        cand = [n for n in hojas_de_datos(wb) if n not in ctx.excluir and n not in han and wb[n].max_row <= 2500
                and (incluir_ocultas or n not in ctx.ocultas)]
        if hoja:
            h = hoja.strip().lower()
            cand = [n for n in cand if n.strip().lower() == h] or [n for n in wb.sheetnames if n.strip().lower() == h]
        out = []
        for n in cand:
            try:
                pl = leer_planilla(Grilla(wb[n], n), n)
            except Exception:
                pl = None
            if pl:
                out.append(pl)
        return out
    if hoja and not any(n.strip().lower() == hoja.strip().lower() for n in wb.sheetnames):
        raise ErrorVerificacion(f"No encontré la hoja '{hoja}' en este archivo. Hojas: {', '.join(wb.sheetnames[:15])}")
    planillas = buscar(False) or buscar(True)
    if not planillas:
        raise ErrorVerificacion("No encontré ninguna planilla de costos (columnas de número de ítem, cantidad, precio unitario y parcial).")
    planillas.sort(key=lambda p: (-len(p.bloques), -len(p.items)))
    if not hoja:
        p0 = planillas[0]
        planillas = [p for p in planillas if len(p.bloques) == len(p0.bloques) and len(p.items) >= 0.5 * len(p0.items)]
    if not han:                      # sin hojas de análisis con índices reconocibles: se busca en cualquier otra hoja visible
        han = [n for n in hojas_de_datos(wb) if n not in ctx.excluir and n not in ctx.ocultas and n != planillas[0].hoja]
    return planillas, han


def _total_cierre(cierre):
    """El TOTAL final de la planilla (con gastos, beneficio e impuestos): el último 'total' del cierre, o None."""
    if not cierre:
        return None
    totales = [m for r, lab, m, pct in cierre if 'total' in lab and 'sub' not in lab and pct is None and m]
    return totales[-1] if totales else None


def total_de_bloque(pl, b):
    """Respaldo para el TOTAL final del bloque (monto del contrato): debajo de los ítems, la última fila rotulada
    'TOTAL' (no 'SUBTOTAL' ni 'COSTO TOTAL') dentro de las columnas del bloque; el primer importe a su derecha."""
    g = pl.grilla
    anteriores = [x.c_fin for x in pl.bloques if x.c_fin < b.p]
    desde = (max(anteriores) + 1) if anteriores else max(1, b.p - 8)
    hasta = b.c_fin + 2
    total = None
    for r in range(pl.ultima_fila_item + 1, pl.ultima_fila_item + 45):
        textos = [(c, strip_accents(g.v(r, c)).strip().lower()) for c in range(desde, hasta)
                  if isinstance(g.v(r, c), str) and g.v(r, c).strip()]
        if not textos or any('costo' in t or 'sub' in t for _, t in textos):
            continue
        c_lab = next((c for c, t in textos if re.match(r'^(precio\s+|monto\s+)?total(\s+general|\s+obra)?\s*[:$]*$', t)), None)
        if c_lab is None:
            continue
        for c in range(c_lab + 1, hasta):
            m = g.n(r, c)
            if m and abs(m) > 1000:
                total = m
                break
    return total


def _factor_cierre(cierre):
    """Cuánto pesa $1 de costo directo en el TOTAL de la planilla (gastos, beneficio e impuestos): total / costo total."""
    if not cierre:
        return None
    costo = next((m for r, lab, m, pct in cierre if SUBT_RE.search(lab) and pct is None), None)
    totales = [m for r, lab, m, pct in cierre if 'total' in lab and 'sub' not in lab and pct is None]
    return (totales[-1] / costo) if costo and totales and costo > 0 else None


def agregar_formulas(res, fm):
    """Lo que se ve leyendo las fórmulas: celdas de precio / parcial cuya fórmula se aparta de la de su columna.
    Es solo INFORMATIVO (aviso): lo que manda es el valor, y si el valor está mal ya lo informa el control de cálculo."""
    ya = {(h['hoja'], h['fila'], h['col']) for h in res['hallazgos']}
    for x in res['resultados']:
        pl = x['pl']
        filas = [i['r'] for i in pl.items]
        info = {i['r']: i for i in pl.items}
        for b in pl.bloques_sel:
            for c, nombre in ((b.p, 'precio unitario'), (b.t, 'parcial')):
                for a in fm.apartadas(pl.hoja, c, filas):
                    i = info[a['fila']]
                    if (pl.hoja, a['fila'], L(c)) in ya:
                        continue
                    if a['tipo'] == 'formula':
                        continue    # acá solo llegan filas cuyo valor da bien: una fórmula distinta con resultado correcto no se informa
                    else:
                        res['hallazgos'].append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=a['fila'], col=L(c), item=i['id'], desc=i['desc'], nivel='AVISO',
                                                           tipo='Valor tipeado donde las demás filas tienen fórmula', formula_esperada=a['esperado'],
                                                           valor_hoja=a['actual'] if isinstance(a['actual'], (int, float)) else None,
                                                           detalle=f"El {nombre} está escrito a mano ({a['actual']}); las demás filas usan la fórmula {a['esperado']}."))


def analizar_una_planilla(ctx, han, pl, seleccion, progreso=True):
    for b in pl.bloques:
        b.seleccionado = bloque_seleccionado(b, seleccion)
    sel = [b for b in pl.bloques if b.seleccionado]
    pl.bloques_sel = sel
    pl.desc_distintas = []
    res = {'pl': pl, 'hallazgos': [], 'bloques': [], 'anclas': 0, 'desc_distintas': []}
    if not sel:
        return res
    grillas = {n: ctx.grilla(n) for n in han}
    anclas = buscar_anclas(grillas, pl)
    por_hoja = _extensiones(anclas)
    res['anclas'] = len(anclas)
    hall = res['hallazgos']
    pcts = {}
    for k, b in enumerate(sel):
        if progreso:
            barra_progreso(k, len(sel), prefijo='  Analizando bloques de la planilla')
        r1 = comparar_bloque(pl, b, anclas, grillas, por_hoja, hall)
        r2 = controlar_aritmetica(pl, b, hall)
        if k == 0:
            filas_con_numero_invalido(pl, hall, b)
        pcts[b.etiqueta] = r2.get('pcts', {})
        res['bloques'].append({'b': b, 'factor_cierre': _factor_cierre(r2.get('cierre')), 'total': _total_cierre(r2.get('cierre')) or total_de_bloque(pl, b), 'vinculo': r1['vinculo'], 'items': r1['items'], 'ok': r1['ok'], 'mal': r1['mal'],
                               'sin_analisis': r1['sin_analisis'], 'sin_comparar': r1['sin_comparar'],
                               'desc_distinta': r1['desc_distinta'], 'parciales_mal': r2['parciales_mal'],
                               'rubros_mal': r2['rubros_mal'], 'cierre_mal': r2['cierre_mal'], 'notas': r2['notas']})
    if progreso:
        barra_progreso(len(sel), len(sel), prefijo='  Analizando bloques de la planilla')
    # los porcentajes de gastos / beneficio / impuestos deberían ser los mismos en todos los bloques
    ref_et = sel[0].etiqueta
    for b in sel[1:]:
        for lab, pct in pcts[b.etiqueta].items():
            p0 = pcts[ref_et].get(lab)
            if p0 is not None and abs(p0 - pct) > 1e-9:
                hall.append(hallazgo_c(hoja=pl.hoja, bloque=b.etiqueta, fila=pl.ultima_fila_item + 1, col=L(b.p),
                                       tipo='Porcentaje distinto al de otro bloque', nivel='AVISO', desc=lab.upper(),
                                       valor_hoja=pct, valor_esperado=p0,
                                       detalle=f"En {ref_et} es {p0:.2%} y en {b.etiqueta} es {pct:.2%}."))
    res['desc_distintas'] = pl.desc_distintas
    return res


def analizar_costos(ctx, planillas, hojas_analisis, seleccion=None, seleccion_txt='todas', progreso=True):
    """Analiza las planillas elegidas. seleccion: tokens de seleccion.parsear_seleccion (None = todo)."""
    if seleccion is not None and not any(bloque_seleccionado(b, seleccion) for p in planillas for b in p.bloques):
        raise ErrorVerificacion(f"El rango '{seleccion_txt}' no toca ningún bloque. Bloques: " +
                                ', '.join(f"{p.hoja} {b.etiqueta} ({L(b.p)}:{L(b.c_fin)})" for p in planillas for b in p.bloques))
    hojas_analisis = [h for h in hojas_analisis if h not in {p.hoja for p in planillas}]
    resultados = []
    for pl in planillas:
        if progreso:
            print(f"  Planilla: '{pl.hoja}' ({len(pl.items)} ítems)")
        resultados.append(analizar_una_planilla(ctx, hojas_analisis, pl, seleccion, progreso))
    return {'path': ctx.path, 'resultados': resultados, 'hallazgos': [h for r in resultados for h in r['hallazgos']],
            'hojas_analisis': hojas_analisis, 'seleccion_txt': seleccion_txt,
            'desc_distintas': [d for r in resultados for d in r['desc_distintas']],
            'bloques_txt': ', '.join(f"{r['pl'].hoja} {b.etiqueta} ({L(b.p)}:{L(b.c_fin)})"
                                     for r in resultados for b in r['pl'].bloques_sel)}


# ----------------------------------------------------------------------
# Comparación con la versión anterior aprobada
# ----------------------------------------------------------------------
def _clave_c(h):
    return (h['hoja'], h['bloque'], str(h['item']) or h['desc'], h['tipo'])


def comparar_versiones_costos(act, ant):
    """Marca cada hallazgo como NUEVO o HEREDADO y lista los valores de bloques anteriores que cambiaron."""
    claves_ant = {_clave_c(h) for h in ant['hallazgos']}
    bl_ant = {(r['pl'].hoja, b.etiqueta): (r['pl'], b) for r in ant['resultados'] for b in r['pl'].bloques}
    for h in act['hallazgos']:
        h['version'] = 'HEREDADO' if _clave_c(h) in claves_ant else ('NUEVO (bloque nuevo)' if (h['hoja'], h['bloque']) not in bl_ant else 'NUEVO')
    cambios = []
    for r in act['resultados']:
        pl = r['pl']
        g = pl.grilla
        for b in pl.bloques_sel:
            par = bl_ant.get((pl.hoja, b.etiqueta))
            if par is None:
                continue
            pla, ba = par
            ga = pla.grilla
            ant_items = pla.por_id()
            ids_act = set()
            for x in pl.items:
                ids_act.add(x['id'])
                y = ant_items.get(x['id'])
                if y is None:
                    cambios.append({'hoja': pl.hoja, 'bloque': b.etiqueta, 'fila': x['r'], 'item': x['id'], 'desc': x['desc'], 'campo': 'ítem nuevo', 'antes': None, 'ahora': g.n(x['r'], b.p)})
                    continue
                for campo, ca, cb in (('precio unitario', ba.p, b.p), ('parcial', ba.t, b.t)):
                    va, vn = ga.n(y['r'], ca), g.n(x['r'], cb)
                    if va is None and vn is None:
                        continue
                    if va is None or vn is None or abs(va - vn) > max(1e-6, 1e-9 * abs(va)):
                        cambios.append({'hoja': pl.hoja, 'bloque': b.etiqueta, 'fila': x['r'], 'item': x['id'], 'desc': x['desc'], 'campo': f"{campo} ({L(cb)})", 'antes': va, 'ahora': vn})
            for i, y in ant_items.items():
                if i not in ids_act:
                    cambios.append({'hoja': pl.hoja, 'bloque': b.etiqueta, 'fila': y['r'], 'item': i, 'desc': y['desc'], 'campo': 'ítem que ya no está', 'antes': ga.n(y['r'], ba.p), 'ahora': None})
    faltan = [f"{k[0]} {k[1]}" for k in bl_ant if not any((r['pl'].hoja, b.etiqueta) == k for r in act['resultados'] for b in r['pl'].bloques)]
    return cambios, faltan


def descripcion_hallazgo_c(h):
    """Una línea que dice DÓNDE está y QUÉ está mal."""
    partes = [f"[{h['bloque']}]" if h['bloque'] else '', f"{h['hoja']}!{h['col']}{h['fila']}" if h['col'] and h['fila'] != '' else h['hoja']]
    if h['item']:
        partes.append(f"ítem {h['item']}" + (f" {h['desc'][:38]}" if h['desc'] else ''))
    elif h['desc']:
        partes.append(h['desc'][:40])
    txt = '  '.join(p for p in partes if p) + f" — {h['tipo']}"
    vh, ve = h['valor_hoja'], h['valor_esperado']
    if isinstance(vh, (int, float)) and isinstance(ve, (int, float)):
        d = vh - ve
        pct = (f" (dif. {'+' if d >= 0 else '-'}{fmt_es(abs(d))} / " + f"{(vh / ve - 1) * 100:+.2f}".replace('.', ',') + " %)") if ve else f" (dif. {fmt_es(d)})"
        txt += f": la planilla dice {fmt_es(vh)}, debería ser {fmt_es(ve)}{pct}"
    elif isinstance(vh, (int, float)):
        txt += f" (valor en la planilla: {fmt_es(vh)})"
    if h['celda_analisis']:
        txt += f" [análisis: {h['celda_analisis']}]"
    if h['detalle']:
        txt += f". {h['detalle']}"
    return txt


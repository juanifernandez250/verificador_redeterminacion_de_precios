# -*- coding: utf-8 -*-
"""
bloques.py
-----------
Bloques de índices del ANALISIS DE PRECIOS: cada bloque es una redeterminación (columnas: índice base,
índice de la redeterminación, coeficiente y precio actualizado) con una fila por insumo. Se reconocen por
su estructura, sin importar cómo las armó la contratista (una hoja o varias, una o muchas
redeterminaciones una al lado de la otra, insumos identificados por Nº o por código del INDEC).
Lo comparten el control de análisis de precios y el de la planilla de costos.
"""
import re
import datetime as dt

from openpyxl.utils import get_column_letter as L

from .comunes import es_error, es_titulo_n, fecha, mes_txt, num, strip_accents, texto


class Bloque:
    def __init__(self):
        self.hoja = None
        self.cn = self.c_base = self.c_red = self.c_coef = self.c_precio = None
        self.fila_hdr = None
        self.m_base = self.m_red = None
        self.n_redet = None
        self.n_redet_cands = []        # números de redeterminación leídos de los encabezados (por prioridad)
        self.nota_redet = ''           # aviso si hubo que corregir el número
        self.v0_fila = None
        self.formula_txt = ''
        self.usa_anticipo = None      # True / False / None (no se pudo saber)
        self.a0_decl = self.v0_decl = None
        self.a0_fila = None
        self.seleccionado = True     # ¿el usuario pidió analizar este bloque?
        self.id_nombre = 'Nº'        # 'Nº' o 'Código' (cómo se identifica el insumo en este bloque)
        self.filas = []               # filas de insumos leídas

    @property
    def col_ini(self):
        """Primera columna del bloque: la del identificador si está pegada al bloque (Nº),
        o la del índice base si el identificador está más a la izquierda (código)."""
        return self.cn if self.cn >= self.c_base - 1 else self.c_base

    @property
    def etiqueta(self):
        return f"R{self.n_redet}" if self.n_redet else f"{mes_txt(self.m_base)}→{mes_txt(self.m_red)}"


# forma típica de un Nº de insumo (MO-02, EQ - 005, M.O -001, MAT. - 145...)
PATRON_NO = re.compile(r'^[A-Za-z][A-Za-z.\s]{0,9}[-\s.]*\d{1,4}$')
_RE_REDET = re.compile(r'(\d+)\s*[º°o]?\s*\.?\s*redet', re.IGNORECASE)
_RE_LABEL_AV = re.compile(r'^\s*([av])\s*0\s*(?:\(\s*r\s*(\d+)\s*\))?\s*=\s*$', re.IGNORECASE)


def _completar_bloque(ws, b):
    """Nº de redeterminación, fórmula declarada y A0/V0 escritos, leídos de los rótulos del bloque."""
    # El número sale del encabezado de la columna de la redeterminación ("6º REDET"), luego de la del precio
    # ("Precio 6º REDET.") y por último de la del coeficiente. Se guardan todos los candidatos: si el encabezado tiene un
    # error de tipeo (ej. "65º REDET"), después se elige el que sigue la secuencia y existe en la hoja AF.
    # Se busca cerca de la fila del encabezado real del bloque (b.fila_hdr), no siempre arriba de todo la
    # hoja: algunas plantillas traen antes un cálculo de coeficiente de pase, IVA, etc.
    r0, r1 = max(1, b.fila_hdr - 8), b.fila_hdr + 4
    b.n_redet_cands = []
    for cc in (b.c_red, b.c_precio, b.c_coef):
        for rr in range(r0, r1):
            m = _RE_REDET.search(texto(ws.cell(row=rr, column=cc).value))
            if m and int(m.group(1)) not in b.n_redet_cands:
                b.n_redet_cands.append(int(m.group(1)))
    if b.n_redet_cands:
        b.n_redet = b.n_redet_cands[0]
    for rr in range(r0, r1 + 2):
        t = texto(ws.cell(row=rr, column=b.c_precio).value)
        if re.match(r'^\s*d\s*=', t, re.IGNORECASE):
            b.formula_txt = t
            break
    if b.formula_txt:
        b.usa_anticipo = 'a0' in re.sub(r'\s', '', b.formula_txt.lower())
    for rr in range(r0, r1 + 4):
        lab = ws.cell(row=rr, column=b.c_precio - 1).value
        if isinstance(lab, str):
            m = _RE_LABEL_AV.match(lab)
            if m:
                val = num(ws.cell(row=rr, column=b.c_precio).value)
                if m.group(1).lower() == 'a':
                    b.a0_decl = val
                    b.a0_fila = rr
                else:
                    b.v0_decl = val
                    b.v0_fila = rr


def _detectar_bloques_por_nro(ws, nombre_hoja):
    """Planillas con una columna 'Nº' pegada a cada bloque de índices."""
    bloques = []
    vistos = set()
    maxc = min(ws.max_column, 300)
    maxr = min(ws.max_row, 60)      # el encabezado puede estar bastante más abajo si la hoja trae, antes
                                     # del análisis en sí, un cálculo de coeficiente de pase, IVA, etc.
    for r in range(1, maxr + 1):
        for c in range(1, maxc + 1):
            if c in vistos or not es_titulo_n(ws.cell(row=r, column=c).value):
                continue
            for rf in range(r, r + 4):
                fs = []
                for cc in range(c + 1, c + 6):
                    v = ws.cell(row=rf, column=cc).value
                    if isinstance(v, (dt.datetime, dt.date)):
                        fs.append((cc, fecha(v)))
                if len(fs) < 2:
                    continue
                c_red = fs[1][0]
                hdr = ' '.join(texto(ws.cell(row=rr, column=cc).value) for rr in range(max(1, r - 2), rf + 8)
                               for cc in (c_red + 1, c_red + 2)).lower()
                if not any(k in hdr for k in ('coef', 'adec', 'valor act', 'precio')):
                    continue
                b = Bloque()
                b.hoja, b.cn, b.fila_hdr = nombre_hoja, c, rf
                b.c_base, b.c_red, b.c_coef, b.c_precio = fs[0][0], c_red, c_red + 1, c_red + 2
                b.m_base, b.m_red = fs[0][1], fs[1][1]
                _completar_bloque(ws, b)
                bloques.append(b)
                vistos.add(c)
                break
    return bloques


def _detectar_bloques_por_fechas(ws, nombre_hoja, tabla):
    """Planillas SIN columna 'Nº': el insumo se identifica por el código del INDEC (o cualquier otra
    clave que figure en la hoja de índices). Los bloques se reconocen por dos fechas contiguas
    (base y redeterminación) seguidas de las columnas COEF. y VALOR ACT.; la columna de identidad se
    busca por CONTENIDO: la que tenga más celdas que existan en la hoja de índices."""
    bloques = []
    maxc = min(ws.max_column, 300)
    max_r = min(ws.max_row, 400)
    maxr_hdr = min(ws.max_row, 60)   # ver nota de más arriba: el encabezado puede estar bien abajo
    hechos = set()
    for rf in range(1, maxr_hdr + 1):
        for c in range(1, maxc):
            v1, v2 = ws.cell(row=rf, column=c).value, ws.cell(row=rf, column=c + 1).value
            if not (isinstance(v1, (dt.datetime, dt.date)) and isinstance(v2, (dt.datetime, dt.date))) or c in hechos:
                continue
            hdr = ' '.join(texto(ws.cell(row=rr, column=cc).value) for rr in range(max(1, rf - 2), rf + 8)
                           for cc in (c + 2, c + 3)).lower()
            if not any(k in hdr for k in ('coef', 'adec')):
                continue
            # columna de identidad: la de la izquierda con más claves conocidas
            cuenta = {}
            for rr in range(rf + 1, max_r + 1):
                for cc in range(1, c):
                    v = ws.cell(row=rr, column=cc).value
                    if isinstance(v, str) and v.strip() and v.strip() in tabla:
                        cuenta[cc] = cuenta.get(cc, 0) + 1
            if not cuenta:
                continue
            col_id, n = max(cuenta.items(), key=lambda kv: (kv[1], kv[0]))
            b = Bloque()
            b.hoja, b.cn, b.fila_hdr = nombre_hoja, col_id, rf
            b.c_base, b.c_red, b.c_coef, b.c_precio = c, c + 1, c + 2, c + 3
            b.m_base, b.m_red = fecha(v1), fecha(v2)
            b.id_nombre = 'Código'
            _completar_bloque(ws, b)
            bloques.append(b)
            hechos.add(c)
    return bloques


def detectar_bloques(ws, nombre_hoja, tabla=None):
    """Bloques de índices de una hoja de análisis. Primero busca el formato con columna 'Nº';
    si no hay, y se dio la tabla de índices, busca el formato de identificación por código."""
    bloques = _detectar_bloques_por_nro(ws, nombre_hoja)
    if not bloques and tabla:
        bloques = _detectar_bloques_por_fechas(ws, nombre_hoja, tabla)
    bloques.sort(key=lambda b: b.c_base)
    return bloques


def _nombre_fila(ws, r, hasta_col):
    """Texto descriptivo del insumo en esa fila: el texto más largo a la izquierda del identificador."""
    mejor = ''
    for c in range(1, hasta_col):
        v = ws.cell(row=r, column=c).value
        if isinstance(v, str) and len(v.strip()) > len(mejor) and not num(v):
            mejor = v.strip()
    return mejor


def _leer_filas_bloque(ws, b, tabla):
    """Filas de insumos del bloque: las que tienen un identificador (Nº o código) reconocible."""
    cands = sorted(set(range(max(1, min(b.cn, b.c_base) - 16), b.c_base)))
    filas = []
    for r in range(b.fila_hdr + 1, ws.max_row + 1):
        no = ws.cell(row=r, column=b.cn).value
        if not isinstance(no, str) or not no.strip():
            continue
        no = no.strip()
        f = {'r': r, 'no': no,
             'base': ws.cell(row=r, column=b.c_base).value,
             'red': ws.cell(row=r, column=b.c_red).value,
             'coef': ws.cell(row=r, column=b.c_coef).value,
             'precio': ws.cell(row=r, column=b.c_precio).value}
        if b.id_nombre == 'Nº':
            valido = no in tabla or es_error(no) or PATRON_NO.match(no)
        else:      # por código: se considera un insumo si el código existe, da error, o la fila trae índices
            titulo = re.sub(r'[\s.]+', '', strip_accents(no.lower())).startswith('codigo')
            valido = (no in tabla or es_error(no) or
                      (not titulo and any(num(f[k]) is not None or es_error(f[k]) for k in ('base', 'red'))))
        if valido:
            f['izq'] = {c: num(ws.cell(row=r, column=c).value) for c in cands}
            f['nombre'] = _nombre_fila(ws, r, b.cn) if b.id_nombre != 'Nº' else ''
            filas.append(f)
    b.filas = filas
    return filas


def construir_bloque_manual(ws, nombre_hoja, tabla, c_base, c_red, c_coef, c_precio, c_id=None):
    """Arma UN bloque de análisis de precios a partir de columnas indicadas A MANO (para cuando la
    detección automática no encontró ninguna hoja con esa estructura). c_* son números de columna
    (usar column_index_from_string para convertir una letra). c_id: columna del Nº/código del insumo;
    si no se da, se usa la columna a la izquierda del índice base (como en la mayoría de las plantillas).
    Los meses (base/redet.) se intentan leer de los encabezados de esas columnas, igual que en la
    detección automática; si no se encuentran, el bloque igual se arma (sin mes conocido)."""
    b = Bloque()
    b.hoja = nombre_hoja
    b.c_base, b.c_red, b.c_coef, b.c_precio = c_base, c_red, c_coef, c_precio
    b.cn = c_id if c_id else max(1, c_base - 1)
    b.id_nombre = 'Código' if c_id else 'Nº'
    b.fila_hdr = 1
    for r in range(1, 16):
        if any(texto(ws.cell(row=r, column=c).value) for c in (c_base, c_red, c_coef, c_precio)):
            b.fila_hdr = r
    for col, attr in ((c_base, 'm_base'), (c_red, 'm_red')):
        for r in range(1, 16):
            v = ws.cell(row=r, column=col).value
            if isinstance(v, (dt.datetime, dt.date)):
                setattr(b, attr, fecha(v))
                break
    _completar_bloque(ws, b)
    _leer_filas_bloque(ws, b, tabla)
    if not b.filas:
        raise ValueError(f"No encontré ninguna fila con datos usando esas columnas en la hoja '{nombre_hoja}' "
                          f"(columna del Nº/código: {L(b.cn)}). Revisá que sean las columnas correctas.")
    return b


def vista_previa_columnas(ws, filas=12, columnas=None):
    """[(letra, [muestras no vacías de las primeras 'filas' filas])] de las columnas con algún dato, para
    mostrarle al usuario qué hay en cada una y que elija bien a mano. Por defecto recorre TODA la hoja
    (hasta donde tiene datos): en un análisis de precios con varias redeterminaciones una al lado de la
    otra, las columnas que importan pueden estar bien a la derecha (columna 100 o más)."""
    tope = columnas or min(max(ws.max_column, 1), 400)
    out = []
    for c in range(1, tope + 1):
        muestras = []
        for r in range(1, filas + 1):
            v = ws.cell(row=r, column=c).value
            if v not in (None, ''):
                if isinstance(v, (dt.datetime, dt.date)):
                    muestras.append(mes_txt(fecha(v)))
                elif isinstance(v, float):
                    muestras.append(f"{v:.6g}")
                else:
                    muestras.append(str(v)[:28])
        if muestras:
            out.append((L(c), muestras))
    return out


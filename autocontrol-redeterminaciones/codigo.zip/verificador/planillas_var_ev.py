# -*- coding: utf-8 -*-
"""
planillas_var_ev.py  --  GENERAR las planillas VAR y EV con los índices oficiales
---------------------------------------------------------------------------------
No verifica: ARMA. Toma de la planilla de la contratista la ESTRUCTURA de cada redeterminación (qué insumos,
con qué composición, a qué cuadro del INDEC remite cada uno y entre qué meses va cada redeterminación) y
completa el mismo cuadro con los índices del boletín del INDEC de cada mes:

  VAR  una tabla por redeterminación: insumo | composición | índice del mes anterior | índice del mes de la
       redeterminación | variación (= actual / anterior) | resultante (= variación x composición) | INDEC,
       y la variación de referencia (= suma de resultantes - 1).
  EV   la evolución mes a mes entre una redeterminación y la siguiente: los índices de TODOS los meses
       intermedios y, abajo, la variación de referencia de cada mes respecto del primero.

Cada planilla es distinta (cada obra tiene sus insumos y su composición), así que nada está fijo: todo sale
del Excel. Lo que necesita es que la planilla de la contratista tenga, en alguna hoja, el encabezado
"Composición" con los meses al lado (como fecha, como texto "MAYO 2025" / "1º REDETERM. MAYO 2025", o el mes
arriba y el año abajo).

Qué índice es cada insumo (en este orden):
  1) el que haya asignado el administrador (Herramientas del administrador -> Índices de la VAR);
  2) la referencia que escribió la contratista al lado (Cuadro / código / descripción);
  3) el inciso del Decreto 1295/02 que corresponde al nombre ("MANO DE OBRA" -> a), "CEMENTO" -> n)...),
     confirmado contra el valor que puso la contratista cuando se puede;
  4) si no, la fila del boletín cuyo valor coincide con el de la contratista (identificado por valor).
Lo que no es un índice del INDEC (costo financiero / tasa BNA) se copia de la planilla de la contratista y
queda marcado para controlarlo a mano.

De qué boletín sale cada mes: del boletín PUBLICADO PARA ese mes (el de noviembre trae octubre). Si no está en
la biblioteca, se usa el boletín posterior más cercano que lo traiga (queda marcado en naranja, porque los
últimos meses del ICC son provisorios y pueden cambiar). Si ninguno lo trae, la celda queda en amarillo.
"""
import datetime as dt
import os
import re

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.worksheet.pagebreak import Break
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L

from .comunes import (ErrorVerificacion, MESES_LARGOS, TOL_INDICE, fecha, mes_txt, num,
                      strip_accents, texto)
from .excel import hojas_de_datos, leer_rango
from .pdf_indec import ART15_INCISO_RE, parsear_cuadro4, valores_en_linea
from .var import (CUADRO_CELDA_RE, _valor_en_boletin, clave_categoria, identificar_referencia,
                  inciso_para_categoria, numero_de_cuadro, texto_referencia)

MESES_NOMBRE = ['ENERO', 'FEBRERO', 'MARZO', 'ABRIL', 'MAYO', 'JUNIO', 'JULIO', 'AGOSTO', 'SEPTIEMBRE',
                'OCTUBRE', 'NOVIEMBRE', 'DICIEMBRE']

# ----------------------------------------------------------------------
# 1) Leer la estructura de la planilla de la contratista
# ----------------------------------------------------------------------
_MES_LARGO_RE = re.compile(r'\b(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|'
                           r'noviembre|diciembre)\b\W*(?:de\s+|del\s+)?(\d{4}|\d{2}\b)?')
_ANIO_RE = re.compile(r'^\s*(19|20)\d{2}\s*$')
_NO_INDEC_REF_RE = re.compile(r'\b(bna|bcra|tna|tasa|banco)\b')


def _mes_de_texto(v):
    """(año, mes) | ('SOLO_MES', mes) | None, para un encabezado escrito como texto."""
    f = fecha(v)
    if f:
        return f
    if not isinstance(v, str):
        return None
    s = strip_accents(v.strip().lower()).replace('setiembre', 'septiembre')
    m = _MES_LARGO_RE.search(s)
    if not m:
        return None
    mes = MESES_LARGOS[m.group(1)]
    if m.group(2):
        a = int(m.group(2))
        return (a + 2000 if a < 100 else a, mes)
    if re.fullmatch(r'\s*' + m.group(1) + r'\s*', s):          # la celda dice SOLO el mes: el año va abajo
        return ('SOLO_MES', mes)
    return None


def _anio(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool) and 1990 <= v <= 2100 and v == int(v):
        return int(v)
    if isinstance(v, str) and _ANIO_RE.match(v):
        return int(v.strip())
    return None


def _txt(g, r, c):
    if r < 1 or c < 1 or r > len(g) or c > len(g[r - 1]):
        return None
    return g[r - 1][c - 1]


def _es(v, *palabras):
    return isinstance(v, str) and any(p in strip_accents(v.lower()) for p in palabras)


def _numero_redet(*textos):
    """'1º REDETERMINACION', 'REDET. N° 3', '2ª REDET.' -> 3. 'BASE' / 'MES BASE' -> 0."""
    for t in textos:
        if not isinstance(t, str):
            continue
        s = strip_accents(t.lower())
        m = re.search(r'(\d{1,2})\s*[º°ªo]?\.?\s*redet', s) or re.search(r'redet\w*\.?\s*n?\s*[º°o.]*\s*(\d{1,2})', s)
        if m:
            return int(m.group(1))
        if re.search(r'\bbase\b', s):
            return 0
    return None


def _cols_de_meses(g, r, c_desde, c_hasta):
    """Columnas de mes del encabezado de la fila r (mirando también las 2 filas de abajo, donde algunas
    planillas ponen la fecha o el año). Devuelve ({col: (año, mes)}, {col: texto del encabezado}, última fila usada)."""
    meses, rotulos, ult = {}, {}, r
    for c in range(c_desde, c_hasta + 1):
        for dr in (0, 1, 2):
            v = _txt(g, r + dr, c)
            ym = _mes_de_texto(v)
            if ym is None:
                continue
            if ym[0] == 'SOLO_MES':
                a = _anio(_txt(g, r + dr + 1, c))
                if a is None:
                    break
                ym = (a, ym[1])
                ult = max(ult, r + dr + 1)
            else:
                ult = max(ult, r + dr)
            meses[c] = ym
            rot = _txt(g, r, c)
            rotulos[c] = rot.strip() if isinstance(rot, str) else ''
            break
    return meses, rotulos, ult


def _col_referencia(g, r_ini, r_fin, excluir, c_max):
    cuenta = {}
    for rr in range(r_ini, r_fin + 1):
        for c in range(1, c_max + 1):
            if c in excluir:
                continue
            v = _txt(g, rr, c)
            if isinstance(v, str) and CUADRO_CELDA_RE.match(strip_accents(v)):
                cuenta[c] = cuenta.get(c, 0) + 1
    if not cuenta:
        return None
    return max(cuenta.items(), key=lambda kv: (kv[1], -kv[0]))[0]


def _bloques_de_hoja(nombre, g):
    """Bloques (una tabla de VAR o de EV cada uno) de una hoja leída a memoria."""
    bloques = []
    n_filas = len(g)
    c_max = max((len(f) for f in g), default=0)
    fin_anterior = 0
    r = 1
    while r <= n_filas:
        c_comp = next((c for c in range(1, c_max + 1) if _es_composicion(_txt(g, r, c))), None)
        if c_comp is None:
            r += 1
            continue
        meses, rotulos, ult = _cols_de_meses(g, r, c_comp + 1, c_max)
        if len(meses) < 2:
            r += 1
            continue
        c_ins = next((c for c in range(1, c_comp) if _es(_txt(g, r, c), 'insumo', 'rubro', 'categor', 'concepto')), None)
        # rótulo de cada columna de mes ('MES BASE', 'REDET. N° 1'...): en la fila del encabezado o en la de arriba
        for c in meses:
            if not rotulos[c]:
                arriba = _txt(g, r - 1, c)
                if isinstance(arriba, str) and _es(arriba, 'base', 'redet', 'corte', 'mes'):
                    rotulos[c] = arriba.strip()
        c_var = next((c for c in range(c_comp + 1, c_max + 1) if c not in meses and _es(_txt(g, r, c), 'variaci')), None)
        c_res = next((c for c in range(c_comp + 1, c_max + 1) if c not in meses and _es(_txt(g, r, c), 'resultante')), None)
        c_ref = _col_referencia(g, ult + 1, min(n_filas, ult + 60), set(meses) | {c_comp}, c_max)
        if c_ref is None:
            c_ref = next((c for c in list(range(c_comp + 1, c_max + 1)) + list(range(1, c_comp))
                          if c not in meses and c != c_ins
                          and any(_es(_txt(g, r + dr, c), 'indec', 'ubicaci', 'indicador', 'fuente') for dr in (-1, 0, 1))), None)
        # columnas de la referencia: hasta 3 a partir de c_ref, sin pisar la del insumo / composición / meses
        cols_ref = []
        if c_ref:
            tope = (c_ins or c_comp) if c_ref < c_comp else c_max + 1
            cols_ref = [c for c in range(c_ref, c_ref + 3) if c < tope and c not in meses and c not in (c_comp, c_ins, c_var, c_res)]

        insumos, vacias, rr = [], 0, ult + 1
        while rr <= n_filas:
            fila_txt = [_txt(g, rr, c) for c in range(1, c_max + 1)]
            if any(_es_composicion(v) for v in fila_txt):
                break                                                  # empieza otro bloque
            etiqueta = None
            if c_ins and isinstance(_txt(g, rr, c_ins), str) and _txt(g, rr, c_ins).strip():
                etiqueta = _txt(g, rr, c_ins).strip()
            else:
                for c in range(1, c_comp):
                    v = _txt(g, rr, c)
                    if c not in cols_ref and isinstance(v, str) and len(v.strip()) >= 2:
                        etiqueta = v.strip()
            if etiqueta and re.match(r'^(sub\s*)?total', strip_accents(etiqueta.lower())):
                fin = rr
                break
            if any(_es(v, 'variacion de referencia', 'variación de referencia') for v in fila_txt):
                fin = rr
                break
            comp = num(_txt(g, rr, c_comp))
            valores = {meses[c]: num(_txt(g, rr, c)) for c in meses}
            if not etiqueta or (comp is None and not any(v is not None for v in valores.values())):
                vacias += 1
                if vacias >= 3 and insumos:
                    break
                rr += 1
                continue
            vacias = 0
            ref = None
            if cols_ref:
                ref = [texto(_txt(g, rr, c)) for c in cols_ref] + [''] * (3 - len(cols_ref))
                if not any(ref):
                    ref = None
            nro = _txt(g, rr, min(c for c in [c_ins or c_comp, c_comp]) - 1) if (c_ins or c_comp) > 1 else None
            insumos.append({'fila': rr, 'nombre': etiqueta, 'comp': comp, 'nro': nro if isinstance(nro, (int, float)) else None,
                            'valores': valores, 'celdas': {meses[c]: f"{L(c)}{rr}" for c in meses}, 'ref': ref,
                            'ref_celdas': [texto(_txt(g, rr, c)) for c in cols_ref[:2]]})
            rr += 1
        else:
            fin = rr
        fin = min(rr, n_filas)
        if insumos:
            # títulos del bloque (PROVINCIA..., CÁLCULO DE..., EMPRESA..., OBRA...): las filas de texto de arriba
            desde = max(fin_anterior + 1, r - 16)
            titulos = []
            for t in range(desde, r):
                textos = [(c, _txt(g, t, c)) for c in range(1, c_max + 1)]
                textos = [(c, v.strip()) for c, v in textos if isinstance(v, str) and v.strip()]
                if textos:
                    titulos.append((t - r, textos))
            # se arranca en la primera fila que parece un título (así no se arrastra el pie del bloque anterior,
            # ej. 'EL COEFICIENTE ... RESULTA MAYOR AL 5%')
            k0 = next((i for i, (_, tx) in enumerate(titulos)
                       if any(_es(v, 'provincia', 'calculo', 'cálculo', 'instituto', 'empresa', 'obra', 'licitaci', 'redeterm')
                              for _, v in tx)), 0)
            titulos = titulos[k0:]
            titulo_txt = ' '.join(v for _, tx in titulos for _, v in tx)
            orden = sorted(meses)
            bloques.append({
                'hoja': nombre, 'fila': r, 'fin': fin, 'titulos': titulos, 'c_comp': c_comp,
                'meses': [meses[c] for c in orden], 'rotulos': [rotulos[c] for c in orden],
                'insumos': insumos, 'c_var': c_var, 'c_res': c_res,
                'es_ev': len(meses) > 2 or _es(nombre, 'ev', 'evoluc') and len(meses) > 2 or _es(titulo_txt, 'evoluci'),
                'numero': _numero_redet(*[v for _, tx in titulos for _, v in tx]) if titulos else None,
                'rotulo_redet': _numero_redet(rotulos[orden[-1]]),
            })
            fin_anterior = fin
        r = max(fin, r) + 1
    return bloques


def _es_composicion(v):
    """Encabezado de la columna de composición / ponderación de cada insumo."""
    return _es(v, 'composici', 'ponderaci', 'incidencia') or (isinstance(v, str) and v.strip() == '%')


def _hojas_candidatas(wb):
    hojas = hojas_de_datos(wb)
    pref = [n for n in hojas if re.search(r'(?<![a-z])(var|ev|evol\w*|variaci\w*)(?![a-z])', strip_accents(n.lower()).strip())
            or ('cat' in n.lower() and 'obra' in n.lower())]
    return pref or hojas


def _leer(ws, max_col, max_row):
    max_col, max_row = min(ws.max_column, max_col), min(ws.max_row, max_row)
    if hasattr(ws, '_sheet'):
        # .xls: celda por celda, para que las fechas lleguen como fecha (leer_rango las deja como número de serie)
        return [[ws.cell(row=r, column=c).value for c in range(1, max_col + 1)] for r in range(1, max_row + 1)]
    return leer_rango(ws, max_col, max_row)


def leer_estructura(wb, hojas=None):
    """Todos los bloques (VAR y EV) que trae el Excel de la contratista."""
    bloques = []
    candidatas = hojas or _hojas_candidatas(wb)
    for n in candidatas:
        try:
            g = _leer(wb[n], 40, 3000)
        except Exception:
            continue
        bloques.extend(_bloques_de_hoja(n, g))
    if not bloques and not hojas:
        for n in hojas_de_datos(wb):
            if n in candidatas:
                continue
            try:
                g = _leer(wb[n], 40, 600)
            except Exception:
                continue
            bloques.extend(_bloques_de_hoja(n, g))
    return bloques


def periodos(bloques):
    """Las redeterminaciones del Excel: [(mes anterior, mes de la redeterminación, n.°, bloque VAR, bloque EV)].
    Salen de los bloques de VAR (dos meses); si la planilla no tiene VAR, de los de EV (primer y último mes)."""
    var = [b for b in bloques if not b['es_ev'] and len(b['meses']) == 2]
    ev = [b for b in bloques if b['es_ev']]
    base = var or ev
    # Varios bloques que arrancan del MISMO mes (ej. DIC→FEB, DIC→MAR, DIC→ABR, DIC→MAY, todos "REDET. N° 1") son la
    # evolución mes a mes hecha con bloques de VAR: la redeterminación es la del último mes; los otros solo aportan
    # los valores intermedios de la contratista (ver _valor_contratista).
    ultimo = {}
    for b in base:
        ini, fin = b['meses'][0], b['meses'][-1]
        k = (ini, b.get('rotulo_redet') or b.get('numero'))
        if ini < fin and (k not in ultimo or fin > ultimo[k]['meses'][-1]):
            ultimo[k] = b
    out = []
    for (ini, _), b in ultimo.items():
        fin = b['meses'][-1]
        b_ev = next((e for e in ev if e['meses'][0] == ini and e['meses'][-1] == fin), None) \
            or next((e for e in ev if e['meses'][0] == ini), None)
        b_var = b if b in var else None
        out.append({'ini': ini, 'fin': fin, 'numero': b.get('rotulo_redet') or b.get('numero'),
                    'var': b_var, 'ev': b_ev, 'estructura': b, 'todos': bloques, 'notas': []})
    out.sort(key=lambda p: (p['fin'], p['ini']))
    # numeración: si no se pudo leer, por orden (1, 2, 3...)
    for i, p in enumerate(out, start=1):
        if not p['numero']:
            p['numero'] = i
    # Cada redeterminación arranca del mes de la ANTERIOR. Si la planilla dice otro mes (ej. la R2 con "ENE-2026" como
    # mes anterior cuando la R1 es de ABR-2026), se usa el de la anterior y se avisa.
    for prev, p in zip(out, out[1:]):
        if p['ini'] != prev['fin'] and prev['fin'] < p['fin']:
            p['notas'].append(f"La planilla toma {mes_txt(p['ini'])} como mes anterior de la R{p['numero']}, pero la "
                              f"R{prev['numero']} es de {mes_txt(prev['fin'])}: se usa {mes_txt(prev['fin'])}.")
            _remapear_mes(p, p['ini'], prev['fin'])
            p['ini'] = prev['fin']
    return out


def _remapear_mes(p, viejo, nuevo):
    """La columna que la contratista rotuló 'viejo' pasa a ser la de 'nuevo' en los bloques de esta redeterminación
    (copias: el bloque original no se toca), para comparar sus valores contra el mes correcto."""
    for clave in ('var', 'ev', 'estructura'):
        b = p.get(clave)
        if not b or viejo not in b['meses']:
            continue
        nb = dict(b, meses=[nuevo if m == viejo else m for m in b['meses']], insumos=[])
        for ins in b['insumos']:
            ni = dict(ins)
            ni['valores'] = {(nuevo if m == viejo else m): v for m, v in ins['valores'].items()}
            ni['celdas'] = {(nuevo if m == viejo else m): v for m, v in ins['celdas'].items()}
            nb['insumos'].append(ni)
        if p.get('estructura') is b:
            p['estructura'] = nb
        p[clave] = nb


# ----------------------------------------------------------------------
# 2) Qué índice del INDEC es cada insumo y cuánto vale cada mes
# ----------------------------------------------------------------------
def _meses_entre(ini, fin):
    out, (a, m) = [], ini
    while (a, m) <= fin:
        out.append((a, m))
        a, m = (a + 1, 1) if m == 12 else (a, m + 1)
    return out


def boletin_del_mes(boletines, ym):
    """(boletín, 'propio' | 'otro') o (None, None). 'propio' = el publicado para ese mes (su último mes es ese)."""
    propio = next((b for b in boletines if b.ultimo_mes == ym), None)
    if propio:
        return propio, 'propio'
    posteriores = sorted((b for b in boletines if ym in b.meses), key=lambda b: b.ultimo_mes)
    if posteriores:
        return posteriores[0], 'otro'
    return None, None


def _prefijo_linea(line):
    """Texto de una fila del boletín antes del primer número (para reconocer la MISMA fila en otro boletín)."""
    m = re.search(r'-?\d{1,3}(?:\.\d{3})*,\d', line)
    t = line[:m.start()] if m else line
    return re.sub(r'\s+', '', strip_accents(t.lower()))


def _identificar_por_valor(boletin, valor, ym, cuadro=None):
    """Busca en el boletín la fila cuyo valor de ese mes es el de la contratista. Devuelve un 'ref' o None."""
    off = boletin.offset(ym)
    if off is None or valor is None:
        return None
    orden = ([cuadro] if cuadro in boletin.rangos else []) + [c for c in sorted(boletin.rangos) if c != cuadro]
    for cu in orden:
        rng = boletin.rangos[cu]
        if cu == 4:                                          # cuadro 4: transpuesto (meses en filas)
            cols, filas = parsear_cuadro4(boletin.lines, rng)
            for letra, v in zip(cols, filas.get(ym) or []):
                if num(v) is not None and abs(num(v) - valor) <= TOL_INDICE:
                    return {'tipo': 'inciso', 'clave': letra, 'cuadro': 4, 'origen': 'valor'}
            continue
        for i in range(*rng):
            vals = valores_en_linea(boletin.lines[i])
            if len(vals) != len(boletin.meses):
                continue
            v = num(vals[-(off + 1)])
            if v is not None and abs(v - valor) <= TOL_INDICE:
                pref = _prefijo_linea(boletin.lines[i])
                if len(pref) >= 3:
                    m = re.search(r'-?\d{1,3}(?:\.\d{3})*,\d', boletin.lines[i])
                    desc = boletin.lines[i][:m.start()] if m else boletin.lines[i]
                    return {'tipo': 'linea', 'clave': pref, 'cuadro': cu, 'origen': 'valor',
                            'texto': re.sub(r'\s+', ' ', desc).strip()[:70]}
    return None


def valor_oficial(boletin, ref, ym):
    """Valor del índice 'ref' para el mes ym en ese boletín (o None)."""
    if ref['tipo'] == 'linea':
        off = boletin.offset(ym)
        if off is None or ref['cuadro'] not in boletin.rangos:
            return None
        for i in range(*boletin.rangos[ref['cuadro']]):
            if _prefijo_linea(boletin.lines[i]) == ref['clave']:
                vals = valores_en_linea(boletin.lines[i])
                if len(vals) == len(boletin.meses):
                    return num(vals[-(off + 1)])
        return None
    r = _valor_en_boletin(boletin, ref, ym)
    return r[0] if r else None


def _es_no_indec(ins, manual):
    if manual is not None:
        return bool(manual.get('no_aplica'))
    if inciso_para_categoria(ins['nombre']) == 'NO_APLICA':
        return True
    ref = ins.get('ref') or []
    cab = strip_accents(' '.join(ref[:2]).lower())
    return bool(ref) and numero_de_cuadro(ref[0]) is None and bool(_NO_INDEC_REF_RE.search(cab))


def identificar(ins, boletines, manuales=None):
    """{'tipo': ...} con el índice del INDEC del insumo, {'tipo': 'NO_INDEC'} o None (no se pudo)."""
    manual = (manuales or {}).get(clave_categoria(ins['nombre']))
    if _es_no_indec(ins, manual):
        return {'tipo': 'NO_INDEC'}
    referencia = ins.get('ref')
    if manual:
        referencia = [f"Cuadro {manual['cuadro']}" if manual.get('cuadro') else '',
                      str(manual.get('codigo') or '').strip(), str(manual.get('desc') or '').strip()]
    ref = identificar_referencia(referencia)
    if ref is None and referencia:
        # 'Art 15 Inciso (a)' / 'Art.15 inciso (c)' escrito en cualquiera de las celdas de la referencia
        for t in referencia:
            m = ART15_INCISO_RE.search(t or '')
            if m:
                ref = {'tipo': 'inciso', 'clave': m.group(1).lower(), 'cuadro': numero_de_cuadro(referencia[0])}
                break
    if ref:
        ref['origen'] = 'manual' if manual else 'planilla'
        return ref
    cuadro = numero_de_cuadro(referencia[0]) if referencia else None
    # un mes con valor de la contratista y con su boletín propio, para confirmar / identificar por valor
    prueba = None
    for ym, v in sorted(ins['valores'].items()):
        b, tipo = boletin_del_mes(boletines, ym)
        if v is not None and b is not None and tipo == 'propio':
            prueba = (b, ym, v)
    letra = inciso_para_categoria(ins['nombre'])
    por_nombre = {'tipo': 'inciso', 'clave': letra, 'cuadro': cuadro, 'origen': 'nombre'} if letra else None
    if prueba:
        b, ym, v = prueba
        if por_nombre:
            vo = valor_oficial(b, por_nombre, ym)
            if vo is not None and abs(vo - v) <= TOL_INDICE:
                return por_nombre
        por_valor = _identificar_por_valor(b, v, ym, cuadro)
        if por_valor:
            return por_valor
    return por_nombre


def describir_ref(ref):
    if not ref:
        return 'sin identificar'
    if ref['tipo'] == 'NO_INDEC':
        return 'no es índice INDEC'
    if ref['tipo'] == 'linea':
        return f"Cuadro {ref['cuadro']}: {ref.get('texto', '')} [identificado por valor]"
    t = texto_referencia(ref)
    if ref.get('origen') == 'valor':
        t += ' [identificado por valor]'
    elif ref.get('origen') == 'manual':
        t += ' [asignado por el administrador]'
    return t


# ----------------------------------------------------------------------
# 3) Calcular las tablas
# ----------------------------------------------------------------------
def _valor_contratista(p, ins_idx, nombre, ym):
    """Valor que puso la contratista para ese insumo y mes (en la VAR o en la EV), y su celda."""
    otros = [b for b in p.get('todos') or [] if ym in b['meses'] and b['meses'][0] == p['ini']] + \
            [b for b in p.get('todos') or [] if ym in b['meses']]
    for b in [p['var'], p['ev'], p['estructura']] + otros:
        if not b or ym not in b['meses']:
            continue
        ins = b['insumos'][ins_idx] if ins_idx < len(b['insumos']) and \
            clave_categoria(b['insumos'][ins_idx]['nombre']) == clave_categoria(nombre) else \
            next((x for x in b['insumos'] if clave_categoria(x['nombre']) == clave_categoria(nombre)), None)
        if ins and ins['valores'].get(ym) is not None:
            return ins['valores'][ym], f"{b['hoja'].strip()}!{ins['celdas'][ym]}"
    return None, None


def calcular(estructura, boletines, manuales=None):
    """Para cada redeterminación: los insumos con el valor oficial de cada mes (VAR = sus dos meses; EV = todos
    los meses entre ambos). Devuelve la lista de períodos con 'filas' y 'meses_ev' completos."""
    pers = periodos(estructura)
    if not pers:
        raise ErrorVerificacion("No encontré en el Excel ninguna tabla de variación de referencia (un encabezado "
                                "«Composición» con los meses de la redeterminación al lado).")
    refs = {}
    for p in pers:
        p['meses_ev'] = _meses_entre(p['ini'], p['fin'])
        p['filas'] = []
        for i, ins in enumerate(p['estructura']['insumos']):
            k = (clave_categoria(ins['nombre']), tuple(ins.get('ref') or ()))
            if k not in refs:
                # para identificar se usan todos los valores que la contratista puso para ese insumo en el Excel
                todos = dict(ins)
                todos['valores'] = {}
                for b in estructura:
                    for x in b['insumos']:
                        if clave_categoria(x['nombre']) == k[0]:
                            todos['valores'].update({m: v for m, v in x['valores'].items() if v is not None})
                refs[k] = identificar(todos, boletines, manuales)
            ref = refs[k]
            celdas = {}
            for ym in p['meses_ev']:
                v_c, celda_c = _valor_contratista(p, i, ins['nombre'], ym)
                d = {'contratista': v_c, 'celda_contratista': celda_c, 'valor': None, 'fuente': '', 'estado': ''}
                if ref and ref['tipo'] == 'NO_INDEC':
                    d.update(valor=v_c, estado='no_indec' if v_c is not None else 'falta',
                             fuente='Copiado de la planilla de la contratista (no es índice INDEC)' if v_c is not None
                             else 'No es índice INDEC y la planilla no trae este mes: completar a mano')
                elif ref is None:
                    d.update(estado='sin_ref', fuente='No pude identificar qué índice del INDEC es este insumo '
                                                       '(asignarlo en Herramientas del administrador -> Índices de la VAR)')
                else:
                    b, tipo = boletin_del_mes(boletines, ym)
                    v = valor_oficial(b, ref, ym) if b is not None else None
                    if v is None:
                        d.update(estado='falta', fuente=(f"El índice no aparece en '{b.nombre}'" if b is not None else
                                                         f"Falta el boletín del INDEC con {mes_txt(ym)} en la biblioteca"))
                    else:
                        d.update(valor=v, estado='ok' if tipo == 'propio' else 'otro_boletin',
                                 fuente=b.nombre if tipo == 'propio' else
                                 f"{b.nombre} (no está el boletín de {mes_txt(ym)}: dato que puede ser provisorio/revisado)")
                celdas[ym] = d
            p['filas'].append({'nro': ins.get('nro'), 'nombre': ins['nombre'], 'comp': ins['comp'],
                               'ref_celdas': ins.get('ref_celdas') or [], 'ref': ref, 'ref_txt': describir_ref(ref),
                               'meses': celdas})
        p['vr'] = _vr(p['filas'], p['ini'], p['fin'], 'valor')
        p['vr_contratista'] = _vr(p['filas'], p['ini'], p['fin'], 'contratista')
        p['vr_ev'] = {ym: _vr(p['filas'], p['ini'], ym, 'valor') for ym in p['meses_ev'][1:]}
    return pers


def _vr(filas, ini, fin, campo):
    tot = 0.0
    for f in filas:
        a, b = f['meses'][ini][campo], f['meses'][fin][campo]
        if a in (None, 0) or b is None or f['comp'] is None:
            return None
        tot += f['comp'] * b / a
    return tot - 1


# ----------------------------------------------------------------------
# 4) Escribir el Excel
# ----------------------------------------------------------------------
_F = 'Arial'
_T = Side(style='thin', color='808080')
_BORDE = Border(left=_T, right=_T, top=_T, bottom=_T)
_ENC = PatternFill('solid', fgColor='D9E1F2')
_TOT = PatternFill('solid', fgColor='F2F2F2')
COLORES = {
    'diferente': PatternFill('solid', fgColor='F8CBAD'),     # el valor de la contratista no es el oficial
    'otro_boletin': PatternFill('solid', fgColor='FCE4D6'),  # sale de otro boletín (no del de ese mes)
    'falta': PatternFill('solid', fgColor='FFF2CC'),         # no hay dato: completar
    'sin_ref': PatternFill('solid', fgColor='FFF2CC'),
    'no_indec': PatternFill('solid', fgColor='DDEBF7'),      # no es INDEC: copiado de la contratista
}
_FMT_IDX = '#,##0.0###'
_FMT_FRAC = '0.0000'


def _fecha_celda(ym):
    return dt.datetime(ym[0], ym[1], 1)


def _c(ws, r, c, v=None, bold=False, fmt=None, fill=None, borde=True, centro=False, size=10, italic=False):
    cel = ws.cell(row=r, column=c)
    if v is not None:
        cel.value = v
    cel.font = Font(name=_F, size=size, bold=bold, italic=italic)
    if fmt:
        cel.number_format = fmt
    if fill:
        cel.fill = fill
    if borde:
        cel.border = _BORDE
    cel.alignment = Alignment(horizontal='center' if centro else None, vertical='center', wrap_text=centro)
    return cel


def _titulos(ws, r, p, tipo, numero):
    """Las filas de título de la contratista (PROVINCIA..., EMPRESA..., OBRA...) con el título de esta tabla."""
    origen = (p['ev'] if tipo == 'EV' else p['var']) or p['estructura']
    lineas = []
    for _, textos in origen['titulos']:
        t = '   '.join(v for _, v in textos)
        if _es(t, 'calculo', 'cálculo', 'evoluci', 'variacion de referencia', 'variación de referencia'):
            continue                                              # el título se reescribe abajo
        lineas.append(t)
    titulo = (f"CÁLCULO DE EVOLUCIÓN VAR - {numero}º REDETERMINACIÓN" if tipo == 'EV' else
              f"CÁLCULO DE VARIACIÓN DE REFERENCIA - {numero}º REDETERMINACIÓN")
    _c(ws, r, 2, titulo, bold=True, size=12, borde=False)
    r += 1
    for t in lineas:
        _c(ws, r, 2, t, borde=False)
        r += 1
    _c(ws, r, 2, f"Índices oficiales del INDEC completados por el programa ({dt.date.today():%d/%m/%Y}). "
                 "Ver la hoja «Diferencias» y la leyenda de colores en «Fuentes».", italic=True, size=8, borde=False)
    return r + 2


def _comentario(d):
    partes = []
    if d['fuente']:
        partes.append(f"Fuente: {d['fuente']}")
    if d['contratista'] is not None and d['valor'] is not None and abs(d['contratista'] - d['valor']) > TOL_INDICE:
        partes.append(f"La contratista puso {d['contratista']:g} ({d['celda_contratista']})")
    return Comment('\n'.join(partes), 'Verificador', width=320, height=90) if partes else None


def _celda_indice(ws, r, c, d, comentar=True):
    fill = None
    if d['estado'] in ('falta', 'sin_ref', 'no_indec', 'otro_boletin'):
        fill = COLORES[d['estado']]
    if d['estado'] in ('ok', 'otro_boletin') and d['contratista'] is not None and abs(d['contratista'] - d['valor']) > TOL_INDICE:
        fill = COLORES['diferente']
    cel = _c(ws, r, c, d['valor'], fmt=_FMT_IDX, fill=fill)
    if comentar and (fill is not None):
        com = _comentario(d)
        if com:
            cel.comment = com
    return cel


def _escribir_var(ws, r, p):
    r = _titulos(ws, r, p, 'VAR', p['numero'])
    ini, fin = p['ini'], p['fin']
    rot = (p['var'] or {}).get('rotulos') or ['', '']
    enc = ['Nº', 'Insumos', 'Composición', rot[0] or ('MES BASE' if p['numero'] == 1 else f"{p['numero'] - 1}º REDET."),
           rot[-1] or f"{p['numero']}º REDET.", 'Variación', 'Resultante', 'INDEC', '']
    for j, t in enumerate(enc, start=1):
        _c(ws, r, j, t, bold=True, fill=_ENC, centro=True)
    ws.merge_cells(start_row=r, start_column=8, end_row=r, end_column=9)
    for j in range(1, 10):
        _c(ws, r + 1, j, fill=_ENC)
    _c(ws, r + 1, 4, _fecha_celda(ini), bold=True, fmt='mmm-yyyy', fill=_ENC, centro=True)
    _c(ws, r + 1, 5, _fecha_celda(fin), bold=True, fmt='mmm-yyyy', fill=_ENC, centro=True)
    r += 2
    r0 = r
    for i, f in enumerate(p['filas'], start=1):
        _c(ws, r, 1, f['nro'] if f['nro'] is not None else i, centro=True)
        _c(ws, r, 2, f['nombre'])
        _c(ws, r, 3, f['comp'], fmt='0.00##')
        _celda_indice(ws, r, 4, f['meses'][ini])
        _celda_indice(ws, r, 5, f['meses'][fin])
        _c(ws, r, 6, f"=IFERROR(E{r}/D{r},\"\")", fmt=_FMT_FRAC)
        _c(ws, r, 7, f"=IFERROR(F{r}*C{r},\"\")", fmt=_FMT_FRAC)
        refc = f['ref_celdas'] + ['', '']
        _c(ws, r, 8, refc[0] or (f['ref_txt'] if f['ref'] else ''))
        _c(ws, r, 9, refc[1])
        r += 1
    _c(ws, r, 2, 'Total', bold=True, fill=_TOT)
    _c(ws, r, 3, f"=SUM(C{r0}:C{r - 1})", bold=True, fmt='0.00', fill=_TOT)
    _c(ws, r, 4, 'Variación de Referencia', bold=True, fill=_TOT)
    ws.merge_cells(start_row=r, start_column=4, end_row=r, end_column=6)
    _c(ws, r, 7, f"=SUM(G{r0}:G{r - 1})-1", bold=True, fmt='0.00%', fill=_TOT)
    p['celda_vr_var'] = f"G{r}"
    faltan = sum(1 for f in p['filas'] for ym in (ini, fin) if f['meses'][ym]['valor'] is None)
    if faltan:
        _c(ws, r + 1, 2, f"⚠ Faltan {faltan} índice(s) (celdas amarillas): la variación de referencia no es definitiva.",
           bold=True, borde=False)
        r += 1
    for nota in p.get('notas') or []:
        _c(ws, r + 1, 2, f"⚠ {nota}", bold=True, borde=False)
        r += 1
    return r + 4


def _escribir_ev(ws, r, p):
    r = _titulos(ws, r, p, 'EV', p['numero'])
    meses = p['meses_ev']
    c0 = 4
    c_ref = c0 + len(meses)
    for j, t in enumerate(['Nº', 'Insumos', 'Composición'], start=1):
        _c(ws, r, j, t, bold=True, fill=_ENC, centro=True)
        _c(ws, r + 1, j, fill=_ENC)
    for k, ym in enumerate(meses):
        _c(ws, r, c0 + k, MESES_NOMBRE[ym[1] - 1], bold=True, fill=_ENC, centro=True)
        _c(ws, r + 1, c0 + k, ym[0], bold=True, fill=_ENC, centro=True)
    _c(ws, r, c_ref, 'INDEC', bold=True, fill=_ENC, centro=True)
    _c(ws, r, c_ref + 1, fill=_ENC)
    ws.merge_cells(start_row=r, start_column=c_ref, end_row=r, end_column=c_ref + 1)
    _c(ws, r + 1, c_ref, fill=_ENC)
    _c(ws, r + 1, c_ref + 1, fill=_ENC)
    r += 2
    r0 = r
    for i, f in enumerate(p['filas'], start=1):
        _c(ws, r, 1, f['nro'] if f['nro'] is not None else i, centro=True)
        _c(ws, r, 2, f['nombre'])
        _c(ws, r, 3, f['comp'], fmt='0.00##')
        for k, ym in enumerate(meses):
            _celda_indice(ws, r, c0 + k, f['meses'][ym])
        refc = f['ref_celdas'] + ['', '']
        _c(ws, r, c_ref, refc[0] or (f['ref_txt'] if f['ref'] else ''))
        _c(ws, r, c_ref + 1, refc[1])
        r += 1
    r1 = r - 1
    _c(ws, r, 2, 'Total', bold=True, fill=_TOT)
    _c(ws, r, 3, f"=SUM(C{r0}:C{r1})", bold=True, fmt='0.00', fill=_TOT)
    _c(ws, r, c0, 'BASE', bold=True, fill=_TOT, centro=True)
    base = L(c0)
    for k in range(1, len(meses)):
        col = L(c0 + k)
        _c(ws, r, c0 + k, f"=IFERROR(SUMPRODUCT($C${r0}:$C${r1},{col}{r0}:{col}{r1}/${base}${r0}:${base}${r1})-1,\"\")",
           bold=True, fmt='0.00%', fill=_TOT)
    _c(ws, r + 1, 2, 'Variación de referencia de cada mes respecto de ' + mes_txt(meses[0]) + '.', italic=True, size=8, borde=False)
    faltan = sum(1 for f in p['filas'] for ym in meses if f['meses'][ym]['valor'] is None)
    if faltan:
        _c(ws, r + 2, 2, f"⚠ Faltan {faltan} índice(s) (celdas amarillas): completar para que el cálculo sea definitivo.",
           bold=True, borde=False)
        r += 1
    return r + 4


def _anchos(ws, n_cols):
    ws.column_dimensions['A'].width = 5
    ws.column_dimensions['B'].width = 38
    ws.column_dimensions['C'].width = 13
    for c in range(4, n_cols + 1):
        ws.column_dimensions[L(c)].width = 14
    ws.sheet_view.showGridLines = False


def escribir(ruta, pers, nombre_excel, boletines):
    wb = Workbook()
    ws = wb.active
    ws.title = 'VAR'
    r = 2
    for i, p in enumerate(pers):
        if i:
            ws.row_breaks.append(Break(id=r - 2))
        r = _escribir_var(ws, r, p)
    _anchos(ws, 9)

    we = wb.create_sheet('EV')
    r = 2
    ancho = 0
    for i, p in enumerate(pers):
        if i:
            we.row_breaks.append(Break(id=r - 2))
        r = _escribir_ev(we, r, p)
        ancho = max(ancho, 5 + len(p['meses_ev']))
    _anchos(we, ancho)

    # Diferencias con la planilla de la contratista
    wd = wb.create_sheet('Diferencias')
    _c(wd, 1, 1, f"Diferencias entre los índices de la planilla de la contratista ({nombre_excel}) y los del INDEC",
       bold=True, size=12, borde=False)
    _c(wd, 2, 1, "Solo se listan los índices que NO coinciden (tolerancia: 0,05 puntos) y los que no se pudieron completar.",
       italic=True, size=9, borde=False)
    enc = ['Redet.', 'Tabla', 'Insumo', 'Mes', 'Celda contratista', 'Contratista', 'INDEC', 'Diferencia', 'Dif. %', 'Fuente / motivo']
    for j, t in enumerate(enc, start=1):
        _c(wd, 4, j, t, bold=True, fill=_ENC, centro=True)
    r = 5
    vistos = set()
    for p in pers:
        for f in p['filas']:
            for ym in p['meses_ev']:
                d = f['meses'][ym]
                tabla = 'VAR y EV' if ym in (p['ini'], p['fin']) else 'EV'
                dif = (d['contratista'] - d['valor']) if (d['contratista'] is not None and d['valor'] is not None) else None
                problema = d['estado'] in ('falta', 'sin_ref') or (dif is not None and abs(dif) > TOL_INDICE
                                                                       and d['estado'] != 'no_indec')
                k = (clave_categoria(f['nombre']), ym)
                if not problema or k in vistos:
                    continue
                vistos.add(k)
                fila = [f"R{p['numero']}", tabla, f['nombre'], mes_txt(ym), d['celda_contratista'] or '—', d['contratista'],
                        d['valor'], dif, (dif / d['valor']) if (dif is not None and d['valor']) else None, d['fuente']]
                for j, v in enumerate(fila, start=1):
                    _c(wd, r, j, v, fmt={6: _FMT_IDX, 7: _FMT_IDX, 8: '#,##0.0#', 9: '0.00%'}.get(j),
                       fill=COLORES['falta'] if d['valor'] is None else None)
                r += 1
    if r == 5:
        _c(wd, 5, 1, 'Todos los índices de la planilla de la contratista coinciden con los del INDEC.', borde=False)
        r = 6
    notas = [(p['numero'], n) for p in pers for n in p.get('notas') or []]
    if notas:
        r += 1
        _c(wd, r, 1, 'Meses de la planilla', bold=True, size=11, borde=False)
        r += 1
        for nro, n in notas:
            _c(wd, r, 1, f"R{nro}", fill=COLORES['diferente'])
            _c(wd, r, 2, n, borde=False)
            r += 1
    r += 2
    _c(wd, r, 1, 'Variación de referencia', bold=True, size=11, borde=False)
    r += 1
    for j, t in enumerate(['Redet.', 'Meses', 'Según la contratista', 'Con índices INDEC', 'Diferencia (puntos %)'], start=1):
        _c(wd, r, j, t, bold=True, fill=_ENC, centro=True)
    r += 1
    for p in pers:
        dif = (p['vr_contratista'] - p['vr']) * 100 if (p['vr'] is not None and p['vr_contratista'] is not None) else None
        for j, v in enumerate([f"R{p['numero']}", f"{mes_txt(p['ini'])} → {mes_txt(p['fin'])}", p['vr_contratista'], p['vr'], dif],
                              start=1):
            _c(wd, r, j, v, fmt={3: '0.00%', 4: '0.00%', 5: '0.00'}.get(j),
               fill=COLORES['diferente'] if (j == 5 and dif is not None and abs(dif) >= 0.005) else None)
        r += 1
    for col, w in zip('ABCDEFGHIJ', (8, 22, 34, 11, 16, 13, 13, 12, 10, 70)):
        wd.column_dimensions[col].width = w

    # Fuentes y leyenda
    wf = wb.create_sheet('Fuentes')
    _c(wf, 1, 1, 'De dónde sale cada dato', bold=True, size=12, borde=False)
    ley = [('Sin color', None, 'Índice del boletín del INDEC publicado para ese mes (coincide con la contratista o no la hay).'),
           ('Rojo claro', COLORES['diferente'], 'Índice oficial que NO coincide con el que puso la contratista (ver comentario de la celda).'),
           ('Naranja claro', COLORES['otro_boletin'], 'No está en la biblioteca el boletín de ese mes: se tomó de un boletín posterior '
                                                      '(los últimos meses del ICC son provisorios y el INDEC los revisa).'),
           ('Amarillo', COLORES['falta'], 'Sin dato: falta el boletín o no se pudo identificar el índice. Completar a mano.'),
           ('Celeste', COLORES['no_indec'], 'No es un índice del INDEC (ej. costo financiero, tasa BNA): copiado de la planilla de la '
                                            'contratista. Controlarlo con su fuente.')]
    for i, (t, fill, desc) in enumerate(ley, start=3):
        _c(wf, i, 1, t, fill=fill)
        _c(wf, i, 2, desc, borde=False)
    r = 3 + len(ley) + 1
    _c(wf, r, 1, 'Índice que se usó para cada insumo', bold=True, size=11, borde=False)
    r += 1
    for j, t in enumerate(['Insumo', 'Referencia de la contratista', 'Índice usado'], start=1):
        _c(wf, r, j, t, bold=True, fill=_ENC)
    r += 1
    vistos = set()
    for p in pers:
        for f in p['filas']:
            k = clave_categoria(f['nombre'])
            if k in vistos:
                continue
            vistos.add(k)
            _c(wf, r, 1, f['nombre'])
            _c(wf, r, 2, ' · '.join(x for x in f['ref_celdas'] if x))
            _c(wf, r, 3, f['ref_txt'], fill=COLORES['falta'] if not f['ref'] else None)
            r += 1
    r += 1
    _c(wf, r, 1, 'Boletín usado para cada mes', bold=True, size=11, borde=False)
    r += 1
    for j, t in enumerate(['Mes', 'Boletín', ''], start=1):
        _c(wf, r, j, t, bold=True, fill=_ENC)
    r += 1
    todos = sorted({ym for p in pers for ym in p['meses_ev']})
    for ym in todos:
        b, tipo = boletin_del_mes(boletines, ym)
        _c(wf, r, 1, mes_txt(ym))
        _c(wf, r, 2, b.nombre if b else 'FALTA en la biblioteca',
           fill=None if tipo == 'propio' else COLORES['otro_boletin' if b else 'falta'])
        _c(wf, r, 3, '' if tipo == 'propio' else ('no es el boletín de ese mes' if b else 'subir el boletín a la biblioteca'), borde=False)
        r += 1
    for col, w in zip('ABC', (36, 60, 60)):
        wf.column_dimensions[col].width = w

    for hoja in (ws, we):
        hoja.page_setup.orientation = 'landscape'
        hoja.page_setup.fitToWidth = 1
        hoja.page_setup.fitToHeight = 0
        hoja.sheet_properties.pageSetUpPr.fitToPage = True
    wb.save(ruta)
    return ruta


# ----------------------------------------------------------------------
# Todo junto
# ----------------------------------------------------------------------
def generar(wb, boletines, ruta_salida, nombre_excel='', manuales=None, solo_ultima=False):
    """Arma el Excel con las hojas VAR, EV, Diferencias y Fuentes. Devuelve (ruta, resumen)."""
    estructura = leer_estructura(wb)
    pers = calcular(estructura, boletines, manuales)
    if solo_ultima:
        pers = pers[-1:]
    escribir(ruta_salida, pers, nombre_excel, boletines)
    n_dif = sum(1 for p in pers for f in p['filas'] for ym in p['meses_ev']
                if f['meses'][ym]['estado'] in ('ok', 'otro_boletin') and f['meses'][ym]['contratista'] is not None
                and abs(f['meses'][ym]['contratista'] - f['meses'][ym]['valor']) > TOL_INDICE)
    n_falta = sum(1 for p in pers for f in p['filas'] for ym in p['meses_ev'] if f['meses'][ym]['valor'] is None)
    return ruta_salida, {'redeterminaciones': [f"R{p['numero']} ({mes_txt(p['ini'])} → {mes_txt(p['fin'])})" for p in pers],
                         'diferencias': n_dif, 'faltantes': n_falta, 'periodos': pers}


def main(argv=None):
    """Línea de comandos:  python -m verificador.planillas_var_ev Excel.xlsx --pdf a.pdf --pdf b.pdf [--out salida.xlsx]
    (o --boletines CARPETA para usar todos los PDF de una carpeta, ej. datos\\boletines)."""
    import argparse
    import glob
    from .excel import abrir_libro
    from .pdf_indec import Boletin
    from .comunes import configurar_consola, nombre_salida_unico
    configurar_consola()
    ap = argparse.ArgumentParser(description='Genera las planillas VAR y EV con los índices oficiales del INDEC.')
    ap.add_argument('excel')
    ap.add_argument('--pdf', action='append', default=[])
    ap.add_argument('--boletines', help='carpeta con los boletines (PDF)')
    ap.add_argument('--out')
    ap.add_argument('--solo-ultima', action='store_true')
    a = ap.parse_args(argv)
    pdfs = list(a.pdf)
    if a.boletines:
        pdfs += sorted(glob.glob(os.path.join(a.boletines, '*.pdf')))
    if not pdfs:
        raise SystemExit('Indicá los boletines con --pdf o --boletines.')
    bols = []
    for pth in pdfs:
        try:
            bols.append(Boletin(pth, progreso=False))
        except Exception as e:
            print(f"  (se ignora {os.path.basename(pth)}: {e})")
    wb = abrir_libro(a.excel)
    out = a.out or nombre_salida_unico(a.excel, os.path.dirname(os.path.abspath(a.excel)), 'Planillas VAR y EV')
    ruta, res = generar(wb, bols, out, os.path.basename(a.excel), solo_ultima=a.solo_ultima)
    print(f"Listo: {ruta}")
    print(f"  Redeterminaciones: {', '.join(res['redeterminaciones'])}")
    print(f"  Índices distintos a los de la contratista: {res['diferencias']} · sin dato: {res['faltantes']}")


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""
informe_pdf.py
---------------
Reporte en PDF PARA LA CONTRATISTA: corto y fácil de leer. Solo lo que tiene que corregir:

    1. Qué está mal (en una frase)
    2. En qué hoja y celda, qué dice y qué debería decir
    3. Qué tiene que hacer

No lleva la parte técnica (alcance, criterios, controles, impacto): eso sigue en el Excel de verificación y en
el informe Word. Las observaciones y celdas que van al PDF las elige el usuario antes de generarlo (ver
interfaz: "Reporte PDF para la contratista"), así se pueden sacar los avisos o errores que no corresponden.

Requiere 'reportlab' (lo instala setup.ps1).
"""
import datetime as dt
import os
import re

from .comunes import ErrorVerificacion, fmt_es

AZUL = '#1F4E78'
GRIS = '#595959'
COLOR_GRAV = {'ERROR': '#C00000', 'MENOR': '#BF8F00', 'AVISO': '#2E75B6'}
FONDO_GRAV = {'ERROR': '#FDE9E7', 'MENOR': '#FFF4D6', 'AVISO': '#E8F1FA'}
NOMBRE_GRAV = {'ERROR': 'Error', 'MENOR': 'Diferencia menor', 'AVISO': 'Aviso'}

# Fuentes TrueType con acentos y símbolos (→, ≠, …). En Windows está Arial; si no aparece ninguna se usa
# Helvetica (sin algunos símbolos: se reemplazan por texto, ver _limpiar).
_FUENTES = [
    (r'C:\Windows\Fonts\arial.ttf', r'C:\Windows\Fonts\arialbd.ttf', r'C:\Windows\Fonts\ariali.ttf'),
    (r'C:\Windows\Fonts\calibri.ttf', r'C:\Windows\Fonts\calibrib.ttf', r'C:\Windows\Fonts\calibrii.ttf'),
    ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
     '/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf'),
    ('/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
     '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
     '/usr/share/fonts/truetype/liberation/LiberationSans-Italic.ttf'),
]
_FUENTE = None          # (normal, negrita, cursiva, unicode?)


def _reportlab():
    try:
        import reportlab  # noqa: F401
    except ImportError:
        raise ErrorVerificacion("Para generar el PDF falta la librería 'reportlab'. Cerrá el programa (Salir) y volvé a "
                                "abrirlo con 'Abrir programa.bat': se instala sola (hace falta internet esa vez).")


def _fuente():
    global _FUENTE
    if _FUENTE:
        return _FUENTE
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    for normal, negrita, cursiva in _FUENTES:
        if os.path.exists(normal) and os.path.exists(negrita):
            try:
                pdfmetrics.registerFont(TTFont('RepN', normal))
                pdfmetrics.registerFont(TTFont('RepB', negrita))
                pdfmetrics.registerFont(TTFont('RepI', cursiva if os.path.exists(cursiva) else normal))
                from reportlab.pdfbase.pdfmetrics import registerFontFamily
                registerFontFamily('Rep', normal='RepN', bold='RepB', italic='RepI', boldItalic='RepB')
                _FUENTE = ('RepN', 'RepB', 'RepI', True)
                return _FUENTE
            except Exception:
                continue
    _FUENTE = ('Helvetica', 'Helvetica-Bold', 'Helvetica-Oblique', False)
    return _FUENTE


_REEMPLAZOS = {'→': '->', '≠': 'distinto de', '≈': '~', '…': '...', '–': '-', '—': '-', '·': '-', '×': 'x',
               '“': '"', '”': '"', '‘': "'", '’': "'", '✓': '', '⚠': '', '≥': '>=', '≤': '<='}


def _limpiar(t):
    """Texto seguro para un Paragraph de reportlab (escapa < > &; sin fuente unicode, reemplaza símbolos)."""
    t = '' if t is None else str(t)
    if not _fuente()[3]:
        for a, b in _REEMPLAZOS.items():
            t = t.replace(a, b)
        t = t.encode('cp1252', 'replace').decode('cp1252')
    return t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def _fv(x, dec):
    if x is None:
        return '—'
    if isinstance(x, bool):
        return 'Sí' if x else 'No'
    if isinstance(x, (int, float)):
        return fmt_es(x, dec)
    return str(x)


def _dec(o):
    return 1 if o.tipo in ('indice', 'indice_directo', 'var') else 2


def _titulo_para_contratista(o):
    """El título tal cual, sin el sufijo técnico ' (R3)' repetido si ya va en la ubicación."""
    return re.sub(r'\s+', ' ', o.titulo or '').strip()


def _que_esta_mal(o):
    """Una frase: lo que se encontró. Si no hay descripción, se arma con el valor actual y el correcto."""
    if o.descripcion:
        return o.descripcion
    if isinstance(o.actual, (int, float)) and isinstance(o.correcto, (int, float)):
        return f"La planilla dice {_fv(o.actual, _dec(o))} y debería decir {_fv(o.correcto, _dec(o))}."
    return ''


def _orden_ubicaciones(o, ubicaciones):
    """Primero donde hay que corregir (la celda de ORIGEN del dato), después las que lo toman de ahí."""
    return sorted(ubicaciones, key=lambda u: (0 if u.rol == 'origen' else 1))


def escribir_pdf(ruta, items, datos, info):
    """items: [(observacion, [ubicaciones elegidas])] en el orden en que van al reporte.
    datos: {'organismo','obra','licitacion','contratista','elabora','cargo'} (puede faltar alguno).
    info: {'redet': nombre, 'archivo': nombre del Excel, 'nota': texto libre para la contratista,
           'version': n de versión del archivo (1 = original), 'corregidas': [títulos corregidos desde la anterior],
           'persisten': {firma, ...} observaciones que ya estaban en la versión anterior}."""
    _reportlab()
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

    fN, fB, fI, _ = _fuente()
    datos = datos or {}
    info = info or {}
    E = lambda nombre, **kw: ParagraphStyle(nombre, fontName=kw.pop('fontName', fN), alignment=TA_LEFT, **kw)
    st_titulo = E('t', fontName=fB, fontSize=17, leading=21, textColor=colors.HexColor(AZUL), spaceAfter=2)
    st_sub = E('s', fontSize=10.5, leading=13, textColor=colors.HexColor(GRIS), spaceAfter=10)
    st_txt = E('x', fontSize=10, leading=13.5, spaceAfter=6)
    st_chico = E('c', fontSize=8.5, leading=11, textColor=colors.HexColor(GRIS))
    st_k = E('k', fontName=fB, fontSize=8.5, leading=11, textColor=colors.HexColor(GRIS))
    st_v = E('v', fontSize=9.5, leading=12.5)
    st_cel = E('cel', fontSize=9, leading=11.5)
    st_celB = E('celB', fontName=fB, fontSize=9, leading=11.5)
    st_cab = E('cab', fontName=fB, fontSize=8.5, leading=10.5, textColor=colors.white)
    st_obs = E('obs', fontName=fB, fontSize=10.5, leading=13.5, textColor=colors.white)
    st_h2 = E('h2', fontName=fB, fontSize=12, leading=15, textColor=colors.HexColor(AZUL), spaceBefore=8, spaceAfter=6)
    P = lambda t, s=st_txt: Paragraph(t, s)

    ancho = A4[0] - 3.6 * cm
    fecha = dt.date.today().strftime('%d/%m/%Y')
    pie_txt = _limpiar(f"{info.get('redet') or ''}  ·  {fecha}")

    def _pie(canvas, doc):
        canvas.saveState()
        canvas.setFont(fN, 7.5)
        canvas.setFillColor(colors.HexColor(GRIS))
        canvas.drawString(1.8 * cm, 1.1 * cm, pie_txt[:120])
        canvas.drawRightString(A4[0] - 1.8 * cm, 1.1 * cm, f"Página {doc.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(ruta, pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm, topMargin=1.6 * cm,
                            bottomMargin=1.8 * cm, title=f"Observaciones - {info.get('redet') or ''}",
                            author=datos.get('organismo') or 'Verificador de redeterminaciones')
    h = []

    # ---- Encabezado
    if datos.get('organismo'):
        h.append(P(_limpiar(datos['organismo']).upper(), st_chico))
        h.append(Spacer(1, 4))
    h.append(P('Observaciones a corregir', st_titulo))
    h.append(P(_limpiar(info.get('redet') or ''), st_sub))

    filas = []
    for k, v in (('Obra', datos.get('obra')), ('Licitación', datos.get('licitacion')),
                 ('Redeterminación', f"N.° {info['numero']}" if info.get('numero') else None),
                 ('Contratista', datos.get('contratista')), ('Archivo revisado', info.get('archivo')),
                 ('Fecha', fecha)):
        if v:
            filas.append([P(k, st_k), P(_limpiar(v), st_v)])
    if filas:
        t = Table(filas, colWidths=[3.4 * cm, ancho - 3.4 * cm])
        t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F5F7FA')),
                               ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#D8DEE4')),
                               ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                               ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]))
        h += [t, Spacer(1, 10)]

    # ---- Resumen en palabras
    n = len(items)
    n_celdas = sum(len(u) for _, u in items)
    if n:
        intro = (f"Se revisó la planilla presentada y se {'encontraron' if n != 1 else 'encontró'} "
                 f"<b>{n} observación{'es' if n != 1 else ''}</b> "
                 f"({n_celdas} celda{'s' if n_celdas != 1 else ''}) que {'deben' if n != 1 else 'debe'} corregirse. "
                 "Para cada una se indica qué está mal, en qué hoja y celda, qué valor tiene hoy y cuál debería tener, "
                 "y qué hay que hacer.")
    else:
        intro = "Se revisó la planilla presentada y no hay observaciones para corregir."
    h.append(P(intro))
    version = info.get('version') or 1
    corregidas = info.get('corregidas') or []
    if version > 1:
        t = f"Esta es la revisión de la <b>presentación n.° {version}</b> (corrección)."
        if corregidas:
            t += f" Respecto de la presentación anterior se corrigieron {len(corregidas)} observación(es)."
        persisten = sum(1 for o, _ in items if o.firma in (info.get('persisten') or set()))
        if persisten:
            t += f" {persisten} observación(es) de la presentación anterior siguen sin corregir (marcadas abajo)."
        h.append(P(t))
    if info.get('nota'):
        nota = Table([[P(_limpiar(info['nota']).replace('\n', '<br/>'), st_v)]], colWidths=[ancho])
        nota.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#FFF8E1')),
                                  ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#E0C36A')),
                                  ('LEFTPADDING', (0, 0), (-1, -1), 8), ('TOPPADDING', (0, 0), (-1, -1), 6),
                                  ('BOTTOMPADDING', (0, 0), (-1, -1), 6)]))
        h += [Spacer(1, 2), nota]
    h.append(Spacer(1, 8))

    # ---- Índice rápido (solo si hay varias)
    if n > 2:
        h.append(P('Resumen', st_h2))
        filas = [[P('N.°', st_cab), P('Qué está mal', st_cab), P('Celdas', st_cab)]]
        for i, (o, us) in enumerate(items, start=1):
            etiqueta = '' if o.gravedad == 'ERROR' else f"  <font color='{COLOR_GRAV[o.gravedad]}'>({NOMBRE_GRAV[o.gravedad]})</font>"
            celdas = ', '.join(f"{u.hoja}!{u.celda}" for u in _orden_ubicaciones(o, us)[:3])
            if len(us) > 3:
                celdas += f" y {len(us) - 3} más"
            filas.append([P(str(i), st_celB), P(_limpiar(_titulo_para_contratista(o)) + etiqueta, st_cel),
                          P(_limpiar(celdas), st_cel)])
        t = Table(filas, colWidths=[1.1 * cm, ancho - 6.6 * cm, 5.5 * cm], repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(AZUL)),
                               ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F5F7FA')]),
                               ('GRID', (0, 0), (-1, -1), 0.25, colors.HexColor('#D8DEE4')),
                               ('VALIGN', (0, 0), (-1, -1), 'TOP')]))
        h += [t, Spacer(1, 6)]

    # ---- Cada observación
    if n:
        h.append(P('Detalle', st_h2))
    for i, (o, us) in enumerate(items, start=1):
        bloque = []
        grav = '' if o.gravedad == 'ERROR' else f"   [{NOMBRE_GRAV[o.gravedad]}]"
        pend = '   · Ya observado en la presentación anterior' if o.firma in (info.get('persisten') or set()) else ''
        cab = Table([[P(f"{i}.  {_limpiar(_titulo_para_contratista(o))}{_limpiar(grav)}{_limpiar(pend)}", st_obs)]],
                    colWidths=[ancho])
        cab.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor(COLOR_GRAV.get(o.gravedad, AZUL))),
                                 ('LEFTPADDING', (0, 0), (-1, -1), 8), ('TOPPADDING', (0, 0), (-1, -1), 5),
                                 ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]))
        bloque.append(cab)

        filas = []
        qm = _que_esta_mal(o)
        if qm:
            filas.append([P('Qué está mal', st_k), P(_limpiar(qm), st_v)])
        if o.causa:
            filas.append([P('Por qué', st_k), P(_limpiar(o.causa), st_v)])
        filas.append([P('Qué hay que hacer', st_k), P(_limpiar(o.accion), st_v)])
        if o.fuente:
            fuente = re.sub(r'\b\d{11,}[ _]', '', o.fuente)          # prefijo interno de la biblioteca de boletines
            filas.append([P('Fuente', st_k), P(_limpiar(fuente), st_chico)])
        t = Table(filas, colWidths=[3.4 * cm, ancho - 3.4 * cm])
        t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'),
                               ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#F2F2F2')),
                               ('LINEBELOW', (0, 0), (-1, -2), 0.25, colors.HexColor('#E3E7EB')),
                               ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#D8DEE4'))]))
        bloque.append(t)

        # celdas: Hoja | Celda | Dice | Debe decir (las columnas de valores solo si alguna celda los tiene)
        us = _orden_ubicaciones(o, us)
        con_valores = any(u.actual is not None or u.correcto is not None for u in us)
        # las notas de los índices son internas ("tabla de índices de la contratista"); las de precios e ítems sirven
        con_notas = o.tipo not in ('indice', 'indice_directo', 'var') and any(u.nota for u in us)
        hay_origen = any(u.rol == 'origen' for u in us) and any(u.rol != 'origen' for u in us)
        dec = _dec(o)
        cab_cols = ['Hoja', 'Celda'] + (['Dice', 'Debe decir'] if con_valores else []) + (['Detalle'] if con_notas else [])
        filas = [[P(x, st_cab) for x in cab_cols]]
        for u in us:
            celda = u.celda + (' (corregir acá)' if hay_origen and u.rol == 'origen' else '')
            fila = [P(_limpiar(u.hoja), st_cel), P(_limpiar(celda), st_celB)]
            if con_valores:
                d = 1 if (u.nota or '').startswith('índice') else dec
                fila += [P(_limpiar(_fv(u.actual, d)), st_cel), P(_limpiar(_fv(u.correcto, d)), st_celB)]
            if con_notas:
                fila.append(P(_limpiar(u.nota), st_chico))
            filas.append(fila)
        if con_valores and con_notas:
            anchos = [4.2 * cm, 2.6 * cm, 2.8 * cm, 2.8 * cm]
        elif con_valores:
            anchos = [5.4 * cm, 3.0 * cm, 3.4 * cm]
        elif con_notas:
            anchos = [5.4 * cm, 3.0 * cm]
        else:
            anchos = [ancho - 4 * cm]
        anchos.append(ancho - sum(anchos))
        t = Table(filas, colWidths=anchos, repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#7F8C9A')),
                               ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#FAFBFC')]),
                               ('GRID', (0, 0), (-1, -1), 0.25, colors.HexColor('#D8DEE4')),
                               ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                               ('TOPPADDING', (0, 0), (-1, -1), 2.5), ('BOTTOMPADDING', (0, 0), (-1, -1), 2.5)]))
        # las primeras filas junto con el título; si hay muchas celdas, el resto sigue en la página siguiente
        h.append(KeepTogether(bloque + [Spacer(1, 3)]))
        h.append(t)
        h.append(Spacer(1, 14))

    # ---- Firma
    if datos.get('elabora'):
        h.append(Spacer(1, 18))
        h.append(P(_limpiar(datos['elabora']) + (f"<br/><font size='8.5' color='{GRIS}'>{_limpiar(datos.get('cargo'))}</font>"
                                                   if datos.get('cargo') else ''), st_txt))

    doc.build(h, onFirstPage=_pie, onLaterPages=_pie)
    return ruta

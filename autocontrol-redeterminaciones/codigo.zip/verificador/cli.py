# -*- coding: utf-8 -*-
"""
cli.py
-------
Recorrido del programa, en tres tiempos:

  1) ARCHIVOS   Excel + PDFs del INDEC (+ versión anterior, opcional).
  2) PREGUNTAS  Se carga todo y, con lo detectado, se hacen TODAS las preguntas juntas.
  3) ANALISIS   Corren los 4 controles seguidos, sin frenarse (si uno falla, los otros siguen),
                y se guarda un único reporte.

Todas las preguntas tienen un valor sugerido (Enter). Cada una se puede pasar por línea de
comandos (ver --ayuda) y con --sin-preguntas no se pregunta nada.
"""
import argparse
import os
import re
import time
import traceback

from openpyxl.utils import column_index_from_string as CI, get_column_letter as L

from . import analisis_items as ai
from . import cache_anterior
from . import analisis_precios as ap
from . import copia_anotada as ca
from . import informe_word as iw
from . import observaciones as ob
from . import __version__
from . import costos as cs
from . import items_indec as it
from . import reporte as rp
from . import var as vn
from .comunes import (ErrorVerificacion, Veredicto, configurar_consola, limpiar_ruta, mes_txt, nombre_salida_unico,
                      parsear_mes, pedir, separar_rutas)
from .contexto import Contexto
from .excel import hojas_de_datos
from .formulas import Formulas
from .pdf_indec import Boletin
from .seleccion import bloque_seleccionado, parsear_seleccion

CONTROLES = [('items', 'Ítems INDEC (códigos de la contratista vs. boletín)'),
             ('var', 'VAR (variación de referencia vs. boletín)'),
             ('ap', 'Análisis de precios (índices, precios, cadena, anticipo)'),
             ('costos', 'Planilla de costos (precios vs. análisis y cálculos)')]
RE_TODO = ('todo', 'todos', 'todas', 'all')


# ======================================================================
# Argumentos
# ======================================================================
def parse_args(argv=None):
    a = argparse.ArgumentParser(prog='verificar', description="Verificador unificado de redeterminaciones de precios")
    a.add_argument('excel', nargs='?', help="Excel de la redeterminación (.xlsx o .xls)")
    a.add_argument('--pdf', action='append', default=[], help="Boletín INDEC (PDF); se puede repetir")
    a.add_argument('--prev', help="Versión anterior aprobada (opcional)")
    a.add_argument('--solo', help="Controles a correr, separados por coma: items,var,ap,costos (por defecto todos)")
    a.add_argument('--meses', help="Mes a comparar de cada PDF, en el orden de --pdf: 'MAR-2026,ABR-2026' (por defecto el último de cada uno)")
    a.add_argument('--hoja-items', help="Hoja con los códigos de la contratista (control de ítems). Con columna: 'Materiales!H'")
    a.add_argument('--hoja-var', help="Hoja VAR")
    a.add_argument('--hoja-indec', help="Hoja con los índices del INDEC del análisis de precios (si no se detecta sola; con columna Nº o Código)")
    a.add_argument('--ap-manual', help="Fuerza la hoja y columnas del análisis de precios cuando no se detecta ninguna: 'HOJA:BASE,RED,COEF,PRECIO' o 'HOJA:BASE,RED,COEF,PRECIO,ID' (columnas por letra)")
    a.add_argument('--cols-ap', help="Columnas/redeterminaciones del análisis de precios (AR:BL, R4, 'AP!AR:BL'); 'todo' = todo")
    a.add_argument('--cols-costos', help="Columnas/redeterminaciones de la planilla de costos (J:L, R2, base); 'todo' = todo")
    a.add_argument('--planilla', help="Hoja de la planilla de costos (si no, se detecta sola)")
    a.add_argument('--out', help="Archivo de salida (por defecto 'Verificacion - <excel>.xlsx' en la carpeta actual)")
    a.add_argument('--organismo', help="Organismo (portada del informe)")
    a.add_argument('--obra', help="Obra (portada del informe; se intenta leer del Excel)")
    a.add_argument('--licitacion', help="Licitación / expediente (portada del informe)")
    a.add_argument('--contratista', help="Contratista (portada del informe)")
    a.add_argument('--elabora', help="Nombre de quien firma el informe")
    a.add_argument('--cargo', help="Cargo de quien firma el informe")
    a.add_argument('--salida', action='append', metavar='LISTA', help="Qué archivos generar: excel, word, copia (separados por coma; se puede repetir). "
                                                                    "Por defecto: los tres. Ej.: --salida excel   o   --salida excel,word")
    a.add_argument('--sin-informe', action='store_true', help="No generar el informe Word")
    a.add_argument('--sin-copia', action='store_true', help="No generar la copia anotada del Excel")
    a.add_argument('--sin-formulas', action='store_true', help="No leer las fórmulas (más rápido; se pierde el origen de los errores y las fórmulas apartadas)")
    a.add_argument('--sin-preguntas', action='store_true', help="No preguntar nada: usa los valores sugeridos y lo indicado por línea de comandos")
    return a.parse_args(argv)


# ======================================================================
# 1) ARCHIVOS
# ======================================================================
def pedir_excel(args, interactivo):
    if args.excel:
        return limpiar_ruta(args.excel)
    if not interactivo:
        return None
    while True:
        resp = limpiar_ruta(pedir("\nArrastrá acá el Excel de la contratista y presioná Enter (o escribí 'salir'): "))
        if resp.lower() in ('', 'salir', 'fin', 'exit', 'q'):
            return None
        if os.path.isfile(resp):
            return resp
        print(f"  No encuentro ese archivo: {resp}")


def pedir_pdfs(args, interactivo):
    pdfs = [limpiar_ruta(p) for p in args.pdf]
    if pdfs or not interactivo:
        return pdfs
    print("\nBoletines INDEC (PDF). Arrastrá uno por vez, o varios juntos; Enter vacío cuando termines.")
    print("  (Con dos PDFs, cada uno verifica su propio mes: típicamente uno por cada redeterminación.)")
    while True:
        resp = pedir(f"  PDF {len(pdfs) + 1}: ")
        if not resp:
            break
        for ruta in separar_rutas(resp):
            if os.path.isfile(ruta) and ruta.lower().endswith('.pdf'):
                pdfs.append(ruta)
                print(f"    agregado: {os.path.basename(ruta)}")
            else:
                print(f"    no es un PDF que exista, lo ignoro: {ruta}")
    return pdfs


def pedir_prev(args, interactivo):
    if args.prev:
        return limpiar_ruta(args.prev)
    if not interactivo:
        return None
    resp = limpiar_ruta(pedir("\n¿Tenés la versión ANTERIOR ya aprobada de este Excel? Arrastrala para marcar qué hallazgos son nuevos\n"
                              "y qué valores viejos cambiaron (Enter para omitir): "))
    return resp if resp and os.path.isfile(resp) else None


# ======================================================================
# 2) CARGA Y DETECCION (sin preguntas)
# ======================================================================
class Carga:
    """Todo lo leído y detectado antes de hacer las preguntas."""
    prev_path = None           # versión anterior (ruta), o None
    prev_error = None          # si no se pudo abrir, por qué
    abrir = None               # función ruta -> libro ya abierto (la interfaz web la usa para no reabrir)
    _prev_ctx = None

    @property
    def prev_ctx(self):
        """La versión anterior se abre recién cuando hace falta: si su análisis ya está guardado
        (cache_anterior), no se abre nunca."""
        if self.prev_error is not None:
            raise ErrorVerificacion(f"No pude abrir la versión anterior: {self.prev_error}")
        if self._prev_ctx is None and self.prev_path:
            try:
                print(f"  Abriendo la versión anterior: {os.path.basename(self.prev_path)} ...")
                self._prev_ctx = Contexto(self.prev_path, wb=self.abrir(self.prev_path) if self.abrir else None)
            except ErrorVerificacion as e:
                self.prev_error = str(e)
                raise
            except Exception as e:
                self.prev_error = f"{type(e).__name__}: {e}"
                raise ErrorVerificacion(f"No pude abrir la versión anterior: {self.prev_error}")
        return self._prev_ctx

    def prev_disponible(self):
        return bool(self.prev_path) and self.prev_error is None


def analisis_anterior_ap(c):
    """Análisis de precios de la versión anterior: guardado si ya se hizo, si no se calcula y se guarda."""
    ant = cache_anterior.cargar(c.prev_path, 'ap')
    if ant is not None:
        print("  Versión anterior: análisis de precios ya calculado antes (no hace falta volver a abrirla).")
        return ant
    ant = ap.analizar_ap(c.prev_ctx, None, progreso=False)
    cache_anterior.guardar(c.prev_path, 'ap', '', ant)
    return ant


def analisis_anterior_costos(c, hoja):
    """Planilla de costos de la versión anterior (misma hoja que la actual), guardada o calculada."""
    ant = cache_anterior.cargar(c.prev_path, 'costos', hoja)
    if ant is not None:
        print("  Versión anterior: planilla de costos ya calculada antes (no hace falta volver a abrirla).")
        return ant
    pls, han = cs.detectar_planillas(c.prev_ctx, hoja=hoja)
    ant = cs.analizar_costos(c.prev_ctx, pls[:1], han, None, progreso=False)
    cache_anterior.guardar(c.prev_path, 'costos', hoja, ant)
    return ant


def parse_ap_manual(txt, wb):
    """'HOJA:BASE,RED,COEF,PRECIO[,ID]' (columnas por letra) -> (hoja, c_base, c_red, c_coef, c_precio, c_id|None)."""
    if ':' not in txt:
        raise ErrorVerificacion(f"'{txt}' no tiene el formato HOJA:BASE,RED,COEF,PRECIO (--ap-manual).")
    hoja_txt, cols_txt = txt.split(':', 1)
    h, _ = parse_hoja_col(hoja_txt, wb)
    if not h:
        raise ErrorVerificacion(f"No encontré la hoja '{hoja_txt.strip()}' (--ap-manual).")
    partes = [x.strip().upper() for x in cols_txt.split(',') if x.strip()]
    if len(partes) not in (4, 5):
        raise ErrorVerificacion(f"'{cols_txt}' debería tener 4 columnas (base,red,coef,precio) o 5 (agregando el "
                                f"código del insumo al final) (--ap-manual).")
    try:
        nums = [CI(x) for x in partes]
    except ValueError as e:
        raise ErrorVerificacion(f"Column inválida en '{cols_txt}': {e} (--ap-manual).")
    c_base, c_red, c_coef, c_precio = nums[:4]
    c_id = nums[4] if len(nums) == 5 else None
    return h, c_base, c_red, c_coef, c_precio, c_id


def cargar(excel, pdfs, prev, hoja_indec=None, ap_manual=None, abrir=None):
    """abrir: opcional, función ruta -> libro ya abierto (para no volver a abrir un Excel que ya está en memoria)."""
    c = Carga()
    c.abrir = abrir
    print("\n" + "=" * 64 + "\nCARGANDO ARCHIVOS\n" + "=" * 64)
    t0 = time.time()
    print(f"Excel: {os.path.basename(excel)} ...")
    c.ctx = Contexto(excel, wb=abrir(excel) if abrir else None)
    if hoja_indec:
        h, _ = parse_hoja_col(hoja_indec, c.ctx.wb)
        if not h:
            raise ErrorVerificacion(f"No encontré la hoja '{hoja_indec}' (--hoja-indec).")
        c.ctx.configurar_indec([h])
    if ap_manual:
        h, c_base, c_red, c_coef, c_precio, c_id = parse_ap_manual(ap_manual, c.ctx.wb)
        try:
            c.ctx.agregar_bloque_manual(h, c_base, c_red, c_coef, c_precio, c_id)
        except ValueError as e:
            raise ErrorVerificacion(str(e))
        print(f"  Análisis de precios: bloque forzado a mano en '{h}' (--ap-manual).")
    c.boletines = []
    for p in pdfs:
        try:
            # un boletín ya leído (ej. el Anexo guardado que trae el autocontrol de la contratista) o la ruta del PDF
            c.boletines.append(p if isinstance(p, Boletin) else Boletin(p))
        except ErrorVerificacion as e:
            print(f"  ⚠ {e}")
        except Exception as e:
            print(f"  ⚠ No pude leer '{os.path.basename(p)}': {type(e).__name__}: {e}")
    c.boletines.sort(key=lambda b: b.ultimo_mes)
    for b1, b2 in zip(c.boletines, c.boletines[1:]):
        if b1.ultimo_mes == b2.ultimo_mes:
            print(f"  ⚠ '{b1.nombre}' y '{b2.nombre}' terminan en el mismo mes ({mes_txt(b1.ultimo_mes)}): "
                  "probablemente sea el mismo boletín dos veces.")
    if prev:
        c.prev_path = prev
        if not os.path.isfile(prev):
            c.prev_error = f"No encuentro el archivo '{prev}'."
            print(f"  ⚠ {c.prev_error} Sigo sin comparar con la versión anterior.")
        else:
            print(f"Versión anterior: {os.path.basename(prev)} (se abre solo si hace falta)")
    wb = c.ctx.wb
    # lo que puede correr cada control
    c.prep_items = it.preparar(wb)
    c.items_manual = None
    c.hojas_var = vn.detectar_hojas_var(wb)
    c.planillas, c.hojas_analisis, c.err_planillas = [], [], ''
    try:
        c.planillas, c.hojas_analisis = cs.detectar_planillas(c.ctx)
    except ErrorVerificacion as e:
        c.err_planillas = str(e)
    c.motivos = {}
    if not c.boletines:
        c.motivos['items'] = 'no se dio ningún PDF del INDEC'
    elif not c.prep_items:
        c.motivos['items'] = 'no encontré una hoja con códigos de índice en el Excel'
    if not c.hojas_var:
        c.motivos['var'] = 'no encontré la hoja VAR (variación de referencia)'
    if not c.ctx.hojas_indec:
        c.motivos['ap'] = 'no encontré la hoja de índices del INDEC en el Excel'
    elif not c.ctx.tabla:
        c.motivos['ap'] = 'la hoja de índices no tiene columna Nº/Código con índices por mes'
    elif not c.ctx.hojas_bloques:
        c.motivos['ap'] = 'no encontré ninguna hoja de análisis de precios'
    c.ap_items = {}
    if 'ap' in c.motivos:                 # ¿análisis por hoja de ítem (CODIGO CPC / BASE / REDET / COEF)?
        try:
            c.ap_items = ai.detectar(c.ctx)
        except Exception as e:
            c.ctx.avisos.append(f"No pude buscar el análisis por hoja de ítem: {type(e).__name__}: {e}")
        if c.ap_items:
            c.motivos.pop('ap')
    if not c.planillas:
        c.motivos['costos'] = c.err_planillas or 'no encontré la planilla de costos'
    print(f"\nListo ({time.time() - t0:.0f} s). Esto es lo que detecté:")
    for b in c.boletines:
        print(f"  PDF {b.nombre}: meses {b.texto_meses()}")
    if c.prep_items:
        print(f"  Ítems INDEC: {c.prep_items.descripcion()}")
    print(f"  Hoja(s) VAR: {c.hojas_var or 'no detectada'}")
    print(f"  Hoja(s) INDEC: {c.ctx.hojas_indec or 'no detectada'}   Anticipo financiero: {c.ctx.hojas_af or 'no detectado'}")
    if c.ap_items:
        print(f"  Análisis de precios por hoja de ítem (CODIGO CPC / BASE / REDET / COEF): {len(c.ap_items)} hojas, "
              f"{sum(len(v) for v in c.ap_items.values())} tablas")
    else:
        print(f"  Análisis de precios: {len(c.ctx.hojas_bloques)} hoja(s) con bloques" if c.ctx.hojas_bloques else "  Análisis de precios: no detectado")
    print("  Planilla de costos: " + ('; '.join(f"'{p.hoja.strip()}' ({len(p.items)} ítems, bloques {', '.join(b.etiqueta for b in p.bloques)})" for p in c.planillas)
                                      if c.planillas else 'no detectada'))
    for a in c.ctx.avisos:
        print(f"  ⚠ {a}")
    return c


# ======================================================================
# 3) PREGUNTAS (todas juntas)
# ======================================================================
class Parametros:
    def __init__(self):
        self.controles = []
        self.meses = []               # [(boletín, mes)]
        self.hoja_items = None        # None = la detectada
        self.cols_valor = {}          # {mes: columna del valor declarado | None}
        self.hojas_var = None
        self.prep_items = None
        self.sel_ap = (None, 'todas')
        self.sel_costos = (None, 'todas')
        self.planillas = []
        self.resumen = []             # [(rótulo, texto)] para el reporte
        self.datos_informe = {}       # portada del informe Word
        self.salidas = {'excel', 'word', 'copia'}   # qué archivos generar


def parse_hoja_col(txt, wb):
    """'Materiales!H' -> ('Materiales', 8) | 'Materiales' -> ('Materiales', None) | (None, None) si no existe."""
    hoja, col = txt.strip(), None
    if '!' in hoja:
        hoja, letra = hoja.rsplit('!', 1)
        try:
            col = CI(letra.strip().upper())
        except ValueError:
            col = None
    for n in hojas_de_datos(wb):
        if n.strip().lower() == hoja.strip().strip("'").lower():
            return n, col
    return None, None


def _listar_hojas(wb, marcadas=()):
    for i, n in enumerate(hojas_de_datos(wb), start=1):
        print(f"    {i}. {n}" + ('   <- detectada' if n in marcadas else ''))


def completar_a_mano(c, interactivo):
    """SOLO para los controles que no se pudieron detectar: el usuario puede indicar la hoja (y la columna)
    a mano. Enter = omitir ese control."""
    if not interactivo:
        return
    wb = c.ctx.wb

    def hoja(msg, con_columna=False):
        while True:
            resp = pedir(msg)
            if not resp:
                return None, None
            if resp == '?':
                _listar_hojas(wb)
                continue
            h, col = parse_hoja_col(resp, wb)
            if h:
                return h, col
            print("    No encuentro esa hoja. Escribí el nombre exacto ('?' = ver las hojas).")

    faltan = [k for k in ('items', 'var', 'ap', 'costos') if k in c.motivos and not (k == 'items' and not c.boletines)]
    if not faltan:
        return
    print("\n  No pude detectar algunas hojas. Si querés, indicalas a mano (Enter = omitir ese control; '?' = ver las hojas):")
    if 'items' in faltan:
        h, col = hoja("  Ítems INDEC: hoja con los códigos de índice (y columna, ej. Materiales!H) > ", True)
        prep = it.preparar(wb, hoja=h, col_codigos=col) if h else None
        if prep:
            c.items_manual, c.prep_items = prep, prep
            c.motivos.pop('items')
        elif h:
            print("    No encontré códigos de índice en esa hoja/columna.")
    if 'var' in faltan:
        h, _ = hoja("  VAR: hoja con la variación de referencia > ")
        if h:
            c.hojas_var = [h]
            c.motivos.pop('var')
    if 'ap' in faltan:
        h, _ = hoja("  Análisis de precios: hoja con los índices del INDEC (con columna Nº o Código) > ")
        if h:
            c.ctx.configurar_indec([h])
            if c.ctx.tabla and c.ctx.hojas_bloques:
                c.motivos.pop('ap')
            else:
                print("    Con esa hoja no encontré hojas de análisis de precios con bloques de índices.")
    if 'costos' in faltan:
        h, _ = hoja("  Planilla de costos: hoja de la planilla > ")
        if h:
            try:
                c.planillas, c.hojas_analisis = cs.detectar_planillas(c.ctx, hoja=h)
                c.motivos.pop('costos')
            except ErrorVerificacion as e:
                print(f"    {e}")


def elegir_hoja(wb, rotulo, detectadas, forzada, interactivo):
    """Hoja(s) a usar: la indicada por --opción, la detectada (Enter) o la que elija el usuario."""
    nombres = hojas_de_datos(wb)
    if forzada:
        for n in nombres:
            if n.strip().lower() == forzada.strip().lower():
                return [n]
        raise ErrorVerificacion(f"No encontré la hoja '{forzada}'. Hojas: {', '.join(nombres[:15])}")
    if not interactivo:
        return detectadas
    print(f"\n  {rotulo}: detecté {', '.join(repr(d) for d in detectadas) or 'ninguna'}")
    while True:
        resp = pedir("  Enter = usar esa | número o nombre de otra hoja | '?' = ver todas las hojas > ")
        if not resp:
            return detectadas
        if resp == '?':
            for i, n in enumerate(nombres, start=1):
                print(f"    {i}. {n}" + ('   <- detectada' if n in detectadas else ''))
            continue
        if resp.isdigit() and 1 <= int(resp) <= len(nombres):
            return [nombres[int(resp) - 1]]
        for n in nombres:
            if n.strip().lower() == resp.lower():
                return [n]
        print("    No entendí esa opción.")


def mostrar_bloques_ap(hojas_bloques):
    print("\n  Bloques del análisis de precios (columnas de índices, del índice base al precio actualizado):")
    grupos = {}
    for hoja, bl in hojas_bloques.items():
        for b in bl:
            grupos.setdefault((b.etiqueta, b.col_ini, b.c_precio, b.m_base, b.m_red), []).append(hoja)
    for (et, ci, cp, mb, mr), hojas in grupos.items():
        hojas = list(dict.fromkeys(hojas))                    # sin repetir (una hoja puede tener varias tablas)
        donde = f"hoja '{hojas[0]}'" if len(hojas) == 1 else f"{len(hojas)} hojas ({', '.join(hojas[:4])}{', ...' if len(hojas) > 4 else ''})"
        print(f"     {et:>4}  {L(ci)}:{L(cp)}   ({mes_txt(mb)} → {mes_txt(mr)})   en {donde}")


def preguntar_seleccion(texto_pregunta, defecto, validar, transformar=lambda t: t):
    """Repite hasta que la respuesta sea válida. Devuelve (tokens | None, texto)."""
    while True:
        resp = pedir(texto_pregunta)
        if not resp and defecto:
            resp = defecto
        if not resp or resp.lower() in RE_TODO:
            return None, 'todas'
        tokens, err = parsear_seleccion(transformar(resp))
        if err:
            print(f"    {err}")
            continue
        err = validar(tokens, resp)
        if err:
            print(f"    {err}")
            continue
        return tokens, resp


RE_ULTIMA = ('ultima', 'última', 'ultimo', 'último', 'last')


def texto_ultima(bloques):
    """'R4' (o el rango de columnas) de la ÚLTIMA redeterminación entre esos bloques, o None."""
    if not bloques:
        return None
    def orden(b):
        return (b.n_redet or 0, getattr(b, 'c_base', None) or getattr(b, 'p', 0) or 0)
    b = max(bloques, key=orden)
    if re.fullmatch(r'R\d+|Base', b.etiqueta or ''):
        return b.etiqueta
    ini = getattr(b, 'c_base', None) or getattr(b, 'p', None)
    fin = getattr(b, 'c_precio', None) or getattr(b, 'c_fin', None)
    return f"{L(ini)}:{L(fin)}" if ini and fin else None


def seleccion_desde_texto(txt, validar, transformar=lambda t: t, bloques=None):
    """Igual, pero para lo que vino por línea de comandos (sin repreguntar). 'ultima' = solo la última
    redeterminación encontrada (la de más a la derecha / número más alto) entre 'bloques'."""
    if txt and txt.strip().lower() in RE_ULTIMA:
        ult = texto_ultima(bloques)
        if not ult:
            return None, 'todas'
        tokens, err = parsear_seleccion(transformar(ult))
        if err or validar(tokens, ult):
            return None, 'todas'
        return tokens, f"{ult} (la última)"
    if not txt or txt.strip().lower() in RE_TODO:
        return None, 'todas'
    tokens, err = parsear_seleccion(transformar(txt))
    if err:
        raise ErrorVerificacion(err)
    err = validar(tokens, txt)
    if err:
        raise ErrorVerificacion(err)
    return tokens, txt.strip()


def hacer_preguntas(args, c, interactivo):
    p = Parametros()
    wb = c.ctx.wb
    completar_a_mano(c, interactivo)
    disponibles = [k for k, _ in CONTROLES if k not in c.motivos]

    # --- qué controles
    if interactivo and not args.solo:
        print("\n" + "=" * 64 + "\nPREGUNTAS (Enter = valor sugerido). Después de esto el análisis corre solo.\n" + "=" * 64)
        print("\n  Controles disponibles:")
        for i, (k, nombre) in enumerate(CONTROLES, start=1):
            print(f"    {i}. {nombre}" + ('' if k in disponibles else f"   [no disponible: {c.motivos[k]}]"))
        resp = pedir("  ¿Cuáles corro? (Enter = todos los disponibles; o números, ej. 1,3) > ")
        if resp:
            elegidos = {CONTROLES[int(x) - 1][0] for x in re.findall(r'\d', resp) if 1 <= int(x) <= len(CONTROLES)}
            disponibles = [k for k in disponibles if k in elegidos]
    elif args.solo:
        pedidos = {x.strip().lower() for x in args.solo.split(',')}
        disponibles = [k for k in disponibles if k in pedidos]
    p.controles = disponibles
    p.resumen.append(('Controles ejecutados', ', '.join(dict(CONTROLES)[k].split(' (')[0] for k in disponibles) or 'ninguno'))

    # --- mes de cada PDF
    if c.boletines and ('items' in p.controles or 'var' in p.controles):
        pedidos = [m.strip() for m in args.meses.split(',')] if args.meses else []
        if interactivo:
            print("\n  MES A COMPARAR DE CADA PDF (Enter = el último mes del boletín)")
        for i, b in enumerate(c.boletines):
            ym = b.ultimo_mes
            if i < len(pedidos) and pedidos[i]:
                ym = parsear_mes(pedidos[i])
            elif interactivo:
                print(f"    {b.nombre}: {b.texto_meses()}")
                while True:
                    resp = pedir(f"    Mes de '{b.nombre}' [{mes_txt(b.ultimo_mes)}]: ")
                    try:
                        ym = parsear_mes(resp) if resp else b.ultimo_mes
                    except ValueError as e:
                        print(f"      {e}")
                        continue
                    if ym in b.meses:
                        break
                    print("      Ese mes no está en el boletín.")
            if ym not in b.meses:
                raise ErrorVerificacion(f"El mes {mes_txt(ym)} no está en '{b.nombre}' (meses: {b.texto_meses()}).")
            p.meses.append((b, ym))
        p.resumen.append(('Mes por boletín', '; '.join(f"{b.nombre} → {mes_txt(ym)}" for b, ym in p.meses)))

    # --- ítems INDEC: hoja y columna del valor declarado por mes
    if 'items' in p.controles:
        prep = c.items_manual
        if prep is None:
            hoja_arg = col_arg = None
            if args.hoja_items:
                hoja_arg, col_arg = parse_hoja_col(args.hoja_items, wb)
                if not hoja_arg:
                    raise ErrorVerificacion(f"No encontré la hoja '{args.hoja_items}'. Hojas: {', '.join(hojas_de_datos(wb)[:15])}")
            elif interactivo:
                print(f"\n  Ítems INDEC: {c.prep_items.descripcion()}")
                while True:
                    resp = pedir("  Enter = usar esa | otra hoja o Hoja!Columna (ej. Materiales!H) | '?' = ver las hojas > ")
                    if not resp:
                        break
                    if resp == '?':
                        _listar_hojas(wb, [c.prep_items.hoja])
                        continue
                    hoja_arg, col_arg = parse_hoja_col(resp, wb)
                    if hoja_arg:
                        break
                    print("    No encuentro esa hoja.")
            prep = it.preparar(wb, hoja=hoja_arg, col_codigos=col_arg) if (hoja_arg or c.prep_items is None) else c.prep_items
        if prep is None:
            c.motivos['items'] = "no encontré códigos de índice en la hoja indicada"
            p.controles.remove('items')
        else:
            p.prep_items = prep
            for b, ym in p.meses:
                col = prep.columna_del_mes(ym)
                if col is None and interactivo:
                    print(f"\n  No encontré la columna de {mes_txt(ym)} en '{prep.hoja}'. Así se ve el encabezado:")
                    for ln in it.vista_previa(wb[prep.hoja], prep.col_codigos)[:12]:
                        print(f"     {ln}")
                    resp = pedir(f"  ¿En qué columna está el valor declarado para {mes_txt(ym)}? (ej. J; Enter = omitir la comparación) > ").upper()
                    try:
                        col = CI(resp) if resp else None
                    except ValueError:
                        col = None
                p.cols_valor[ym] = col
            p.resumen.append(('Ítems: hoja / columna de códigos', f"{prep.hoja} / {L(prep.col_codigos)}"))

    # --- VAR
    if 'var' in p.controles:
        p.hojas_var = elegir_hoja(wb, 'Hoja VAR (variación de referencia)', c.hojas_var, args.hoja_var, interactivo)
        p.resumen.append(('Hoja VAR', ', '.join(p.hojas_var)))

    # --- análisis de precios
    if 'ap' in p.controles:
        hb = c.ap_items or c.ctx.hojas_bloques
        todos = [b for bl in hb.values() for b in bl]

        def valida_ap(tokens, resp):
            return None if any(bloque_seleccionado(b, tokens) for b in todos) else \
                "Ese rango no toca ningún bloque de índices (mirá las columnas de la lista; para R4 escribí R4)."
        if interactivo and not args.cols_ap:
            mostrar_bloques_ap(hb)
            p.sel_ap = preguntar_seleccion("  ¿Qué columnas del ANALISIS DE PRECIOS analizo?  Ej.: AR:BL | J:N, AZ:BD | R4 | Enter = todo > ", '', valida_ap)
        else:
            p.sel_ap = seleccion_desde_texto(args.cols_ap, valida_ap, bloques=todos)
        p.resumen.append(('Análisis de precios: columnas', p.sel_ap[1]))

    # --- planilla de costos
    if 'costos' in p.controles:
        planillas = c.planillas
        if args.planilla:
            planillas = [x for x in planillas if x.hoja.strip().lower() == args.planilla.strip().lower()]
            if not planillas:
                raise ErrorVerificacion(f"'{args.planilla}' no es una planilla de costos detectada.")
        elif len(planillas) > 1 and interactivo:
            print("\n  Encontré más de una planilla de costos:")
            for i, x in enumerate(planillas, start=1):
                print(f"    {i}. '{x.hoja.strip()}'  ({len(x.items)} ítems; bloques: {', '.join(b.etiqueta for b in x.bloques)})")
            resp = pedir("  ¿Cuál analizo? (número; 'todas'; Enter = la 1) > ").lower()
            if resp in RE_TODO:
                pass
            elif resp.isdigit() and 1 <= int(resp) <= len(planillas):
                planillas = [planillas[int(resp) - 1]]
            else:
                planillas = planillas[:1]
        else:
            planillas = planillas[:1]
        p.planillas = planillas
        bloques = [b for x in planillas for b in x.bloques]

        def valida_cs(tokens, resp):
            return None if any(bloque_seleccionado(b, tokens) for b in bloques) else \
                "Ese rango no toca ningún bloque de la planilla (para la primera redeterminación escribí R1; para la base, base)."
        a_r0 = lambda t: re.sub(r'\bbase\b', 'R0', t, flags=re.IGNORECASE)
        if interactivo and not args.cols_costos:
            print("\n  Bloques de la planilla de costos:")
            for x in planillas:
                print(f"    Hoja '{x.hoja.strip()}': " + '   '.join(f"{b.etiqueta} {L(b.p)}:{L(b.c_fin)}" for b in x.bloques))
            solo_r = re.fullmatch(r'\s*R\d+(\s*[,;]\s*R\d+)*\s*', p.sel_ap[1] or '') if 'ap' in p.controles else None
            defecto = p.sel_ap[1] if solo_r else ''
            sufijo = f" [{defecto}]" if defecto else ''
            p.sel_costos = preguntar_seleccion(f"  ¿Qué columnas de la PLANILLA DE COSTOS analizo?  Ej.: J:L | R2 | base | Enter = {'lo mismo que el análisis' if defecto else 'todo'}{sufijo} > ",
                                               defecto, valida_cs, a_r0)
        else:
            p.sel_costos = seleccion_desde_texto(args.cols_costos, valida_cs, a_r0, bloques=bloques)
        p.resumen.append(('Planilla de costos: hoja / columnas', f"{', '.join(x.hoja.strip() for x in planillas)} / {p.sel_costos[1]}"))
    p.salidas = preguntar_salidas(args, interactivo)
    p.datos_informe = preguntar_datos_informe(args, c, interactivo) if 'word' in p.salidas else {}
    return p


ARCHIVOS = (('excel', 'Excel de verificación (el detalle de cada control)'),
            ('word', 'Informe en Word para presentar a la empresa'),
            ('copia', 'Copia anotada del Excel (celdas marcadas y comentadas)'))


def _parsear_salidas(texto):
    """'1,3' / '13' / 'excel,word' / 'todos' -> conjunto de claves; None si no se entiende."""
    t = texto.strip().lower().replace(' ', '').replace(';', ',')
    if t in ('', 'todos', 'todo', 'los tres', 'lostres'):
        return {k for k, _ in ARCHIVOS}
    claves = [k for k, _ in ARCHIVOS]
    out = set()
    for parte in ([t] if t.isdigit() else t.split(',')):
        if parte.isdigit():
            for d in parte:
                if not (1 <= int(d) <= len(claves)):
                    return None
                out.add(claves[int(d) - 1])
        elif parte in claves or parte in ('informe', 'copia_anotada', 'anotada'):
            out.add({'informe': 'word', 'copia_anotada': 'copia', 'anotada': 'copia'}.get(parte, parte))
        else:
            return None
    return out or None


def preguntar_salidas(args, interactivo):
    """Qué archivos generar. Por defecto los tres; --sin-informe / --sin-copia los sacan."""
    if args.salida:
        elegidas = _parsear_salidas(','.join(args.salida))
        if elegidas is None:
            raise ErrorVerificacion("--salida solo acepta: excel, word, copia (separados por coma).")
    elif interactivo:
        print("\n  QUE ARCHIVOS QUERES GENERAR")
        for i, (_, txt) in enumerate(ARCHIVOS, start=1):
            print(f"    {i}) {txt}")
        while True:
            elegidas = _parsear_salidas(pedir("  Numeros separados por coma, ej. 1,2  (Enter = los tres): "))
            if elegidas is not None:
                break
            print("    No entendi. Escribi los numeros (1, 2, 3) separados por coma, o Enter para los tres.")
    else:
        elegidas = {k for k, _ in ARCHIVOS}
    if args.sin_informe:
        elegidas.discard('word')
    if args.sin_copia:
        elegidas.discard('copia')
    return elegidas


def preguntar_datos_informe(args, c, interactivo):
    """Datos de la portada del informe Word: se leen del Excel y se pueden corregir (Enter = dejar lo detectado)."""
    try:
        d = iw.datos_obra(c.ctx)
    except Exception:
        d = {}
    d.update({k: getattr(args, k) for k in ('organismo', 'obra', 'licitacion', 'contratista', 'elabora', 'cargo') if getattr(args, k, None)})
    if interactivo:
        print("\n  DATOS PARA LA PORTADA DEL INFORME WORD (Enter = dejar lo detectado / en blanco)")
        for k, etiqueta in (('obra', 'Obra'), ('contratista', 'Contratista'), ('elabora', 'Quién firma (nombre)'), ('cargo', 'Cargo')):
            det = d.get(k, '')
            resp = pedir(f"    {etiqueta} [{det[:60] if det else 'en blanco'}]: ")
            if resp:
                d[k] = resp
    return d


# ======================================================================
# 4) ANALISIS (sin frenarse)
# ======================================================================
def correr(controles_clave, titulo, fn, veredictos):
    """Corre un control; si falla, lo registra y sigue con el próximo."""
    print(f"\n>>> {titulo}")
    try:
        return fn()
    except ErrorVerificacion as e:
        veredictos.append(Veredicto(controles_clave, titulo, 'ERROR', str(e)))
        print(f"  ⚠ {e}")
    except Exception as e:
        veredictos.append(Veredicto(controles_clave, titulo, 'ERROR', f"error inesperado: {type(e).__name__}: {e}"))
        print("  ⚠ Error inesperado en este control (los demás siguen):")
        traceback.print_exc()
    return None


def cargar_formulas(c, usar):
    """Libro con fórmulas (solo .xlsx/.xlsm). None si no está disponible o falla: el resto sigue igual."""
    if not usar:
        return None
    try:
        print("\nLeyendo las fórmulas del Excel...")
        return Formulas(c.ctx.path)
    except ErrorVerificacion as e:
        print(f"  (fórmulas no disponibles: {e})")
    except Exception as e:
        print(f"  (no pude leer las fórmulas: {type(e).__name__}: {e})")
    return None


def analizar(c, p, prev_nombre, fm=None):
    veredictos, r = [], {'items': [], 'var': None, 'ap': None, 'costos': None}
    con_prev = c.prev_disponible()
    wb = c.ctx.wb
    for k, nombre in CONTROLES:
        if k not in p.controles:
            veredictos.append(Veredicto(k, nombre.split(' (')[0], 'OMITIDO', c.motivos.get(k, 'no se pidió correrlo')))

    # ---- 1) ítems INDEC (un mes por PDF)
    if 'items' in p.controles:
        for b, ym in p.meses:
            def f(b=b, ym=ym):
                res = it.verificar_mes(wb, p.prep_items, b, ym, p.cols_valor.get(ym), otros=[x for x in c.boletines if x is not b])
                r['items'].append(res)
                v = rp.veredicto_items(res)
                veredictos.append(v)
                rp.imprimir_control(v)
            correr('items', f"1) Ítems INDEC {mes_txt(ym)} vs. {b.nombre}", f, veredictos)

    # ---- 2) VAR
    if 'var' in p.controles:
        def f():
            prep = vn.preparar_var(wb, p.hojas_var)
            n_man = vn.aplicar_referencias_manuales(prep, getattr(c, 'var_refs', None))
            if n_man:
                print(f"  VAR: {n_man} categoría(s) con el índice INDEC asignado a mano por el administrador.")
            res = vn.verificar_var(prep, c.boletines, p.meses)
            r['var'] = res
            v = rp.veredicto_var(res)
            veredictos.append(v)
            rp.imprimir_control(v)
        correr('var', '2) VAR', f, veredictos)

    # ---- 3) análisis de precios
    if 'ap' in p.controles:
        def f():
            if c.ap_items:
                act = ai.analizar_items(c.ctx, c.ap_items, c.boletines, p.sel_ap[0], p.sel_ap[1], meses_boletin={ym: b for b, ym in p.meses})
                if con_prev:
                    print("  (La comparación con la versión anterior no está disponible para el análisis por hoja de ítem.)")
            else:
                act = ap.analizar_ap(c.ctx, p.sel_ap[0], p.sel_ap[1])
                if con_prev:
                    try:
                        print(f"  Analizando la versión anterior ({prev_nombre})...")
                        ant = analisis_anterior_ap(c)
                        r['ap_cambios'], r['ap_faltan'], r['ap_desalineadas'] = ap.comparar_versiones(act, ant)
                        r['ap_prev'] = prev_nombre
                    except ErrorVerificacion as e:
                        print(f"  ⚠ No pude comparar con la versión anterior: {e}")
            if fm is not None:
                (ai if c.ap_items else ap).agregar_formulas(act, c.ctx, fm)
            r['ap'] = act
            v = rp.veredicto_ap(act, 'ap_prev' in r)
            veredictos.append(v)
            rp.imprimir_control(v, 'ap_prev' in r)
        correr('ap', '3) Análisis de precios', f, veredictos)

    # ---- 4) planilla de costos
    if 'costos' in p.controles:
        def f():
            act = cs.analizar_costos(c.ctx, p.planillas, c.hojas_analisis, p.sel_costos[0], p.sel_costos[1])
            if con_prev:
                try:
                    print(f"\n  Analizando la versión anterior ({prev_nombre})...")
                    ant = analisis_anterior_costos(c, act['resultados'][0]['pl'].hoja)
                    r['costos_cambios'], r['costos_faltan'] = cs.comparar_versiones_costos(act, ant)
                    r['costos_prev'] = prev_nombre
                except ErrorVerificacion as e:
                    print(f"  ⚠ No pude comparar con la versión anterior: {e}")
            if fm is not None:
                cs.agregar_formulas(act, fm)
            r['costos'] = act
            v = rp.veredicto_costos(act, 'costos_prev' in r)
            veredictos.append(v)
            rp.imprimir_control(v, 'costos_prev' in r)
        correr('costos', '4) Planilla de costos', f, veredictos)

    orden = {k: i for i, (k, _) in enumerate(CONTROLES)}
    veredictos.sort(key=lambda v: orden[v.clave])
    return veredictos, r


# ======================================================================
# Programa principal
# ======================================================================
class Salida:
    """Lo que dejó una corrida: archivos generados y resultados (lo usan las pruebas automáticas)."""
    def __init__(self):
        self.archivos = {}
        self.veredictos, self.r, self.observaciones = [], {}, []
        self.segundos = 0.0


def sesion_completa(args, interactivo):
    """Devuelve None si el usuario no dio ningún Excel (fin del programa) o una Salida."""
    excel = pedir_excel(args, interactivo)
    if not excel:
        return None
    salida = Salida()
    pdfs = pedir_pdfs(args, interactivo)
    prev = pedir_prev(args, interactivo)
    t0 = time.time()
    c = cargar(excel, pdfs, prev, args.hoja_indec, args.ap_manual)
    p = hacer_preguntas(args, c, interactivo)
    if not p.controles and not c.motivos:
        print("No hay controles para correr.")
        return salida
    print("\n" + "=" * 64 + "\nANALISIS (corre solo, sin preguntas)\n" + "=" * 64)
    fm = cargar_formulas(c, not args.sin_formulas)
    veredictos, r = analizar(c, p, os.path.basename(prev) if prev else None, fm)
    obs = ob.construir(r)
    salida.veredictos, salida.r, salida.observaciones = veredictos, r, obs
    carpeta = os.path.dirname(args.out) if args.out else '.'
    out = (args.out or nombre_salida_unico(excel, carpeta)) if 'excel' in p.salidas else None
    sesion = {'excel_verificacion': 'excel' in p.salidas, 'excel': excel, 'pdfs': [(b.nombre, mes_txt(ym)) for b, ym in p.meses] or [(b.nombre, '') for b in c.boletines],
              'prev': prev if c.prev_disponible() else None, 'parametros': p.resumen}
    print("\nGuardando los archivos...")
    if out:
        rp.escribir_reporte(out, sesion, veredictos, r, obs)
        salida.archivos['Excel de verificación'] = out
    if 'word' in p.salidas:
        try:
            ruta = nombre_salida_unico(excel, carpeta, 'Informe', '.docx')
            iw.escribir_informe(ruta, obs, r, veredictos, sesion, p.datos_informe, __version__)
            salida.archivos['Informe Word'] = ruta
        except ErrorVerificacion as e:
            print(f"  ⚠ No se generó el informe Word: {e}")
        except Exception as e:
            print(f"  ⚠ No se generó el informe Word: {type(e).__name__}: {e}")
            traceback.print_exc()
    if 'copia' in p.salidas and fm is None:
        print("  ⚠ No se generó la copia anotada: hace falta leer las fórmulas (solo .xlsx/.xlsm y sin --sin-formulas).")
    if fm is not None and 'copia' in p.salidas:
        try:
            ruta = nombre_salida_unico(excel, carpeta, 'Copia anotada', '.xlsx')
            marcadas, sin_lugar = ca.escribir_copia(ruta, fm, obs)
            salida.archivos['Copia anotada del Excel'] = ruta
            print(f"  Copia anotada: {marcadas} celdas marcadas" + (f" ({sin_lugar} lugares sin celda propia, solo en el informe)" if sin_lugar else ''))
        except Exception as e:
            print(f"  ⚠ No se generó la copia anotada: {type(e).__name__}: {e}")
    salida.segundos = time.time() - t0
    rp.imprimir_final(veredictos, out, salida.segundos, obs, salida.archivos)
    return salida


def main(argv=None):
    configurar_consola()
    args = parse_args(argv)
    interactivo = not args.sin_preguntas
    print("=" * 64 + "\n  VERIFICADOR UNIFICADO DE REDETERMINACIONES\n"
          "  Ítems INDEC · VAR · Análisis de precios · Planilla de costos\n" + "=" * 64)
    while True:
        try:
            seguir = sesion_completa(args, interactivo) is not None
        except ErrorVerificacion as e:
            print(f"\n⚠ {e}")
            seguir = True
        except Exception:
            print("\n⚠ Ocurrió un error inesperado:")
            traceback.print_exc()
            seguir = True
        if not interactivo or not seguir:
            break
        op = pedir("\nEnter = terminar | 'otro' = analizar otro Excel > ").lower()
        if op not in ('otro', 'excel', 'nuevo'):
            break
        args.excel = args.pdf = args.prev = None
        args.pdf, args.meses, args.hoja_items, args.hoja_var, args.hoja_indec = [], None, None, None, None
        args.cols_ap = args.cols_costos = args.planilla = args.out = args.ap_manual = None
    print("Listo, ¡hasta la próxima!")

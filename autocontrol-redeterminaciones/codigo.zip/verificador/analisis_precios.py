# -*- coding: utf-8 -*-
"""
analisis_precios.py  --  CONTROL 3: análisis de precios
--------------------------------------------------------
Verifica el ANALISIS DE PRECIOS de una redeterminación (todas las hojas de análisis, sin importar cómo las
haya armado la contratista):
  1) INDICES: para cada insumo toma su identificador (Nº o código INDEC), busca esa fila en la hoja de
     índices del mismo archivo y compara el índice BASE y el de la REDETERMINACION contra lo que dice
     esa hoja para el mes del encabezado del bloque. Solo mira VALORES (no fórmulas).
  2) PRECIO: recalcula el precio actualizado con los índices correctos
         P_nuevo = P_anterior x (A0 + V0 x coef)         coef = redet / base
     (sin anticipo: P_anterior x coef) y lo compara fila por fila.
  3) CADENA DE PRECIOS: cada bloque debe arrancar del precio actualizado del bloque anterior.
  4) ANTICIPO FINANCIERO: A0 y V0 se recalculan desde la hoja AF (A0 = A.F x V0 / V1, V0 = 1 - A0).
  5) (opcional) VERSION ANTERIOR APROBADA: marca cada hallazgo como NUEVO o HEREDADO.

Funciones principales:
    analizar_ap(ctx, seleccion)          -> resultado del análisis
    comparar_versiones(act, ant)         -> (cambios, faltan, desalineadas)
"""
import re

from openpyxl.utils import column_index_from_string as CI, get_column_letter as L

from .bloques import _leer_filas_bloque
from .comunes import (TOL_FACTOR, TOL_INDICE, TOL_PRECIO_ABS, TOL_PRECIO_REL, ErrorVerificacion, es_error,
                      fmt_es, mes_txt, num)
from .seleccion import bloque_seleccionado, texto_bloques


# ----------------------------------------------------------------------
# Motor de controles
# ----------------------------------------------------------------------
def _ols(xs, ys):
    n = len(xs)
    if n < 3:
        return None
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx < 1e-12:
        return None
    v = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    return my - v * mx, v


def _ols_robusto(xs, ys):
    """Regresión y = a + v x que ignora valores atípicos (un precio pisado a mano no debe arruinar el ajuste)."""
    pares = list(zip(xs, ys))
    aj = _ols(xs, ys)
    for _ in range(5):
        if aj is None:
            break
        a, v = aj
        res = sorted(abs(y - (a + v * x)) for x, y in pares)
        umbral = max(1e-6, 4 * res[len(res) // 2])
        keep = [(x, y) for x, y in pares if abs(y - (a + v * x)) <= umbral]
        if len(keep) == len(pares) or len(keep) < max(3, len(xs) // 2):
            break
        pares = keep
        aj = _ols([p[0] for p in pares], [p[1] for p in pares]) or aj
    return aj


def _ajustar_columna(filas, col, esperado):
    """¿Cuánto se parece la columna 'col' al PRECIO ANTERIOR? Devuelve (fraccion_de_filas_que_encajan, a, v)
    para P_nuevo / P_ant = a + v x coef. Se prueba primero con el (A0, V0) ESPERADO (desde AF), que no
    depende de los datos; si los precios se calcularon con otros valores, se ajusta con los propios datos."""
    xs, ys = [], []
    for f in filas:
        cf, pn, pa = num(f['coef']), num(f['precio']), f['izq'].get(col)
        if cf is None or pn is None or not pa or pa <= 0:
            continue
        xs.append(cf)
        ys.append(pn / pa)
    if not xs:
        return 0.0, None, None
    def fraccion(a, v):
        return sum(1 for x, y in zip(xs, ys) if abs(y - (a + v * x)) < 1e-5) / len(xs)
    mejor = (0.0, None, None)
    if esperado is not None:
        mejor = (fraccion(*esperado), esperado[0], esperado[1])
        if mejor[0] >= 0.5:
            # El A0 / V0 de AF explica la mayoría de las filas: se lo toma como válido y las que no cierran (ej. filas que
            # apuntan al A0 de otra redeterminación) se informan una por una. El ajuste libre solo se usa cuando AF no
            # explica ni la mitad de las filas (los precios se calcularon con otro A0). Ajustar libremente con filas
            # mezcladas da un A0 "promedio" que no existe.
            return mejor
    if len(xs) >= 5:
        aj = _ols_robusto(xs, ys)
        if aj is not None:
            fr = fraccion(*aj)
            if fr > mejor[0] + 1e-9:
                mejor = (fr, aj[0], aj[1])
    return mejor


def identificar_precio_anterior(b, bloque_prev, esperado):
    """Devuelve (columna, a_ajustado, v_ajustado, fraccion) del precio anterior."""
    if not b.filas:
        return None
    cands = set(b.filas[0]['izq'])
    if bloque_prev is not None:
        cands.add(bloque_prev.c_precio)
    mejor = None
    for col in cands:
        if not any(f['izq'].get(col) for f in b.filas):
            continue
        frac, a, v = _ajustar_columna(b.filas, col, esperado)
        clave = (frac, -abs(b.c_base - col))
        if mejor is None or clave > mejor[0]:
            mejor = (clave, col, a, v, frac)
    if mejor is None or mejor[4] < 0.5:
        return None
    return mejor[1], mejor[2], mejor[3], mejor[4]


def columnas_por_fila(b, col_prev, a, v, precio_bloque_ant=None, desde=None):
    """Columna del PRECIO ANTERIOR fila por fila.

    Muchas planillas usan la misma columna para todo el bloque, pero otras cambian el orden según la
    sección del análisis (ej. EISA: en materiales es 'cantidad | precio' y en mano de obra es
    'precio | horas'). Con una sola columna para todo, en una de las secciones se leía la CANTIDAD como
    si fuera el precio y se marcaban cientos de errores falsos.

    Se usan: la columna principal (la que explica más filas) y, además, cualquier otra columna que
    explique EXACTAMENTE (precio nuevo = precio anterior x factor) un grupo de filas que la principal no
    explica (al menos 3 filas). Cada fila toma la primera que la explica; si ninguna la explica (un error
    real), toma la del renglón más cercano de arriba, que es la de su misma sección, y el error se
    informa contra esa columna. Devuelve ({fila: columna}, [columnas extra usadas]).

    'desde': primera columna PROPIA del bloque (la siguiente al precio del bloque anterior). Las columnas
    extra se buscan primero entre las propias: la columna de precio del bloque ANTERIOR casi siempre
    "explica" las filas (es justamente el precio de partida correcto), y si se la usara taparía el error
    de un bloque que arranca de un valor tipeado en lugar de ese precio (San Benito, EQ-010)."""
    def explica(f, c):
        pa, pn, cf = f['izq'].get(c), num(f['precio']), num(f['coef'])
        if not pa or pa <= 0 or pn is None or cf is None:
            return False
        esperado = pa * (a + v * cf)
        return abs(pn - esperado) <= max(TOL_PRECIO_ABS, TOL_PRECIO_REL * abs(esperado))

    def arranca_bien(f, c):          # el precio de partida es el precio del bloque anterior
        pp = (precio_bloque_ant or {}).get(f['r'])
        pa = f['izq'].get(c)
        return bool(pp) and bool(pa) and abs(pa - pp) <= max(TOL_PRECIO_ABS, TOL_PRECIO_REL * abs(pp))

    sin_explicar = [f for f in b.filas if not explica(f, col_prev)]
    extras = []
    todas = [c for c in b.filas[0]['izq'] if c != col_prev] if b.filas else []
    propias = [c for c in todas if desde is None or c >= desde]
    ajenas = [c for c in todas if c not in propias]
    for otras in (propias, ajenas):
        otras = list(otras)
        while sin_explicar and otras:
            cuenta = {c: sum(1 for f in sin_explicar if explica(f, c)) for c in otras}
            c = max(cuenta, key=lambda k: (cuenta[k], -abs(b.c_base - k)))
            if cuenta[c] < 3:
                break
            extras.append(c)
            otras.remove(c)
            sin_explicar = [f for f in sin_explicar if not explica(f, c)]
    usadas = [col_prev] + extras
    asignada, ultima = {}, col_prev
    for f in b.filas:
        col = next((c for c in usadas if explica(f, c)), None)
        if col is None:
            col = next((c for c in usadas if arranca_bien(f, c)), None)
        if col is None:
            col = ultima if f['izq'].get(ultima) else col_prev
        asignada[f['r']] = col
        ultima = col
    return asignada, extras


def _validar_secuencia_redet(bloques, af_numeros):
    """El número de redeterminación de un bloque debe ser el siguiente al del bloque anterior y (si hay hoja AF) existir
    en ella. Si el encabezado trae otro número (típico error de tipeo: '65º REDET' por '6º'), se toma el que corresponde y se avisa."""
    anterior = None
    for b in sorted(bloques, key=lambda x: x.c_base):
        n = b.n_redet
        if anterior is not None:
            esperado = anterior + 1
            plausible = n == esperado
            if not plausible and (n is None or n not in af_numeros or n < anterior):
                if esperado in b.n_redet_cands or esperado in af_numeros or n is None:
                    b.nota_redet = (f"El encabezado dice '{n}º REDET'" if n else "El encabezado no trae el número de redeterminación") + \
                                   f"; se tomó {esperado}º (es la que sigue a la anterior" + (" y existe en AF)." if esperado in af_numeros else ").")
                    b.n_redet = esperado
        anterior = b.n_redet if b.n_redet else anterior


def esperado_anticipo(b, af_por_n):
    """(a, v, origen, info_af) que DEBE usar el bloque, según AF."""
    if b.usa_anticipo is False:
        return 0.0, 1.0, 'sin anticipo (P x coef)', None
    af = af_por_n.get(b.n_redet) if b.n_redet else None
    if af is not None and b.usa_anticipo:
        V1, V0, pct = af['V1'], af['V0'], af['pct']
        if all(isinstance(x, float) for x in (V1, V0, pct)) and V1 != 0:
            if abs(V1 - V0) <= 1e-6 * max(abs(V1), 1) and isinstance(af.get('A0_res'), float):
                # V1 = V0 (típico de la primera redeterminación: todavía no hay un valor propio
                # distinto del precio de contrato). En ese caso la fórmula pct*V0/V1 no sirve para
                # deducir el A0 correcto: siempre da exactamente 'pct', tenga o no sentido, porque
                # V0/V1 vale 1 sin importar si a esta altura ya se pagó anticipo o no (eso depende del
                # contrato, no de la cuenta). Se usa el A0 que la propia hoja AF declara (A0_res).
                return af['A0_res'], af.get('V0_res', 1.0 - af['A0_res']), 'AF (A0 declarado; V1 = V0 no permite recalcularlo)', af
            a0 = pct * V0 / V1
            return a0, 1.0 - a0, 'AF (A.F x V0 / V1)', af
    if b.usa_anticipo:
        return None, None, 'no se pudo recalcular desde AF', af
    return None, None, 'fórmula del bloque no declarada', af


def _hallazgo(**kw):
    base = {'hoja': '', 'bloque': '', 'fila': '', 'col': '', 'no': '', 'insumo': '', 'tipo': '',
            'valor_hoja': None, 'valor_esperado': None, 'causa': '', 'detalle': '', 'nivel': 'ERROR',
            'm_base': None, 'm_red': None}
    base.update(kw)
    return base


def _mes_que_coincide(vals, val, m_esperado, b):
    """Si un índice mal cargado es EXACTAMENTE el de otro mes de la misma fila de la tabla de índices (típico de un
    bloque copiado de la redeterminación anterior sin actualizar la referencia al mes), devuelve ese mes; si no, None.
    Primero se prueba el mes base del bloque (el caso más común: el índice de la redet. quedó igual al base)."""
    if val is None:
        return None
    candidatos = [m for m in (b.m_base, b.m_red) if m and m != m_esperado] + sorted((m for m in vals if m != m_esperado), reverse=True)
    for m in candidatos:
        v = vals.get(m)
        if v is not None and abs(v - val) <= TOL_INDICE:
            return m
    return None


def analizar_hoja(ws, nombre_hoja, bloques, tabla, af_por_n, seleccion=None):
    """Devuelve (bloques, hallazgos, resumen_por_bloque). Si hay 'seleccion', solo se REPORTAN los
    bloques elegidos; los anteriores igual se leen para poder encadenar los precios."""
    for b in bloques:
        b.seleccionado = bloque_seleccionado(b, seleccion)
    idx_sel = [i for i, b in enumerate(bloques) if b.seleccionado]
    if not idx_sel:
        return bloques, [], []
    ultimo_sel = idx_sel[-1]
    hallazgos = []
    resumen = []
    prev = None
    cadena = {}          # fila -> precio correcto acumulado (o None si la cadena se cortó)
    precio_bloque_ant = {}   # fila -> precio que muestra la hoja en el bloque anterior
    cortes = {}          # fila -> etiqueta del primer bloque donde el precio de partida no era el anterior
    for k, b in enumerate(bloques):
        if k > ultimo_sel:
            break                       # lo que viene después del último bloque elegido no hace falta
        _leer_filas_bloque(ws, b, tabla)
        res = {'hoja': nombre_hoja, 'bloque': b.etiqueta, 'm_base': b.m_base, 'm_red': b.m_red,
               'n_redet': b.n_redet, 'insumos': len(b.filas), 'ind_ok': 0, 'ind_mal': 0,
               'pre_ok': 0, 'pre_mal': 0, 'acum_mal': 0, 'cortes': 0, 'a0_hoja': b.a0_decl, 'a0_af': None,
               'a0_ajuste': None, 'v0_ajuste': None, 'frac_ajuste': None, 'col_prev': None,
               'a_esp': None, 'v_esp': None, 'origen_av': '', 'notas': []}

        # -- fechas encadenadas
        if prev is not None and prev.m_red != b.m_base:
            res['notas'].append(f"la base de este bloque ({mes_txt(b.m_base)}) no coincide con la redet. anterior ({mes_txt(prev.m_red)})")
            hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=b.fila_hdr, col=L(b.c_base), tipo='Fechas del bloque',
                                       detalle=res['notas'][-1], m_base=b.m_base, m_red=b.m_red))
        # -- ¿la hoja INDEC tiene esos meses?
        meses_indec = set()
        for d in tabla.values():
            meses_indec.update(d['vals'].keys())
        for m, rot, col_f in ((b.m_base, 'base', b.c_base), (b.m_red, 'redeterminación', b.c_red)):
            if m not in meses_indec:
                res['notas'].append(f"la hoja INDEC no tiene el mes {mes_txt(m)} ({rot})")
                hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=b.fila_hdr, col=L(col_f), tipo='INDEC sin ese mes',
                                           detalle=res['notas'][-1], m_base=b.m_base, m_red=b.m_red))

        # -- 1) índices por Nº
        coef_exp = {}
        for f in b.filas:
            no = f['no']
            if es_error(no):
                p = num(f['precio'])
                if p is not None and p > 0:
                    res['ind_mal'] += 1
                    hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=f['r'], col=L(b.cn), no=no,
                                               tipo=f'{b.id_nombre} con error', valor_hoja=p,
                                               detalle=f'El insumo tiene precio pero no está vinculado a la hoja de índices (el {b.id_nombre} da error): no se actualiza.',
                                               m_base=b.m_base, m_red=b.m_red))
                else:
                    hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=f['r'], col=L(b.cn), no=no, nivel='AVISO',
                                               tipo=f'{b.id_nombre} con error', detalle="Renglón sin valor (p. ej. 'S/V'): no afecta ningún precio.",
                                               m_base=b.m_base, m_red=b.m_red))
                continue
            if no not in tabla:
                res['ind_mal'] += 1
                hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=f['r'], col=L(b.cn), no=no,
                                           tipo=f'{b.id_nombre} inexistente en INDEC', detalle=f'Ese {b.id_nombre} no figura en la hoja de índices.',
                                           m_base=b.m_base, m_red=b.m_red))
                continue
            d = tabla[no]
            ob, orr = d['vals'].get(b.m_base), d['vals'].get(b.m_red)
            base, red = num(f['base']), num(f['red'])
            mal = False
            for etiqueta, val, esp, col in (('Índice base', base, ob, b.c_base), ('Índice de la redet.', red, orr, b.c_red)):
                if esp is None:
                    continue
                if val is None or abs(val - esp) > TOL_INDICE:
                    mal = True
                    m_esp = b.m_base if col == b.c_base else b.m_red
                    hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=f['r'], col=L(col), no=no,
                                               insumo=(f.get('nombre') or d['nombre']), tipo=etiqueta, valor_hoja=val, valor_esperado=esp,
                                               detalle=f"INDEC dice {esp:g} para {mes_txt(m_esp)}",
                                               m_base=b.m_base, m_red=b.m_red, mes_usado=_mes_que_coincide(d['vals'], val, m_esp, b)))
            if mal:
                res['ind_mal'] += 1
                f['indice_mal'] = True
            elif ob is not None and orr is not None:
                res['ind_ok'] += 1
            if ob and orr:
                coef_exp[f['r']] = orr / ob

        # -- 2) A0 / V0 esperados (desde AF) y precio anterior
        a_e, v_e, origen, af = esperado_anticipo(b, af_por_n)
        if b.nota_redet:
            res['notas'].append(b.nota_redet)
            hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=b.fila_hdr, col=L(b.c_coef), tipo='Número de redeterminación corregido', nivel='AVISO',
                                       detalle=b.nota_redet, m_base=b.m_base, m_red=b.m_red))
        if a_e is None and b.usa_anticipo and b.a0_decl is not None:
            # AF no tiene esta redeterminación: no se puede cruzar. Se controlan los precios con el A0 que declara la hoja
            # (mejor que estimarlo de los propios precios) y se avisa que ese A0 no se pudo verificar contra AF.
            a_e = b.a0_decl
            v_e = b.v0_decl if b.v0_decl is not None else 1.0 - b.a0_decl
            origen = 'A0 escrito en la hoja (no hay bloque en AF para esta redeterminación)'
            hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=b.a0_fila or b.fila_hdr, col=L(b.c_precio), tipo='Anticipo financiero (AF)', nivel='AVISO',
                                       valor_hoja=b.a0_decl,
                                       detalle=f"La hoja AF no tiene un bloque para la redeterminación {b.n_redet}: el A0 de la hoja ({b.a0_decl:.6f}) no se pudo verificar contra AF. "
                                               "Los precios se controlaron con ese A0.", m_base=b.m_base, m_red=b.m_red))
        res['a_esp'], res['v_esp'], res['origen_av'] = a_e, v_e, origen
        if af is not None and isinstance(af.get('A0_res'), float):
            res['a0_af'] = af['A0_res']
        esperado = (a_e, v_e) if a_e is not None else None
        ident = identificar_precio_anterior(b, prev, esperado)
        if ident is None:
            res['notas'].append('No pude identificar la columna del precio anterior: se controlan solo los índices.')
            hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=b.fila_hdr, col=L(b.c_precio), tipo='Precio no controlado', nivel='AVISO',
                                       detalle=res['notas'][-1], m_base=b.m_base, m_red=b.m_red))
            for f in b.filas:
                cadena[f['r']] = None
            precio_bloque_ant = {f['r']: num(f['precio']) for f in b.filas}
            prev = b
            resumen.append(res)
            continue
        col_prev, a_fit, v_fit, frac = ident
        res.update({'col_prev': col_prev, 'a0_ajuste': a_fit, 'v0_ajuste': v_fit, 'frac_ajuste': frac})
        if a_e is None:                 # sin AF: se usa lo que muestran los propios precios
            a_e, v_e = a_fit, v_fit
            res['a_esp'], res['v_esp'] = a_e, v_e
            res['origen_av'] += ' -> se usa el ajuste de los precios'
        # Si el A0 que USAN los precios no es el de AF, se informa UNA vez (con su impacto) y las filas se
        # controlan con el A0 que la hoja efectivamente aplica: así no se marcan miles de filas por una
        # sola causa y siguen visibles los demás errores.
        a_af_ref, v_af_ref = a_e, v_e
        a0_discrepa = a_fit is not None and abs(a_fit - a_e) > TOL_FACTOR * 20
        if a0_discrepa:
            a_e, v_e = a_fit, v_fit
            res['a0_discrepa'] = True

        col_fila, extras = columnas_por_fila(b, col_prev, a_e, v_e, precio_bloque_ant if k > 0 else None,
                                             desde=(prev.c_precio + 1) if prev is not None else None)
        if extras:
            res['cols_prev_extra'] = extras
            res['notas'].append("el precio anterior no está en la misma columna en todas las filas: se usó " +
                                f"{L(col_prev)} y, en las secciones que lo tienen en otro lugar, " + ', '.join(L(c) for c in extras))
        for f in b.filas:
            r = f['r']
            no = f['no']
            if no not in tabla:
                cadena[r] = None
                continue
            col_r = col_fila.get(r, col_prev)
            pa, pn = f['izq'].get(col_r), num(f['precio'])
            ce = coef_exp.get(r)
            if not pa or pn is None or ce is None:
                cadena[r] = None                 # la cadena de esta fila se corta: no hay con qué comparar
                continue
            # el precio de partida debe ser el precio actualizado del bloque anterior
            pp = precio_bloque_ant.get(r)
            if k > 0 and pp and abs(pa - pp) > max(TOL_PRECIO_ABS, TOL_PRECIO_REL * abs(pp)):
                res['cortes'] += 1
                cortes.setdefault(r, b.etiqueta)
                hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=r, col=L(col_r), no=no,
                                           insumo=(f.get('nombre') or tabla[no]['nombre']), tipo='Precio de partida ≠ precio de la redet. anterior',
                                           valor_hoja=pa, valor_esperado=pp,
                                           detalle='El bloque no arranca del precio actualizado del bloque anterior: la cadena se cortó.',
                                           m_base=b.m_base, m_red=b.m_red))
            # precio "local": con el precio anterior de la hoja y el índice correcto
            p_loc = pa * (a_e + v_e * ce)
            tol = max(TOL_PRECIO_ABS, TOL_PRECIO_REL * abs(p_loc))
            if abs(pn - p_loc) <= tol:
                res['pre_ok'] += 1
            else:
                res['pre_mal'] += 1
                causa = 'consecuencia del índice de esta fila' if f.get('indice_mal') else 'el precio no sigue la fórmula del bloque'
                hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=r, col=L(b.c_precio), no=no,
                                           insumo=(f.get('nombre') or tabla[no]['nombre']), tipo='Precio del bloque', valor_hoja=pn, valor_esperado=p_loc,
                                           causa=causa, detalle=f"con A0={a_e:.4f} / V0={v_e:.4f}", m_base=b.m_base, m_red=b.m_red))
            # precio "acumulado": cadena desde el precio base con los índices correctos
            base_ac = pa if k == 0 else cadena.get(r)
            p_ac = base_ac * (a_e + v_e * ce) if base_ac else None
            cadena[r] = p_ac
            if p_ac is not None and k == ultimo_sel and abs(pn - p_ac) > max(TOL_PRECIO_ABS, TOL_PRECIO_REL * abs(p_ac)):
                res['acum_mal'] += 1
                hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=r, col=L(b.c_precio), no=no,
                                           insumo=(f.get('nombre') or tabla[no]['nombre']), tipo='Precio acumulado (vs. cadena correcta)',
                                           valor_hoja=pn, valor_esperado=p_ac,
                                           causa=(f"la cadena se cortó en {cortes[r]}" if r in cortes else
                                                  ('error arrastrado de un bloque anterior' if abs(pn - p_loc) <= tol else 'ver hallazgos de este bloque')),
                                           m_base=b.m_base, m_red=b.m_red))

        precio_bloque_ant = {f['r']: num(f['precio']) for f in b.filas}

        # -- A0 / V0 vs lo que usa el análisis y lo que muestran los precios
        if b.usa_anticipo or (b.usa_anticipo is None and abs((a_fit or 0)) > 1e-9):
            if a0_discrepa:
                imp = [(a_af_ref + v_af_ref * ce) / (a_fit + v_fit * ce) - 1
                       for ce in coef_exp.values() if abs(a_fit + v_fit * ce) > 1e-9]
                if imp:
                    res['impacto_a0'] = (min(imp), max(imp))
                    txt_imp = f" Con el A0 correcto, los precios de este bloque cambiarían entre {min(imp):+.3%} y {max(imp):+.3%}."
                else:
                    txt_imp = ''
                hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=b.a0_fila or b.fila_hdr, col=L(b.c_precio), tipo='Anticipo financiero (A0)',
                                           valor_hoja=a_fit, valor_esperado=a_af_ref,
                                           detalle=f"Los precios de este bloque se calcularon con A0={a_fit:.6f}; " + ("según AF" if af is not None else "según el A0 escrito en la hoja") + f" debería ser {a_af_ref:.6f}.{txt_imp}",
                                           m_base=b.m_base, m_red=b.m_red))
            elif b.a0_decl is not None and a_af_ref is not None and abs(b.a0_decl - a_af_ref) > TOL_FACTOR:
                hallazgos.append(_hallazgo(hoja=nombre_hoja, bloque=b.etiqueta, fila=b.a0_fila or b.fila_hdr, col=L(b.c_precio), tipo='Anticipo financiero (A0)',
                                           valor_hoja=b.a0_decl, valor_esperado=a_af_ref,
                                           detalle=f"El A0 escrito encima de la columna de precio ({b.a0_decl:.6f}) no es el de AF ({a_af_ref:.6f}), aunque los precios sí usan el de AF." if af is not None else
                                                   f"El A0 escrito encima de la columna de precio ({b.a0_decl:.6f}) no coincide con el que usan los precios ({a_af_ref:.6f}).",
                                           m_base=b.m_base, m_red=b.m_red))
        prev = b
        resumen.append(res)
    # solo se informa lo de los bloques elegidos
    etiquetas = {b.etiqueta for b in bloques if b.seleccionado}
    hallazgos = [h for h in hallazgos if h['bloque'] in etiquetas]
    resumen = [r for r in resumen if r['bloque'] in etiquetas]
    return bloques, hallazgos, resumen


# ----------------------------------------------------------------------
# Controles de la hoja AF
# ----------------------------------------------------------------------
def agrupar_resumen(resumen):
    """Un renglón por redeterminación. Cuando el análisis está en muchas hojas (una por ítem), suma
    las hojas en vez de mostrar un renglón por hoja."""
    grupos = {}
    for x in resumen:
        k = (x['bloque'], x['m_base'], x['m_red'])
        g = grupos.get(k)
        if g is None:
            g = dict(x)
            g['hojas'] = [x['hoja']]
            g['notas'] = list(x['notas'])
            grupos[k] = g
            continue
        for c in ('insumos', 'ind_ok', 'ind_mal', 'pre_ok', 'pre_mal', 'acum_mal', 'cortes'):
            g[c] += x[c]
        g['hojas'].append(x['hoja'])
        for t in x['notas']:
            if t not in g['notas']:
                g['notas'].append(t)
        if g['a_esp'] is None:
            g['a_esp'], g['v_esp'], g['a0_ajuste'] = x['a_esp'], x['v_esp'], x['a0_ajuste']
        if g['a0_hoja'] is None:
            g['a0_hoja'] = x['a0_hoja']
    for g in grupos.values():
        g['hoja'] = g['hojas'][0] if len(g['hojas']) == 1 else f"{len(g['hojas'])} hojas"
    return list(grupos.values())


def controlar_af(af_bloques, usados):
    """Un renglón por bloque de AF con sus controles. 'usados' = nros de
    redeterminación cuyo análisis usa A0 en su fórmula. Cada hallazgo indica
    la celda de AF donde está el dato cuestionado."""
    filas = []
    hallazgos = []
    v0_ref = None
    previos = []            # bloques de AF ya vistos (para aceptar el V0 "telescópico")

    def nota(fila, b, texto, campo=None, nivel=None):
        fila['notas'].append(texto)
        r, c = b['celdas'].get(campo, (b['fila'], b.get('col_titulo', 1))) if campo else (b['fila'], b.get('col_titulo', 1))
        hallazgos.append(_hallazgo(hoja=b.get('hoja', 'AF'), bloque=f"R{b['n']}", fila=r, col=L(c), tipo='Anticipo financiero (AF)',
                                   detalle=texto, nivel=nivel or ('ERROR' if fila['usado'] else 'AVISO')))

    for b in af_bloques:
        n = b['n']
        fila = {'n': n, 'usado': n in usados, 'V1': b['V1'], 'V0': b['V0'], 'pct': b['pct'],
                'A0_calc': None, 'A0_af': b['A0_res'], 'V0_af': b['V0_res'], 'estado': 'OK', 'notas': []}
        if b.get('reemplazado_por'):
            # el mismo Rn está más abajo: se usa el último; este es un bloque viejo o repetido
            fila['usado'] = False
            fila['notas'].append(f"hay otro bloque R{n} más abajo (fila {b['reemplazado_por']}) y es el que se usa")
            hallazgos.append(_hallazgo(hoja=b.get('hoja', 'AF'), bloque=f"R{n}", fila=b['fila'], col=L(b.get('col_titulo', 1)), tipo='Anticipo financiero (AF)',
                                       nivel='AVISO', detalle=f"El bloque R{n} de la fila {b['fila']} está repetido: el que se usa es el de la fila {b['reemplazado_por']}. "
                                                              "Conviene borrar el viejo para evitar confusiones."))
            fila['estado'] = 'AVISO (repetido)'
            filas.append(fila)
            continue
        vals = (b['V1'], b['V0'], b['pct'])
        if any(v == 'ERR' or v is None for v in vals):
            falta = next(k for k, v in (('V1', b['V1']), ('V0', b['V0']), ('pct', b['pct'])) if v == 'ERR' or v is None)
            nota(fila, b, 'faltan datos o hay error (#DIV/0!) en V1 / V0 / % de anticipo', falta)
        else:
            if b['V1'] == 0:
                nota(fila, b, 'V1 es cero', 'V1')
            elif abs(b['V1'] - b['V0']) <= 1e-6 * max(abs(b['V1']), 1):
                # V1 = V0 (típico de la primera redeterminación): la fórmula pct*V0/V1 no sirve para
                # validar el A0 declarado (V0/V1 = 1 siempre, tenga o no sentido el resultado) -- no hay
                # con qué compararlo de forma independiente, así que no se marca ningún desacuerdo.
                fila['A0_calc'] = None
            else:
                fila['A0_calc'] = b['pct'] * b['V0'] / b['V1']
                a_af = b['A0_res']
                if isinstance(a_af, float) and abs(a_af - fila['A0_calc']) > TOL_FACTOR:
                    nota(fila, b, f"A0 en AF = {a_af:.6f} pero A.F x V0 / V1 = {fila['A0_calc']:.6f}", 'A0_res')
                v_af = b['V0_res']
                if isinstance(v_af, float) and isinstance(a_af, float) and abs(v_af - (1 - a_af)) > TOL_FACTOR:
                    nota(fila, b, f"V0 en AF = {v_af:.6f} pero 1 - A0 = {1 - a_af:.6f}", 'V0_res')
            # V0 válido: el precio de contrato, o el precio (V1 o V0) de CUALQUIER redeterminación anterior
            # (esquema "telescópico": cada redeterminación parte del precio de una anterior, ej. la R3 con el
            # precio de la R2 o de la R1). Eso es correcto y no se informa; solo se marca un V0 que no es
            # ninguno de esos precios.
            if v0_ref is None:
                v0_ref = b['V0']
            else:
                origen = None
                if abs(b['V0'] - v0_ref) <= 0.005:
                    origen = 'precio de contrato'
                else:
                    for a in reversed(previos):
                        if isinstance(a['V1'], float) and abs(b['V0'] - a['V1']) <= 0.005:
                            origen = f"precio de la R{a['n']} (esquema telescópico)"
                            break
                        if isinstance(a['V0'], float) and abs(b['V0'] - a['V0']) <= 0.005:
                            origen = f"mismo V0 que la R{a['n']}"
                            break
                fila['v0_origen'] = origen
                if origen is None:
                    nota(fila, b, f"el precio de partida V0 ({fmt_es(b['V0'])}) no es el precio de contrato ({fmt_es(v0_ref)}) "
                                  "ni el precio (V1) de ninguna redeterminación anterior", 'V0', nivel='AVISO')
            previos.append(b)
            m = re.search(r'(\d+)\s*[°º]', b['V1_rotulo']) or re.search(r'n\s*[°º]?\s*(\d+)', b['V1_rotulo'].lower())
            if m and n and n >= 2 and int(m.group(1)) != n - 1:
                nota(fila, b, f"el rótulo de V1 dice redeterminación {m.group(1)} y debería ser la {n - 1}", 'V1')
        if fila['notas']:
            solo_v0 = all('precio de partida V0' in t for t in fila['notas'])
            fila['estado'] = 'AVISO' if solo_v0 else ('REVISAR' if fila['usado'] else 'AVISO (no se usa)')
        filas.append(fila)
    return filas, hallazgos



# ----------------------------------------------------------------------
# Pipeline: analiza un libro ya abierto (Contexto)
# ----------------------------------------------------------------------
def resolver_seleccion(hojas_bloques, tokens, texto_elegido):
    """Bloques que toca la selección; error si no toca ninguno."""
    todos = [b for bl in hojas_bloques.values() for b in bl]
    elegidos = [b for b in todos if bloque_seleccionado(b, tokens)]
    if not elegidos:
        raise ErrorVerificacion(f"El rango '{texto_elegido}' no toca ningún bloque de índices. "
                                f"Bloques detectados: {texto_bloques(todos)}")
    return elegidos


def analizar_ap(ctx, seleccion=None, seleccion_txt='todas', progreso=True):
    """seleccion: tokens de seleccion.parsear_seleccion (None = todo)."""
    def say(*a):
        if progreso:
            print(*a)

    if not ctx.hojas_indec:
        raise ErrorVerificacion("No encontré la hoja de índices del INDEC (INDEC / Indices...) en este archivo.")
    if not ctx.tabla:
        raise ErrorVerificacion(f"La hoja '{ctx.hojas_indec[0]}' no tiene una columna Nº o Código con índices por mes.")
    hojas_bloques = ctx.hojas_bloques
    if not hojas_bloques:
        raise ErrorVerificacion("No encontré ninguna hoja de análisis de precios (columnas Nº / índices / coef. / precio actualizado).")
    if seleccion is not None:
        resolver_seleccion(hojas_bloques, seleccion, seleccion_txt)

    for bl in hojas_bloques.values():
        _validar_secuencia_redet(bl, set(ctx.af_por_n))
    say(f"  Hoja de índices: {ctx.hojas_indec}  ({len(ctx.tabla)} claves con índices por mes)")
    say(f"  Anticipo financiero: {', '.join(ctx.hojas_af) or 'no encontrada'}"
        + (f"  (redeterminaciones: {sorted(ctx.af_por_n)})" if ctx.af_bloques else ''))

    hojas, hallazgos, resumen = {}, [], []
    for n, bl in hojas_bloques.items():
        bl, h, r = analizar_hoja(ctx.wb[n], n, bl, ctx.tabla, ctx.af_por_n, seleccion)
        hojas[n] = bl
        hallazgos += h
        resumen += r
    elegidos = [b for bl in hojas.values() for b in bl if b.seleccionado]
    say(f"  {len(hojas)} hoja(s) de análisis. Bloques analizados: {texto_bloques(elegidos)}")

    usados = {b.n_redet for b in elegidos if b.usa_anticipo and b.n_redet}
    af_filas, h_af = controlar_af(ctx.af_bloques, usados)
    if seleccion is not None:      # solo lo de AF que corresponde a las redeterminaciones elegidas
        ns_sel = {f"R{b.n_redet}" for b in elegidos if b.n_redet}
        h_af = [h for h in h_af if h['bloque'] in ns_sel]
    hallazgos += h_af
    return {'path': ctx.path, 'hojas': hojas, 'hallazgos': hallazgos, 'resumen': resumen, 'af_filas': af_filas,
            'hojas_indec': ctx.hojas_indec, 'hoja_af': ', '.join(ctx.hojas_af), 'tabla': ctx.tabla,
            'seleccion_txt': seleccion_txt, 'resumen_agr': agrupar_resumen(resumen),
            'bloques_txt': texto_bloques(elegidos)}


# ----------------------------------------------------------------------
# Comparación con la versión anterior aprobada
# ----------------------------------------------------------------------
def _clave(h):
    return (h['hoja'], h['m_base'], h['m_red'], h['fila'], h['col'], h['tipo'], h['bloque'] if h['hoja'] == 'AF' else '')


def comparar_versiones(act, ant):
    """Marca cada hallazgo como NUEVO / HEREDADO y lista los valores de
    redeterminaciones anteriores que cambiaron."""
    claves_ant = {_clave(h) for h in ant['hallazgos']}
    bloques_ant = {(n, b.m_base, b.m_red): b for n, bl in ant['hojas'].items() for b in bl}
    for h in act['hallazgos']:
        if h['hoja'] == 'AF':
            h['version'] = 'HEREDADO' if _clave(h) in claves_ant else 'NUEVO'
        elif (h['hoja'], h['m_base'], h['m_red']) not in bloques_ant:
            h['version'] = 'NUEVO (bloque nuevo)'
        else:
            h['version'] = 'HEREDADO' if _clave(h) in claves_ant else 'NUEVO'

    cambios = []
    desalineadas = 0
    for n, bl in act['hojas'].items():
        for b in bl:
            if not b.seleccionado:
                continue
            bp = bloques_ant.get((n, b.m_base, b.m_red))
            if bp is None:
                continue
            filas_ant = {f['r']: f for f in bp.filas}
            for f in b.filas:
                fa = filas_ant.get(f['r'])
                if fa is None:
                    cambios.append({'hoja': n, 'bloque': b.etiqueta, 'fila': f['r'], 'campo': 'fila nueva', 'no': f['no'],
                                    'antes': None, 'ahora': None})
                    continue
                if fa['no'] != f['no']:
                    desalineadas += 1
                    cambios.append({'hoja': n, 'bloque': b.etiqueta, 'fila': f['r'], 'campo': 'Nº distinto', 'no': f['no'],
                                    'antes': fa['no'], 'ahora': f['no']})
                    continue
                for campo, col in (('índice base', b.c_base), ('índice redet.', b.c_red), ('coef.', b.c_coef), ('precio', b.c_precio)):
                    k = {'índice base': 'base', 'índice redet.': 'red', 'coef.': 'coef', 'precio': 'precio'}[campo]
                    va, vn = num(fa[k]), num(f[k])
                    if va is None and vn is None:
                        continue
                    if va is None or vn is None or abs(va - vn) > max(1e-6, 1e-9 * abs(va)):
                        cambios.append({'hoja': n, 'bloque': b.etiqueta, 'fila': f['r'], 'campo': campo + f' ({L(col)})',
                                        'no': f['no'], 'antes': va, 'ahora': vn})
    # AF
    af_ant = {r['n']: r for r in ant['af_filas']}
    for r in act['af_filas']:
        ra = af_ant.get(r['n'])
        if ra is None:
            continue
        for campo in ('V1', 'V0', 'pct'):
            va, vn = ra[campo], r[campo]
            if isinstance(va, float) and isinstance(vn, float) and abs(va - vn) > 1e-9 * max(1, abs(va)):
                cambios.append({'hoja': 'AF', 'bloque': f"R{r['n']}", 'fila': '', 'campo': campo, 'no': '', 'antes': va, 'ahora': vn})
    bloques_act = {(n, b.m_base, b.m_red) for n, bl in act['hojas'].items() for b in bl}
    faltan = [f"{n} {mes_txt(k[1])}→{mes_txt(k[2])}" for k, _ in bloques_ant.items()
              for n in [k[0]] if k not in bloques_act]
    return cambios, faltan, desalineadas



def _ubicacion(h):
    if h['col'] and h['fila'] != '':
        return f"{h['hoja']}!{h['col']}{h['fila']}"
    return f"{h['hoja']} ({h['bloque']})" if h['bloque'] else h['hoja']


def descripcion_hallazgo(h):
    """Una línea que dice DÓNDE está y QUÉ está mal."""
    dec = 1 if 'Índice' in h['tipo'] else 2
    partes = [f"[{h['bloque']}]" if h['bloque'] else '', _ubicacion(h)]
    if h['no']:
        partes.append(f"{h['no']} {h['insumo']}".strip())
    cab = '  '.join(p for p in partes if p)
    txt = f"{cab} — {h['tipo']}"
    vh, ve = h['valor_hoja'], h['valor_esperado']
    if isinstance(vh, float) and isinstance(ve, float):
        pct = f" ({(vh / ve - 1) * 100:+.2f} %)".replace('.', ',') if ve else ''
        d = 6 if abs(ve) < 1 else dec
        txt += f": la hoja dice {fmt_es(vh, d)}, debería ser {fmt_es(ve, d)}{pct}"
    if h['detalle'] and not (isinstance(vh, float) and isinstance(ve, float) and 'Índice' in h['tipo']):
        txt += f". {h['detalle']}"
    elif h['detalle']:
        txt += f" ({h['detalle']})"
    if h['causa']:
        txt += f" [{h['causa']}]"
    return txt




def agregar_formulas(res, ctx, fm):
    """Lee las fórmulas. (1) De dónde sale cada índice mal cargado. (2) Coeficiente y precio cuya fórmula se aparta de la
    de las filas vecinas: se informa SOLO si además el valor da mal (ERROR); si el valor es correcto no se informa. Las columnas de
    ÍNDICE no se revisan por fórmula: cada fila puede buscar el índice en otra celda, lo que importa es que el valor sea
    el del INDEC (y eso ya lo controla el análisis)."""
    con_valor_mal = {(h['hoja'], h['fila'], h['col']) for h in res['hallazgos'] if h['tipo'] in ('Precio del bloque', 'Coeficiente')}
    for b in [b for bl in res['hojas'].values() for b in bl if b.seleccionado]:
        filas = [f['r'] for f in b.filas]
        info = {f['r']: f for f in b.filas}
        for c, nombre in ((b.c_coef, 'coeficiente'), (b.c_precio, 'precio actualizado')):
            for a in fm.apartadas(b.hoja, c, filas):
                f = info[a['fila']]
                base = dict(hoja=b.hoja, bloque=b.etiqueta, fila=a['fila'], col=L(c), no=f['no'], insumo=f.get('nombre', ''), m_base=b.m_base, m_red=b.m_red)
                if a['tipo'] == 'formula':
                    mal = (b.hoja, a['fila'], L(c)) in con_valor_mal
                    if not mal:
                        continue    # fórmula distinta pero el valor da bien (ej. la empresa lo armó de otra forma): no se informa
                    res['hallazgos'].append(_hallazgo(
                        tipo='Fórmula distinta a la de las filas vecinas' if mal else 'Fórmula distinta con resultado correcto', nivel='ERROR' if mal else 'AVISO',
                        formula_actual=a['actual'], formula_esperada=a['esperado'], formula_firma=a.get('firma'),
                        detalle=f"La fórmula del {nombre} es {a['actual']}; en las demás filas de la columna es {a['esperado']}." + ('' if mal else ' El valor que da es correcto.'), **base))
                else:
                    res['hallazgos'].append(_hallazgo(tipo='Valor tipeado donde las demás filas tienen fórmula', nivel='AVISO', formula_esperada=a['esperado'],
                                                      valor_hoja=a['actual'] if isinstance(a['actual'], (int, float)) else None,
                                                      detalle=f"El {nombre} está escrito a mano ({a['actual']}); las demás filas usan la fórmula {a['esperado']}.", **base))
    _formulas_con_a0_ajeno(res, fm)
    for h in res['hallazgos']:
        if h['tipo'] in ('Índice base', 'Índice de la redet.') and h['fila'] != '' and h['col']:
            o = fm.origen(h['hoja'], h['fila'], CI(h['col']), ctx.wb)
            if o:
                h['origen'] = o


_REF_ABS = re.compile(r'\$?([A-Z]{1,3})\$?(\d+)')


def _formulas_con_a0_ajeno(res, fm):
    """El precio de un bloque se calcula con el A0 y V0 de SU redeterminación (celdas escritas encima de su columna de
    precio). Si la fórmula de una fila apunta al A0/V0 de OTRO bloque (típico al copiar una fórmula de la redeterminación
    anterior: $CK$5 en lugar de $DC$5), el precio sale con el anticipo de otra redeterminación. Se marca cada fila."""
    for hoja, bloques in res['hojas'].items():
        por_col = {b.c_precio: b for b in bloques if b.a0_fila}
        for b in [b for b in bloques if b.seleccionado and b.a0_fila]:
            for f in b.filas:
                formula = fm.formula(hoja, f['r'], b.c_precio)
                if not formula:
                    continue
                ajenas = {}
                for m in _REF_ABS.finditer(formula):
                    col, fila = CI(m.group(1)), int(m.group(2))
                    otro = por_col.get(col)
                    if otro is not None and otro is not b and fila in {otro.a0_fila, otro.v0_fila or otro.a0_fila + 1}:
                        ajenas[m.group(0)] = otro
                if not ajenas:
                    continue
                otro = next(iter(ajenas.values()))
                esperada = formula
                for ref in ajenas:
                    fila = int(_REF_ABS.match(ref).group(2))
                    esperada = esperada.replace(ref, f"${L(b.c_precio)}${fila}")
                res['hallazgos'].append(_hallazgo(
                    hoja=hoja, bloque=b.etiqueta, fila=f['r'], col=L(b.c_precio), no=f['no'], insumo=f.get('nombre', ''), m_base=b.m_base, m_red=b.m_red,
                    tipo='Fórmula usa el A0/V0 de otra redeterminación', nivel='ERROR', formula_actual=formula, formula_esperada=esperada, n_otra=otro.n_redet,
                    detalle=f"La fórmula del precio usa {', '.join(sorted(ajenas))} (A0/V0 de la redeterminación {otro.n_redet}); el bloque {b.etiqueta} debería usar "
                            f"${L(b.c_precio)}${b.a0_fila} y ${L(b.c_precio)}${b.v0_fila or b.a0_fila + 1} (su propio A0 y V0)."))

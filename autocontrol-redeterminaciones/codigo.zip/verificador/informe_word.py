# -*- coding: utf-8 -*-
"""
informe_word.py
----------------
Informe en Word para presentar a la empresa: resumen, observaciones numeradas (agrupadas por causa, con gravedad,
lugar exacto, valor actual y correcto, fuente, impacto estimado y corrección solicitada), diferencias menores, avisos,
alcance de la verificación y planilla de correcciones.

Requiere la librería 'python-docx' (la instala setup.ps1).
"""
import datetime as dt
import os
import re

from .comunes import ErrorVerificacion, fmt_es, mes_txt
from .observaciones import GRAVEDADES, NOMBRE_CONTROL, cobertura, contar, impacto_total, nombre_boletin

AZUL = '1F4E78'
COLOR_GRAV = {'ERROR': 'C00000', 'MENOR': 'BF8F00', 'AVISO': '2E75B6'}
FONDO_GRAV = {'ERROR': 'FDE9E7', 'MENOR': 'FFF4D6', 'AVISO': 'E8F1FA'}
ANCHO_UTIL_CM = 17.0                     # A4 con márgenes de 2 cm
MAX_LUGARES = 6
MAX_FILAS_ANEXO = 150


# ----------------------------------------------------------------------
# Datos de portada (leídos del propio Excel si es posible)
# ----------------------------------------------------------------------
_RE_ORGANISMO = re.compile(r'instituto|ministerio|municipalidad|municipio|gobierno|secretar[ií]a|direcci[oó]n (general|provincial|nacional)|agencia|comuna|ente |consejo|vialidad|obras sanitarias|cooperativa|universidad', re.I)
_RE_EXCLUIR_ORG = re.compile(r'tabla|c[aá]lculo|variaci[oó]n|redetermin|an[aá]lisis|planilla|precio|licitaci|^obra', re.I)
_RE_EMPRESA = re.compile(r'\b(s\.?\s?a\.?|s\.?\s?r\.?\s?l\.?|s\.?a\.?s\.?|u\.?t\.?e\.?)\s*$|construcciones|constructora|ingenier[ií]a|contratista', re.I)


def datos_obra(ctx):
    """{'organismo','obra','licitacion','contratista'} detectados en las primeras filas de las primeras hojas (se pueden corregir)."""
    d = {'organismo': '', 'obra': '', 'licitacion': '', 'contratista': ''}
    hojas = [n for n in ctx.wb.sheetnames if n not in ctx.ocultas][:14]
    limpio = lambda v: re.sub(r'\s+', ' ', str(v).replace('\xa0', ' ')).strip()
    for n in hojas:
        try:
            ws = ctx.wb[n]
            celdas = {}                                       # (fila, col) -> texto, primeras filas y hasta 150 columnas
            for r in range(1, min(ws.max_row, 25) + 1):
                for c in range(1, min(ws.max_column, 150) + 1):
                    v = ws.cell(row=r, column=c).value
                    if isinstance(v, str) and v.strip():
                        celdas[(r, c)] = limpio(v)
            for (r, c), t in sorted(celdas.items()):
                tl = t.lower()
                if not d['obra'] and re.match(r'^obra\b', tl):      # 'OBRA: ...' (no 'Obrador, cerco...')
                    resto = re.sub(r'^obra\s*:?\s*', '', t, flags=re.I).strip(' “”"\'')
                    if not resto:                             # 'OBRA:' con el nombre en la celda de al lado
                        resto = next((celdas[(r, cc)] for cc in range(c + 1, c + 8) if (r, cc) in celdas), '').strip(' “”"\'')
                    if len(resto) >= 12 and len(resto.split()[0]) >= 3:          # no 'OBRA BASE' (encabezado de columna)
                        d['obra'] = resto
                elif not d['licitacion'] and tl.startswith('licitaci'):
                    d['licitacion'] = t
                elif not d.get('expediente') and re.match(r'^(expediente|expte)\b', tl):
                    # 'EXPEDIENTE: 62954 / 2024.' -> '62954 / 2024' (o lo que esté en la celda de al lado)
                    v = re.sub(r'^(expediente|expte)\.?\s*(n[°º.o]*)?\s*:?\s*', '', t, flags=re.I).strip(' .')
                    if not re.search(r'\d', v):
                        v = next((celdas[(r, cc)] for cc in range(c + 1, c + 6) if (r, cc) in celdas), '').strip(' .')
                    if re.search(r'\d', v):
                        d['expediente'] = v
                elif not d['contratista'] and re.match(r'^(proponente|contratista|empresa)\s*:?$', tl):
                    sig = next((celdas[(r, cc)] for cc in range(c + 1, c + 8) if (r, cc) in celdas), '')
                    d['contratista'] = sig
                elif not d['contratista'] and re.match(r'^(proponente|contratista|empresa)\s*:\s*\S', tl):
                    d['contratista'] = re.sub(r'^[^:]+:\s*', '', t)
                elif not d['organismo'] and _RE_ORGANISMO.search(t) and not _RE_EXCLUIR_ORG.search(t) and len(t) < 110:
                    d['organismo'] = t
                    # la empresa suele estar en la misma columna, en las filas de arriba o abajo del organismo
                    if not d['contratista']:
                        for rr in (r - 1, r - 2, r + 1):
                            u = celdas.get((rr, c), '')
                            if u and _RE_EMPRESA.search(u) and not _RE_ORGANISMO.search(u):
                                d['contratista'] = u
                                break
        except Exception:
            continue
        if all(d.values()) and d.get('expediente'):
            break
    return d


# ----------------------------------------------------------------------
# Utilidades de python-docx
# ----------------------------------------------------------------------
def _docx():
    try:
        import docx
        return docx
    except ImportError:
        raise ErrorVerificacion("Falta la librería 'python-docx' para armar el informe Word (la instala setup.ps1). "
                                "Ejecutá de nuevo el .bat para que la agregue.")


def _shade(cell, hex_):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tcPr = cell._tc.get_or_add_tcPr()
    for old in tcPr.findall(qn('w:shd')):
        tcPr.remove(old)
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_)
    tcPr.append(shd)


_ORDEN_TBLPR = ['tblStyle', 'tblpPr', 'tblOverlap', 'bidiVisual', 'tblStyleRowBandSize', 'tblStyleColBandSize', 'tblW', 'jc',
                'tblCellSpacing', 'tblInd', 'tblBorders', 'shd', 'tblLayout', 'tblCellMar', 'tblLook', 'tblCaption', 'tblDescription']


def _en_tblpr(tblPr, elemento, nombre):
    """Inserta el elemento en la posición que exige el esquema de Word (el orden de los hijos de tblPr importa)."""
    from docx.oxml.ns import qn
    for old in tblPr.findall(qn(f'w:{nombre}')):
        tblPr.remove(old)
    despues = _ORDEN_TBLPR[_ORDEN_TBLPR.index(nombre) + 1:]
    for hijo in tblPr:
        if hijo.tag.split('}')[1] in despues:
            hijo.addprevious(elemento)
            return
    tblPr.append(elemento)


def _bordes(table, color='BFBFBF', sz=4):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tblPr = table._tbl.tblPr
    b = OxmlElement('w:tblBorders')
    for lado in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        e = OxmlElement(f'w:{lado}')
        e.set(qn('w:val'), 'single')
        e.set(qn('w:sz'), str(sz))
        e.set(qn('w:space'), '0')
        e.set(qn('w:color'), color)
        b.append(e)
    _en_tblpr(tblPr, b, 'tblBorders')


def _anchos(table, cms):
    """Ancho fijo por columna (tabla y cada celda), para que se vea igual en Word, LibreOffice y Google Docs."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm
    table.autofit = False
    tblPr = table._tbl.tblPr
    lay = OxmlElement('w:tblLayout')
    lay.set(qn('w:type'), 'fixed')
    _en_tblpr(tblPr, lay, 'tblLayout')
    for row in table.rows:
        for i, w in enumerate(cms):
            if i < len(row.cells):
                row.cells[i].width = Cm(w)
    for i, w in enumerate(cms):
        table.columns[i].width = Cm(w)


def _celda(cell, texto, negrita=False, tam=9, color=None, alinear=None, cursiva=False):
    from docx.shared import Pt, RGBColor
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = 0
    p.paragraph_format.space_before = 0
    if alinear == 'der':
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = p.add_run(str(texto) if texto is not None else '')
    r.bold, r.italic = negrita, cursiva
    r.font.size = Pt(tam)
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    return p


def _parrafos(cell, lineas, tam=9):
    """Varias líneas en una celda (un párrafo por línea)."""
    from docx.shared import Pt
    cell.text = ''
    for i, ln in enumerate(lineas):
        p = cell.paragraphs[0] if i == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(1)
        p.paragraph_format.space_before = 0
        r = p.add_run(ln)
        r.font.size = Pt(tam)


def _titulo(doc, texto, nivel=1):
    from docx.shared import Pt, RGBColor
    h = doc.add_heading(texto, level=nivel)
    for r in h.runs:
        r.font.name = 'Calibri'
        r.font.color.rgb = RGBColor.from_string(AZUL)
        r.font.size = Pt(14 if nivel == 1 else 11.5)
    h.paragraph_format.space_before = Pt(14 if nivel == 1 else 8)
    h.paragraph_format.space_after = Pt(4)
    h.paragraph_format.keep_with_next = True
    return h


def _texto(doc, texto, tam=10, negrita=False, cursiva=False, color=None, despues=4):
    from docx.shared import Pt, RGBColor
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(despues)
    r = p.add_run(texto)
    r.font.size, r.bold, r.italic = Pt(tam), negrita, cursiva
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    return p


def _numero_pagina(doc):
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt
    p = doc.sections[0].footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run('Página ')
    r.font.size = Pt(8)
    for tipo in ('PAGE',):
        run = p.add_run()
        run.font.size = Pt(8)
        f1 = OxmlElement('w:fldChar'); f1.set(qn('w:fldCharType'), 'begin')
        it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = tipo
        f2 = OxmlElement('w:fldChar'); f2.set(qn('w:fldCharType'), 'end')
        run._r.append(f1); run._r.append(it); run._r.append(f2)


# ----------------------------------------------------------------------
# Formato de valores
# ----------------------------------------------------------------------
def _fv(x, dec=None):
    if x is None:
        return '—'
    if isinstance(x, str):
        return x
    if isinstance(x, (int, float)):
        if dec is None:
            dec = 1 if abs(x) >= 1000 and round(x, 1) == x else 2
        return fmt_es(x, dec)
    return str(x)


def _impacto_txt(o):
    if o.impacto_directo is None:
        return None
    d = o.impacto_directo
    sentido = 'sobreestima' if d > 0 else 'subestima'
    t = f"$ {fmt_es(abs(d))} en costo directo"
    if o.impacto_total is not None:
        t += f" (≈ $ {fmt_es(abs(o.impacto_total))} con gastos, beneficio e impuestos)"
    return f"{t}; la planilla {sentido} el importe. Estimación."


def _valores_por_mes(o):
    """['OCT-2025: 10.640,3 → 10.630,5', ...] de una observación de índice / VAR."""
    return [f"{mes_txt(m)}: {_fv(o.meses[m][0], 1)} → {_fv(o.meses[m][1], 1)}" for m in sorted(o.meses)] or ['—']


def _del_control(o, v):
    """¿La observación pertenece a esta fila de la tabla de controles? (Ítems INDEC tiene una fila por mes.)"""
    if v.clave not in o.controles:
        return False
    if v.clave == 'items' and o.meses and isinstance(v.datos, dict) and 'ym' in v.datos:
        return v.datos['ym'] in o.meses
    return True


def _lugares(o, max_n=MAX_LUGARES):
    out = []
    dec = 1 if o.tipo in ('indice', 'var') else 2
    for u in o.ubicaciones[:max_n]:
        rol = {'origen': ' [origen]' if o.tipo == 'indice' else ' [corregir acá]', 'propagacion': ''}.get(u.rol, '')
        if u.actual is not None or u.correcto is not None:
            out.append(f"{u.texto()}{rol}: {_fv(u.actual, dec)} → {_fv(u.correcto, dec)}" + (f"  ({u.nota[:44]})" if u.nota and o.tipo in ('precio', 'cadena', 'coef', 'a0_otra') else ''))
        else:
            out.append(f"{u.texto()}{rol}" + (f" ({u.nota})" if u.nota else ''))
    if len(o.ubicaciones) > max_n:
        out.append(f"… y {len(o.ubicaciones) - max_n} lugar(es) más (ver la planilla de correcciones).")
    return out


# ----------------------------------------------------------------------
# El informe
# ----------------------------------------------------------------------
def escribir_informe(out_path, obs, resultados, veredictos, sesion, datos, version_programa=''):
    """obs: lista de observaciones. datos: {'organismo','obra','licitacion','contratista','elabora','cargo'} (puede estar vacío)."""
    docx = _docx()
    from docx.enum.section import WD_ORIENT
    from docx.shared import Cm, Pt
    doc = docx.Document()
    sec = doc.sections[0]
    sec.orientation = WD_ORIENT.PORTRAIT
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.0)
    sec.top_margin, sec.bottom_margin = Cm(2.0), Cm(2.0)
    for z in doc.settings.element.findall('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}zoom'):
        z.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}percent', '100')
    st = doc.styles['Normal']
    st.font.name = 'Calibri'
    st.font.size = Pt(10)
    _numero_pagina(doc)

    n = contar(obs)
    d_dir, d_tot = impacto_total(obs)
    errores = [o for o in obs if o.gravedad == 'ERROR']
    menores = [o for o in obs if o.gravedad == 'MENOR']
    avisos = [o for o in obs if o.gravedad == 'AVISO']

    # ---- encabezado
    _texto(doc, (datos.get('organismo') or '').upper(), tam=9, color='595959', despues=2)
    _texto(doc, 'INFORME DE VERIFICACIÓN DE REDETERMINACIÓN DE PRECIOS', tam=17, negrita=True, color=AZUL, despues=2)
    if datos.get('obra'):
        _texto(doc, datos['obra'], tam=11, despues=8)
    filas = [('Licitación / expediente', datos.get('licitacion')), ('Contratista', datos.get('contratista')),
             ('Documento analizado', os.path.basename(sesion['excel'])),
             ('Boletines INDEC utilizados', '; '.join(f"{nombre_boletin(b)} ({m})" if m else nombre_boletin(b) for b, m in sesion['pdfs']) or 'ninguno'),
             ('Fecha del informe', dt.date.today().strftime('%d/%m/%Y'))]
    filas = [(k, v) for k, v in filas if v]
    tb = doc.add_table(rows=len(filas), cols=2)
    _bordes(tb)
    for i, (k, v) in enumerate(filas):
        _celda(tb.rows[i].cells[0], k, negrita=True, tam=9)
        _shade(tb.rows[i].cells[0], 'F2F2F2')
        _celda(tb.rows[i].cells[1], v, tam=9)
    _anchos(tb, [4.6, ANCHO_UTIL_CM - 4.6])

    # ---- 1. resultado
    _titulo(doc, '1. Resultado de la verificación')
    if not errores and not menores:
        concl = ("La verificación no arrojó observaciones que requieran corrección." if not avisos else
                 "La verificación no arrojó errores; se detallan avisos para conocimiento.")
    else:
        concl = (f"La verificación arrojó {n['ERROR']} observación(es) que requieren corrección"
                 + (f", {n['MENOR']} diferencia(s) menor(es) a criterio del organismo" if n['MENOR'] else '')
                 + (f" y {n['AVISO']} aviso(s)" if n['AVISO'] else '') + '. Las observaciones agrupan por causa los lugares afectados: '
                 "una misma causa puede alcanzar a muchas celdas u hojas.")
    _texto(doc, concl)
    if d_dir:
        _texto(doc, f"Impacto estimado de las observaciones cuantificables: $ {fmt_es(abs(d_dir))} en costo directo"
                    + (f" (≈ $ {fmt_es(abs(d_tot))} con gastos, beneficio e impuestos)" if d_tot else '')
                    + " (suma de las diferencias de importe, en valor absoluto). Es una estimación para priorizar; no reemplaza la recomposición de la planilla.", cursiva=True, tam=9.5)

    tb = doc.add_table(rows=1 + len(veredictos), cols=5)
    _bordes(tb)
    for j, h in enumerate(['Control', 'Resultado', 'Errores', 'Menores', 'Avisos']):
        _celda(tb.rows[0].cells[0 + j], h, negrita=True, tam=9, color='FFFFFF')
        _shade(tb.rows[0].cells[j], AZUL)
    for i, v in enumerate(veredictos, start=1):
        por = {g: sum(1 for o in obs if o.gravedad == g and _del_control(o, v)) for g in GRAVEDADES}
        estado = {'OK': 'Sin observaciones', 'REVISAR': 'Con observaciones', 'AVISO': 'Con avisos', 'OMITIDO': 'No ejecutado', 'ERROR': 'No se pudo completar'}[v.estado]
        if v.estado not in ('OMITIDO', 'ERROR'):
            estado = ('Con observaciones' if por['ERROR'] else 'Solo diferencias menores' if por['MENOR'] else 'Con avisos' if por['AVISO'] else 'Sin observaciones')
        _celda(tb.rows[i].cells[0], v.titulo, tam=9)
        _celda(tb.rows[i].cells[1], estado, tam=9)
        for j, g in enumerate(GRAVEDADES, start=2):
            _celda(tb.rows[i].cells[j], por[g] if v.estado not in ('OMITIDO', 'ERROR') else '—', tam=9, alinear='der')
        if v.estado in ('OMITIDO', 'ERROR'):
            _shade(tb.rows[i].cells[1], 'EDEDED')
        elif por['ERROR']:
            _shade(tb.rows[i].cells[1], FONDO_GRAV['ERROR'])
        elif por['MENOR'] or por['AVISO']:
            _shade(tb.rows[i].cells[1], FONDO_GRAV['MENOR'])
        else:
            _shade(tb.rows[i].cells[1], 'E2F0D9')
    _anchos(tb, [6.0, 4.6, 2.1, 2.1, 2.2])

    # ---- 2. observaciones
    if errores:
        _titulo(doc, '2. Observaciones que requieren corrección')
        for o in errores:
            _bloque_obs(doc, o)

    # ---- 3. menores
    if menores:
        _titulo(doc, f"{'3' if errores else '2'}. Diferencias menores (a criterio del organismo)")
        _texto(doc, "Diferencias inferiores al 0,15 % o que coinciden con una versión revisada del dato publicada por el INDEC "
                    "(los últimos meses del ICC son provisorios y se revisan). No se consideran errores; se informan para su evaluación.", tam=9.5)
        tb = doc.add_table(rows=1 + len(menores), cols=5)
        _bordes(tb)
        for j, h in enumerate(['N°', 'Concepto', 'En la planilla → publicado', 'Impacto est. $', 'Lugares']):
            _celda(tb.rows[0].cells[j], h, negrita=True, tam=8.5, color='FFFFFF')
            _shade(tb.rows[0].cells[j], AZUL)
        for i, o in enumerate(menores, start=1):
            _celda(tb.rows[i].cells[0], o.id, negrita=True, tam=8.5)
            _celda(tb.rows[i].cells[1], o.titulo, tam=8.5)
            _parrafos(tb.rows[i].cells[2], _valores_por_mes(o), tam=8)
            _celda(tb.rows[i].cells[3], (fmt_es(abs(o.impacto_directo)) if o.impacto_directo else '—'), tam=8.5, alinear='der')
            _celda(tb.rows[i].cells[4], o.n, tam=8.5, alinear='der')
        _anchos(tb, [1.4, 6.6, 4.6, 2.6, 1.8])

    # ---- 4. avisos
    if avisos:
        k = 2 + bool(errores) + bool(menores)
        _titulo(doc, f"{k}. Avisos")
        for o in avisos:
            ubic = ', '.join(u.texto() for u in o.ubicaciones[:3]) + (f" y {o.n - 3} más" if o.n > 3 else '')
            _texto(doc, f"{o.id} · {o.titulo}" + (f" ({o.n} lugar(es))" if o.n else ''), tam=9.5, negrita=True, despues=0)
            if o.descripcion:
                _texto(doc, o.descripcion, tam=9, despues=0)
            _texto(doc, f"Lugares: {ubic}" if o.n else '', tam=8.5, color='595959', despues=5)

    # ---- alcance
    k = 2 + bool(errores) + bool(menores) + bool(avisos)
    _titulo(doc, f"{k}. Alcance de la verificación")
    _texto(doc, 'Qué se verificó:', negrita=True, tam=9.5, despues=1)
    for ln in cobertura(resultados):
        _viñeta(doc, ln)
    _texto(doc, 'Criterios:', negrita=True, tam=9.5, despues=1)
    for ln in ("Cada mes se compara únicamente con el boletín del INDEC de ese mes (octubre con el boletín de noviembre, enero con el de febrero, etc.).",
               "Tolerancia en índices: 0,05 puntos (el INDEC publica con un decimal). Tolerancia en precios: un centavo.",
               "Error: hay que corregirlo. Diferencia menor: inferior al 0,15 % o igual a una versión revisada del dato; a criterio del organismo. Aviso: no es un error, conviene revisarlo.",
               "El impacto estimado suma la diferencia de importe de las filas afectadas y se lleva al total con el factor de gastos, beneficio e impuestos de la planilla. Es aproximado."):
        _viñeta(doc, ln)
    _texto(doc, 'Limitaciones:', negrita=True, tam=9.5, despues=1)
    for ln in ("No se verifican los precios base ni las cantidades de la oferta, ni que cada insumo esté asignado al código del INDEC que le corresponde.",
               "Los índices se controlan por su VALOR (contra el INDEC), no por la fórmula que los trae: cada fila puede buscarlo donde quiera.",
               "Las fórmulas se leen para ubicar la causa de un valor incorrecto; una fórmula distinta cuyo valor es correcto se informa como aviso, no como error."):
        _viñeta(doc, ln)

    # ---- anexo
    filas_anexo = [(o, u) for o in errores for u in o.ubicaciones]
    if filas_anexo:
        doc.add_page_break()
        _titulo(doc, 'Anexo A. Planilla de correcciones (observaciones que requieren corrección)')
        _texto(doc, "Detalle por celda de las observaciones que requieren corrección."
                    + (" La lista completa, con todas las gravedades y una columna de estado, está en la hoja «Correcciones» del Excel de verificación." if sesion.get('excel_verificacion', True) else ''), tam=9)
        mostrar = filas_anexo[:MAX_FILAS_ANEXO]
        tb = doc.add_table(rows=1 + len(mostrar), cols=5)
        _bordes(tb)
        for j, h in enumerate(['Obs.', 'Hoja', 'Celda', 'Valor actual', 'Valor correcto']):
            _celda(tb.rows[0].cells[j], h, negrita=True, tam=8.5, color='FFFFFF')
            _shade(tb.rows[0].cells[j], AZUL)
        for i, (o, u) in enumerate(mostrar, start=1):
            dec = 1 if o.tipo in ('indice', 'var') else 2
            _celda(tb.rows[i].cells[0], o.id, tam=8)
            _celda(tb.rows[i].cells[1], u.hoja, tam=8)
            _celda(tb.rows[i].cells[2], u.celda, tam=8)
            _celda(tb.rows[i].cells[3], _fv(u.actual, dec), tam=8)
            _celda(tb.rows[i].cells[4], _fv(u.correcto, dec), tam=8)
        _anchos(tb, [1.4, 6.2, 1.8, 3.8, 3.8])
        if len(filas_anexo) > len(mostrar):
            _texto(doc, f"(se muestran {len(mostrar)} de {len(filas_anexo)} filas" + ("; el resto está en el Excel de verificación)" if sesion.get('excel_verificacion', True) else ")"), tam=8.5, cursiva=True)

    # ---- firma
    doc.add_paragraph()
    _texto(doc, 'Elaborado por:', tam=9.5, negrita=True, despues=14)
    _texto(doc, '______________________________', tam=10, despues=0)
    if datos.get('elabora'):
        _texto(doc, datos['elabora'], tam=10, despues=0)
    if datos.get('cargo'):
        _texto(doc, datos['cargo'], tam=9, color='595959', despues=0)
    if version_programa:
        _texto(doc, f"Generado con el Verificador unificado de redeterminaciones {version_programa}.", tam=7.5, color='808080')
    doc.save(out_path)


def _viñeta(doc, texto):
    from docx.shared import Pt
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(texto)
    r.font.size = Pt(9)


def _bloque_obs(doc, o):
    """Una observación: barra con número y título, y tabla con los datos."""
    from docx.shared import Pt
    filas = []
    filas.append(('Control', NOMBRE_CONTROL.get(o.control, o.control) + (' + ' + ', '.join(NOMBRE_CONTROL[c] for c in sorted(o.controles - {o.control})) if len(o.controles) > 1 else '')))
    filas.append(('Qué se encontró', o.descripcion))
    if o.causa:
        filas.append(('Causa', o.causa))
    filas.append(('Dónde', _lugares(o)))
    if o.meses:
        filas.append(('Valor actual → correcto', _valores_por_mes(o)))
    elif o.tipo != 'formula' and isinstance(o.actual, (int, float)):
        filas.append(('Valor actual → correcto', f"{_fv(o.actual, 2)}  →  {_fv(o.correcto, 2)}"))
    if o.fuente:
        filas.append(('Fuente', o.fuente))
    imp = _impacto_txt(o)
    if imp:
        filas.append(('Impacto estimado', imp))
    filas.append(('Corrección solicitada', o.accion))

    tb = doc.add_table(rows=1 + len(filas), cols=2)
    _bordes(tb)
    cab = tb.rows[0].cells[0].merge(tb.rows[0].cells[1])
    _celda(cab, f"{o.id}  ·  {o.titulo}", negrita=True, tam=10, color='FFFFFF')
    _shade(cab, COLOR_GRAV[o.gravedad])
    for i, (k, v) in enumerate(filas, start=1):
        _celda(tb.rows[i].cells[0], k, negrita=True, tam=8.5)
        _shade(tb.rows[i].cells[0], 'F2F2F2')
        if isinstance(v, list):
            _parrafos(tb.rows[i].cells[1], v, tam=8.5)
        else:
            _celda(tb.rows[i].cells[1], v, tam=9)
    _anchos(tb, [3.6, ANCHO_UTIL_CM - 3.6])
    # que el título no quede solo al final de una página
    for row in tb.rows[:2]:
        for c in row.cells:
            for p in c.paragraphs:
                p.paragraph_format.keep_with_next = True
    sp = doc.add_paragraph()
    sp.paragraph_format.space_after = Pt(4)

# -*- coding: utf-8 -*-
"""
motor.py
---------
El puente entre la interfaz web y el paquete `verificador`. No repite la lógica de detección ni de
análisis: llama a las mismas funciones que usa `verificar.py` por línea de comandos, pero sin
preguntar nada (usa los valores que el programa detecta solo) y separa "analizar" de "generar un
archivo", para que la web pueda mostrar el resultado y recién generar el Excel / Word / copia que el
usuario pida, cuando lo pida.

Los resultados de un análisis (objetos de Python, no todos serializables) se guardan en memoria
mientras el programa está abierto (CACHE). Si el programa se cerró y se volvió a abrir, generar un
reporte de una redeterminación vieja vuelve a correr el análisis con los mismos archivos guardados
(tarda lo mismo que la primera vez, pero da exactamente el mismo resultado).
"""
import collections
import contextlib
import io
import os
import sys
import threading
import time

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if RAIZ not in sys.path:
    sys.path.insert(0, RAIZ)

from verificador import cli as vc                    # noqa: E402
from verificador import observaciones as ob          # noqa: E402
from verificador import reporte as rp                # noqa: E402
from verificador import informe_word as iw           # noqa: E402
from verificador import copia_anotada as ca           # noqa: E402
from verificador.comunes import ErrorVerificacion, nombre_salida_unico, mes_txt   # noqa: E402
from verificador.contexto import Contexto            # noqa: E402
from verificador import analisis_items as ai          # noqa: E402
from verificador.pdf_indec import Boletin             # noqa: E402
from openpyxl.utils import column_index_from_string as CI   # noqa: E402

try:
    from interfaz.trabajos import redirigir as _redirigir     # salida por hilo (ver trabajos.py)
except ImportError:                                          # pragma: no cover
    _redirigir = contextlib.redirect_stdout

CACHE = {}     # id de redeterminación -> resultado de ejecutar() (se pierde si se cierra el programa)


# ----------------------------------------------------------------------
# Excel abierto UNA vez por archivo, compartido por las pantallas Y el análisis
# ----------------------------------------------------------------------
# El libro se abre en modo solo lectura (verificador/excel.py: ws.cell no crea celdas ni escribe nada),
# así que lo pueden usar a la vez la pantalla de "corregir a mano" y un análisis sin pisarse. Se
# identifica por el CONTENIDO del archivo (huella SHA-1), no por su ruta: el Excel que se sube en el
# paso 1 se copia después a la carpeta de la obra con otro nombre, y el análisis reusa el libro que ya
# se había abierto para el paso 2 en lugar de volver a leerlo (lo que más tarda). Quedan en memoria los
# últimos 3.
_LIBROS = collections.OrderedDict()   # huella -> libro
_CTX = collections.OrderedDict()      # huella -> (Contexto de las pantallas, Lock)
_CTX_LOCK = threading.RLock()
_INSPECCION = {}                      # huella -> dict de inspeccionar()
_MAX_LIBROS = 3


def _clave(excel_path):
    from verificador.cache_anterior import huella_archivo
    h = huella_archivo(excel_path)
    if h is None:
        raise ErrorVerificacion(f"No encuentro el archivo '{excel_path}'.")
    return h


def libro(excel_path):
    """El libro de ese Excel, abierto una sola vez (se reusa si ya está en memoria)."""
    from verificador.excel import abrir_libro
    clave = _clave(excel_path)
    with _CTX_LOCK:
        if clave in _LIBROS:
            _LIBROS.move_to_end(clave)
            print(f"  Excel abierto: {os.path.basename(excel_path)} (ya estaba en memoria, no se vuelve a leer).")
            return _LIBROS[clave]
    wb = abrir_libro(excel_path)          # fuera del lock: puede tardar
    with _CTX_LOCK:
        _LIBROS[clave] = wb
        while len(_LIBROS) > _MAX_LIBROS:
            viejo, _ = _LIBROS.popitem(last=False)
            _CTX.pop(viejo, None)
        return wb


def _contexto(excel_path):
    """(Contexto, Lock) para las pantallas (hojas, vista previa, sugerencias). No es el del análisis:
    el análisis arma el suyo (con los ajustes manuales), pero sobre el MISMO libro ya abierto."""
    clave = _clave(excel_path)
    with _CTX_LOCK:
        if clave in _CTX:
            return _CTX[clave]
    ctx = Contexto(excel_path, wb=libro(excel_path))
    with _CTX_LOCK:
        if clave not in _CTX:
            _CTX[clave] = (ctx, threading.Lock())
        return _CTX[clave]


def _bloques_con_avance(ctx):
    """Lo mismo que ctx.hojas_bloques, pero con una barra de progreso real (una hoja a la vez)."""
    from verificador.bloques import detectar_bloques
    from verificador.excel import hojas_de_datos
    from verificador.comunes import barra_progreso
    if ctx._hojas_bloques is not None:
        return ctx._hojas_bloques
    hojas = [n for n in hojas_de_datos(ctx.wb) if n not in ctx.excluir]
    res = {}
    for i, n in enumerate(hojas, start=1):
        barra_progreso(i - 1, len(hojas), f"  Buscando el análisis de precios: hoja '{n}'")
        try:
            bl = detectar_bloques(ctx.wb[n], n, ctx.tabla)
        except Exception as e:
            ctx.avisos.append(f"No pude leer la hoja '{n}': {type(e).__name__}: {e}")
            continue
        if bl:
            res[n] = bl
    if hojas:
        barra_progreso(len(hojas), len(hojas), "  Buscando el análisis de precios")
    ctx._hojas_bloques = res
    return res


def inspeccionar(excel_path, etapa=None):
    """Todo lo que necesitan las pantallas ANTES de analizar (hojas, meses, datos del informe,
    redeterminaciones detectadas), abriendo el Excel una sola vez. 'etapa(desde, hasta, texto)' es
    opcional (interfaz.trabajos.StreamEtapa.etapa) para la barra de progreso."""
    clave = _clave(excel_path)
    if clave in _INSPECCION:
        return _INSPECCION[clave]
    etapa = etapa or (lambda *a: None)
    etapa(3, 60, 'Abriendo el Excel…')
    ctx, lock = _contexto(excel_path)
    with lock:
        etapa(60, 85, 'Buscando el análisis de precios…')
        hojas_bloques = _bloques_con_avance(ctx)
        etapa(85, 90, 'Buscando análisis por ítem…')
        meses, ap_etq = set(), []
        for bl in hojas_bloques.values():
            for b in bl:
                meses.update(x for x in (b.m_base, b.m_red) if x)
                if b.etiqueta not in ap_etq:
                    ap_etq.append(b.etiqueta)
        try:
            por_item = ai.detectar(ctx)
        except Exception:
            por_item = {}
        for bl in por_item.values():
            for b in bl:
                meses.update(x for x in (b.m_base, b.m_red) if x)
                if not hojas_bloques and b.etiqueta not in ap_etq:
                    ap_etq.append(b.etiqueta)
        etapa(90, 95, 'Buscando la planilla de costos…')
        costos_etq = []
        try:
            from verificador import costos as cs
            pls, _ = cs.detectar_planillas(ctx)
            for pl in pls:
                for b in getattr(pl, 'bloques', []) or []:
                    if b.etiqueta not in costos_etq:
                        costos_etq.append(b.etiqueta)
        except Exception:
            pass
        etapa(95, 99, 'Leyendo los datos de la obra…')
        try:
            datos = iw.datos_obra(ctx)
        except Exception:
            datos = {'organismo': '', 'obra': '', 'licitacion': '', 'contratista': ''}
        def _orden(e):          # Base, R1, R2, … R10 (por número, no alfabético)
            import re as _re
            m = _re.fullmatch(r'R(\d+)', e or '')
            return (0, 0) if e == 'Base' else ((1, int(m.group(1))) if m else (2, 0))
        res = {'hojas': list(ctx.wb.sheetnames), 'meses': sorted(meses), 'datos_informe': datos,
               'etiquetas': {'ap': sorted(ap_etq, key=_orden), 'costos': sorted(costos_etq, key=_orden)},
               'ap_detectado': bool(hojas_bloques or por_item)}
    _INSPECCION[clave] = res
    return res


# ----------------------------------------------------------------------
# Atajos (todos leen de inspeccionar(): el Excel se abre una sola vez)
# ----------------------------------------------------------------------
def meses_necesarios(excel_path):
    """(año, mes) de los bloques de índices del análisis de precios de este Excel, sin PDF todavía."""
    try:
        return inspeccionar(excel_path)['meses']
    except ErrorVerificacion:
        return []


def datos_obra_seguro(excel_path):
    """Organismo/obra/licitación/contratista detectados en el Excel. Nunca lanza."""
    try:
        return inspeccionar(excel_path)['datos_informe']
    except Exception:
        return {'organismo': '', 'obra': '', 'licitacion': '', 'contratista': ''}


def leer_meses_boletin(ruta_pdf, progreso=True):
    """Meses (año, mes) que cubre el Anexo de un PDF del INDEC. Se usa al subirlo a la biblioteca: de paso
    queda GUARDADO el Anexo ya detectado (ver pdf_indec.guardar_anexo), así el análisis no lo vuelve a buscar."""
    b = Boletin(ruta_pdf, progreso=progreso)
    return [list(m) for m in b.meses]


def anexo_listo(ruta_pdf):
    """¿Este boletín ya tiene su Anexo detectado y guardado?"""
    from verificador.pdf_indec import anexo_guardado
    return os.path.exists(ruta_pdf) and anexo_guardado(ruta_pdf) is not None


def huella_pdf(ruta_pdf):
    from verificador.pdf_indec import huella_pdf as _h
    return _h(ruta_pdf)


def nombres_hojas(excel_path):
    return inspeccionar(excel_path)['hojas']


def etiquetas_redeterminaciones(excel_path):
    """Etiquetas REALES de los bloques de redeterminación detectados (ej. ['R1','R2']) para el
    análisis de precios y la planilla de costos."""
    try:
        return inspeccionar(excel_path)['etiquetas']
    except ErrorVerificacion:
        return {'ap': [], 'costos': []}


def vista_previa_hoja(excel_path, hoja):
    """[(letra, [muestras])] de las columnas con datos de esa hoja (primeras 40 filas: algunas
    plantillas tienen el encabezado en la fila 20 o más abajo)."""
    from verificador.bloques import vista_previa_columnas
    ctx, lock = _contexto(excel_path)
    if hoja not in ctx.wb.sheetnames:
        raise ErrorVerificacion(f"El Excel no tiene una hoja llamada '{hoja}'.")
    with lock:
        return vista_previa_columnas(ctx.wb[hoja], filas=40)


def sugerir_grupos(excel_path, hoja):
    """Grupos de columnas (índice base, índice de la redeterminación, coeficiente, precio) que PARECEN
    un bloque del análisis de precios, reconocidos por los NÚMEROS y no por los títulos: tres columnas
    seguidas donde, fila por fila, la tercera es la segunda dividida la primera (coef = redet / base).
    Sirve justo cuando la detección automática no encontró nada porque los títulos no son los de
    siempre. Devuelve [{'base','red','coef','precio','filas','titulo'}], de izquierda a derecha."""
    from openpyxl.utils import get_column_letter as L
    from verificador.comunes import num, texto
    from verificador.excel import leer_rango
    ctx, lock = _contexto(excel_path)
    if hoja not in ctx.wb.sheetnames:
        return []
    with lock:
        ws = ctx.wb[hoja]
        maxc = min(max(ws.max_column or 1, 1), 400)
        filas = leer_rango(ws, maxc, 3000)
    ancho = max((len(f) for f in filas), default=0)
    grupos = []
    c = 0
    while c + 2 < ancho:
        coinciden, primera = 0, None
        for i, f in enumerate(filas):
            if c + 2 >= len(f):
                continue
            b, r, k = num(f[c]), num(f[c + 1]), num(f[c + 2])
            if b and r and k and b > 0 and abs(k - r / b) <= max(0.0006 * abs(k), 0.00015):
                coinciden += 1
                primera = i if primera is None else primera
        if coinciden >= 3:
            # precio: la columna de la derecha del coeficiente con números en esas filas
            precio = c + 3
            titulo = ''
            for i in range(max(0, primera - 8), primera):
                for cc in (c, c + 1, c + 2, c + 3):
                    v = filas[i][cc] if cc < len(filas[i]) else None
                    t = texto(v) if isinstance(v, str) else ''
                    if t and len(t) < 40 and num(t) is None and not t.lower().startswith('d=') and t not in titulo:
                        titulo = (titulo + ' / ' + t) if titulo else t
            grupos.append({'base': L(c + 1), 'red': L(c + 2), 'coef': L(c + 3), 'precio': L(precio + 1),
                           'filas': coinciden, 'titulo': titulo[:80]})
            c += 3
        else:
            c += 1
    return grupos


def probar_columnas(excel_path, hoja, col_base, col_red, col_coef, col_precio, col_id=None):
    """Arma el bloque manual SIN analizar nada, para avisar en el momento si esas columnas sirven
    (cuántos insumos encontró y unos ejemplos) o por qué no, en lugar de enterarse recién al final."""
    from verificador.bloques import construir_bloque_manual
    from openpyxl.utils import get_column_letter as L
    ctx, lock = _contexto(excel_path)
    col = lambda x: CI(x.strip().upper())
    cols = [col_base, col_red, col_coef, col_precio]
    if len(set(cols)) < 4:
        return {'ok': False, 'mensaje': 'Elegiste la misma columna para dos cosas distintas.'}
    with lock:
        try:
            b = construir_bloque_manual(ctx.wb[hoja], hoja, ctx.tabla, *[col(x) for x in cols],
                                        col(col_id) if col_id else None)
        except (ValueError, KeyError) as e:
            return {'ok': False, 'mensaje': str(e)}
    ejemplos = [f['no'] for f in b.filas[:4]]
    meses = ''
    if b.m_base or b.m_red:
        meses = f"{mes_txt(b.m_base) if b.m_base else '?'} → {mes_txt(b.m_red) if b.m_red else '?'}"
    return {'ok': True, 'filas': len(b.filas), 'ejemplos': ejemplos, 'meses': meses,
            'col_id': L(b.cn), 'etiqueta': f"R{b.n_redet}" if b.n_redet else ''}


# ----------------------------------------------------------------------
# Ejecutar el análisis completo (como --sin-preguntas), sin escribir archivos
# ----------------------------------------------------------------------
def ejecutar(excel_path, pdf_paths, prev_path=None, datos_informe=None, overrides=None, stream=None, reglas=None):
    """Corre los 4 controles con los valores que el programa detecta solo (igual que --sin-preguntas).
    'overrides': dict opcional para corregir a mano lo que la detección automática no encontró o
    encontró mal — hoja_indec, hoja_items, hoja_var, cols_ap, planilla, cols_costos (los mismos nombres
    que las opciones --hoja-indec, etc. de la línea de comandos). Además, 'hoja_ap_manual' + 'col_base' +
    'col_red' + 'col_coef' + 'col_precio' (+ 'col_id' opcional) fuerzan un bloque de análisis de precios
    con esas columnas exactas, para cuando la detección automática no encontró NINGUNA hoja con esa
    estructura (--hoja-indec/--cols-ap no ayudan en ese caso: no hay nada detectado sobre lo cual elegir).
    'stream': si se da (interfaz.trabajos.StreamEnVivo), el progreso se redirige ahí en vivo, para que
    la interfaz pueda mostrar una barra real mientras corre; si no, se guarda todo para el final.
    Devuelve un dict con todo lo necesario para mostrar el resultado y, más tarde, generar cualquiera
    de los 3 reportes."""
    overrides = overrides or {}
    argv = [excel_path]
    for p in pdf_paths:
        if isinstance(p, str):              # los boletines ya leídos (objetos) van directo a cargar()
            argv += ['--pdf', p]
    if prev_path:
        argv += ['--prev', prev_path]
    argv.append('--sin-preguntas')
    for clave in ('organismo', 'obra', 'licitacion', 'contratista', 'elabora', 'cargo'):
        v = (datos_informe or {}).get(clave)
        if v:
            argv += [f'--{clave}', v]
    for clave, bandera in (('hoja_indec', '--hoja-indec'), ('hoja_items', '--hoja-items'), ('hoja_var', '--hoja-var'),
                           ('cols_ap', '--cols-ap'), ('planilla', '--planilla'), ('cols_costos', '--cols-costos'),
                           ('ap_manual', '--ap-manual')):
        v = overrides.get(clave)
        if not v and clave in ('cols_ap', 'cols_costos'):
            v = 'ultima'          # por defecto se informa SOLO la última redeterminación (se elige "Todas" a mano)
        if v:
            argv += [bandera, v]
    args = vc.parse_args(argv)

    propio = stream is None
    if propio:
        stream = io.StringIO()
    t0 = time.time()
    with _redirigir(stream):
        c = vc.cargar(excel_path, pdf_paths, prev_path, args.hoja_indec, abrir=libro)
        if overrides.get('hoja_ap_manual') and overrides.get('col_base') and overrides.get('col_red') \
                and overrides.get('col_coef') and overrides.get('col_precio'):
            _forzar_bloque_manual(c, overrides)
        _aplicar_hojas_a_mano(c, overrides, args)
        if not c.ctx.hojas_bloques and not c.ap_items and not c.planillas and not c.boletines:
            raise ErrorVerificacion("No reconocí ninguna estructura conocida en este Excel (ni índices INDEC, ni análisis "
                                     "de precios, ni planilla de costos). ¿Es el archivo correcto?")
        p = vc.hacer_preguntas(args, c, interactivo=False)
        if not p.controles:
            raise ErrorVerificacion("Ninguno de los 4 controles se pudo ejecutar con este archivo: "
                                     + '; '.join(f"{k}: {v}" for k, v in c.motivos.items()))
        fm = vc.cargar_formulas(c, True)
        c.var_refs = (reglas or {}).get('var') or {}          # índices INDEC asignados a mano en la VAR
        veredictos, r = vc.analizar(c, p, os.path.basename(prev_path) if prev_path else None, fm)
        obs = ob.construir(r)
        sesion = {'excel_verificacion': True, 'excel': excel_path,
                  'pdfs': [(b.nombre, mes_txt(ym)) for b, ym in p.meses] or [(b.nombre, '') for b in c.boletines],
                  'prev': prev_path if c.prev_disponible() else None, 'parametros': p.resumen}
    segundos = time.time() - t0
    bitacora = stream.valor() if hasattr(stream, 'valor') else stream.getvalue()
    res = {'c': c, 'p': p, 'fm': fm, 'veredictos': veredictos, 'r': r, 'obs': obs, 'sesion': sesion,
            'datos_informe': p.datos_informe, 'segundos': segundos, 'bitacora': bitacora,
            'excel_path': excel_path, 'version': vc.__version__}
    aplicar_descartes(res, (reglas or {}).get('descartar') or {})
    return res


def _aplicar_hojas_a_mano(c, ov, args):
    """Las hojas elegidas a mano en la web (VAR, ítems, planilla de costos) para los controles que NO
    se detectaron solos. Por línea de comandos esto lo hace la pregunta interactiva de cli.py
    (completar_a_mano), que en modo sin preguntas no corre: sin esto, elegir la hoja VAR cuando no se
    había detectado ninguna no hacía NADA. Si la hoja elegida no sirve, el control queda sin ejecutar
    pero el motivo lo dice (en lugar de ignorar la elección en silencio)."""
    from verificador import analisis_items as _ai    # noqa: F401  (import para mantener el orden de carga)
    from verificador import costos as cs
    from verificador import items_indec as it
    wb = c.ctx.wb
    h = ov.get('hoja_var')
    if h and 'var' in c.motivos and h in wb.sheetnames:
        c.hojas_var = [h]
        c.motivos.pop('var')
        print(f"  VAR: hoja elegida a mano '{h}'.")
    h = ov.get('hoja_items')
    if h and 'items' in c.motivos and c.boletines and h in wb.sheetnames:
        prep = it.preparar(wb, hoja=h)
        if prep:
            c.items_manual = c.prep_items = prep
            c.motivos.pop('items')
            print(f"  Ítems INDEC: hoja elegida a mano '{h}'.")
        else:
            c.motivos['items'] = f"en la hoja elegida a mano ('{h}') no encontré códigos de índice del INDEC"
    h = ov.get('planilla')
    if h and h in wb.sheetnames:
        ya = [x for x in c.planillas if x.hoja.strip().lower() == h.strip().lower()]
        if not ya:
            try:
                c.planillas, c.hojas_analisis = cs.detectar_planillas(c.ctx, hoja=h)
                c.motivos.pop('costos', None)
                print(f"  Planilla de costos: hoja elegida a mano '{h}'.")
            except ErrorVerificacion as e:
                c.motivos['costos'] = f"la hoja elegida a mano ('{h}') no parece una planilla de costos: {e}"
                c.planillas = []
                args.planilla = None
    if 'ap' in c.motivos and ov.get('hoja_ap_manual') and getattr(c, 'error_ap_manual', None):
        c.motivos['ap'] = f"las columnas elegidas a mano no sirven: {c.error_ap_manual}"


def _forzar_bloque_manual(c, overrides):
    """Arma el bloque de análisis de precios con las columnas que el usuario indicó a mano (ver
    ejecutar()) y actualiza c.motivos / c.ap_items para que el resto del programa lo use."""
    try:
        col = lambda s: CI(s.strip().upper())
        c.ctx.agregar_bloque_manual(
            overrides['hoja_ap_manual'], col(overrides['col_base']), col(overrides['col_red']),
            col(overrides['col_coef']), col(overrides['col_precio']),
            col(overrides['col_id']) if overrides.get('col_id') else None)
        c.ap_items = {}                 # se fuerza el formato clásico (por columnas), no el de por-ítem
        c.motivos.pop('ap', None)
        print(f"  Análisis de precios: bloque agregado a mano en '{overrides['hoja_ap_manual']}'.")
    except (ValueError, KeyError, Exception) as e:
        c.error_ap_manual = str(e)
        print(f"  ⚠ No pude armar el bloque a mano: {e}")


def _clave_control(clave):
    return (clave or '').split('@')[0].split(':')[0]


def aplicar_descartes(res, descartar):
    """Saca de las observaciones las que el ADMINISTRADOR marcó como que no corresponden (con su motivo) y
    ajusta el resumen de cada control: si a un control no le queda nada pendiente, queda OK, aclarando que
    fue por decisión del administrador. Se puede volver a llamar cuando cambian las reglas (usa siempre la
    lista original completa)."""
    todas = res.setdefault('obs_todas', list(res['obs']))
    originales = res.setdefault('_veredictos_orig', [(v.estado, v.mensaje) for v in res['veredictos']])
    res['obs'] = [o for o in todas if o.firma not in descartar]
    res['obs_descartadas'] = [(o, descartar[o.firma]) for o in todas if o.firma in descartar]
    for v, (estado, mensaje) in zip(res['veredictos'], originales):
        v.estado, v.mensaje = estado, mensaje
        clave = _clave_control(v.clave)
        n_desc = sum(1 for o, _ in res['obs_descartadas'] if clave in {_clave_control(x) for x in o.controles})
        if not n_desc:
            continue
        quedan = [o for o in res['obs'] if clave in {_clave_control(x) for x in o.controles}]
        nota = f"{n_desc} observación(es) descartada(s) por el administrador"
        if not quedan and estado in ('REVISAR', 'AVISO', 'ERROR'):
            v.estado, v.mensaje = 'OK', f"OK: {nota} (ver su motivo en la redeterminación)"
        else:
            v.mensaje = f"{mensaje} · {nota}"
    return res


def precalcular_anterior(excel_path):
    """Deja calculado y guardado (verificador/cache_anterior.py) el análisis de este Excel COMO versión
    anterior, para que la próxima redeterminación que se compare contra él no tenga que abrirlo. Se
    llama en segundo plano al marcar una redeterminación como aprobada. Nunca lanza."""
    try:
        from verificador import costos as cs
        c = vc.Carga()
        c.prev_path, c.abrir = excel_path, libro
        try:
            vc.analisis_anterior_ap(c)
        except Exception:
            pass
        try:
            pls, _ = cs.detectar_planillas(c.prev_ctx)
            if pls:
                vc.analisis_anterior_costos(c, pls[0].hoja)
        except Exception:
            pass
    except Exception:
        pass


def resultado_para_guardar(res):
    """Lo que se persiste de un análisis: el resumen por control (para listar redeterminaciones sin
    tener que volver a analizar) y los contadores de observaciones por gravedad."""
    resumen = [{'control': v.titulo, 'estado': v.estado, 'mensaje': v.mensaje} for v in res['veredictos']]
    n = ob.contar(res['obs'])
    return resumen, n.get('ERROR', 0), n.get('MENOR', 0), n.get('AVISO', 0)


def obtener_o_rehacer(id_, obtener_redet, boletin_por_id, stream=None, reglas_de=None):
    """Devuelve el resultado en memoria de esta redeterminación; si el programa se reinició y no está,
    lo vuelve a calcular con los mismos archivos y ajustes manuales guardados (obtener_redet /
    boletin_por_id son funciones de almacen.py, pasadas como parámetro para no crear una dependencia
    circular)."""
    if id_ in CACHE:
        return CACHE[id_]
    redet = obtener_redet(id_)
    if redet is None:
        return None
    pdfs = [boletin_por_id(i)['ruta'] for i in redet['boletin_ids'] if boletin_por_id(i)]
    res = ejecutar(redet['excel_ruta'], pdfs, redet.get('prev_ruta'), redet['datos_informe'], redet.get('overrides'), stream,
                   reglas=reglas_de(id_) if reglas_de else None)
    CACHE[id_] = res
    return res


# ----------------------------------------------------------------------
# Generar UN archivo a la vez (el usuario elige cuál, y cuándo)
# ----------------------------------------------------------------------
def _filas_descartadas(res):
    return [(o.titulo, o.gravedad, o.n, (g.get('motivo') or ''), g.get('usuario', ''), g.get('fecha', ''),
             'toda la empresa' if g.get('empresa_id') else 'esta redeterminación')
            for o, g in (res.get('obs_descartadas') or [])]


def generar_excel(res, carpeta):
    ruta = nombre_salida_unico(res['excel_path'], carpeta)
    rp.escribir_reporte(ruta, res['sesion'], res['veredictos'], res['r'], res['obs'])
    filas = _filas_descartadas(res)
    if filas:
        # lo que el administrador descartó NO está en "Observaciones", pero sí queda a la vista, con su motivo
        import openpyxl
        from openpyxl.styles import Font
        wb = openpyxl.load_workbook(ruta)
        ws = wb.create_sheet('Descartadas', 2)
        ws.append(['Observaciones descartadas por el administrador (no cuentan en el resultado)'])
        ws['A1'].font = Font(bold=True, size=12)
        ws.append([])
        ws.append(['Observación', 'Gravedad original', 'Lugares', 'Motivo', 'Quién', 'Cuándo', 'Alcance'])
        for c in ws[3]:
            c.font = Font(bold=True)
        for f in filas:
            ws.append(list(f))
        for col, ancho in zip('ABCDEFG', (60, 16, 10, 60, 14, 18, 20)):
            ws.column_dimensions[col].width = ancho
        wr = wb[wb.sheetnames[0]]
        wr.append([])
        wr.append([f"{len(filas)} observación(es) descartada(s) por el administrador: ver la hoja 'Descartadas' (los detalles "
                   "técnicos de cada control siguen listando todo lo que el programa encontró)."])
        wb.save(ruta)
    return ruta


def generar_word(res, carpeta):
    ruta = nombre_salida_unico(res['excel_path'], carpeta, 'Informe', '.docx')
    iw.escribir_informe(ruta, res['obs'], res['r'], res['veredictos'], res['sesion'], res['datos_informe'], res['version'])
    filas = _filas_descartadas(res)
    if filas:
        import docx
        d = docx.Document(ruta)
        d.add_heading('Observaciones descartadas por el administrador', level=2)
        d.add_paragraph('Las siguientes observaciones del programa se revisaron y se consideró que no corresponden; '
                        'no forman parte de las observaciones de este informe.')
        t = d.add_table(rows=1, cols=3)
        t.style = 'Table Grid'
        for c, txt in zip(t.rows[0].cells, ('Observación', 'Motivo', 'Quién / cuándo')):
            c.text = txt
        for titulo, grav, n, motivo, quien, cuando, alcance in filas:
            fila = t.add_row().cells
            fila[0].text, fila[1].text, fila[2].text = titulo, motivo, f"{quien}, {cuando}"
        d.save(ruta)
    return ruta


def generar_copia(res, carpeta):
    if res['fm'] is None:
        raise ErrorVerificacion("La copia anotada necesita leer las fórmulas del Excel (.xlsx/.xlsm); este archivo no lo permite.")
    ruta = nombre_salida_unico(res['excel_path'], carpeta, 'Copia anotada')
    ca.escribir_copia(ruta, res['fm'], res['obs'])
    return ruta


# ----------------------------------------------------------------------
# Reporte PDF para la contratista: el usuario ELIGE qué observaciones (y qué celdas) van
# ----------------------------------------------------------------------
def clave_celda(u):
    return f"{u.hoja}!{u.celda}"


def seleccion_pdf(res, guardada=None):
    """Para la pantalla de "elegir qué va al PDF": [{'o': observación, 'marcada': bool, 'celdas': [(ubicación,
    marcada)]}]. Por defecto van SOLO los errores (con todas sus celdas). Si ya se generó antes un PDF de esta
    redeterminación, se respeta lo que se eligió esa vez; las observaciones que aparecen recién (ej. después de
    subir un archivo corregido) toman el criterio por defecto."""
    g = guardada or {}
    vistas = set(g.get('vistas') or [])
    elegidas = set(g.get('obs') or [])
    sin = {k: set(v) for k, v in (g.get('sin_celdas') or {}).items()}
    out = []
    for o in res['obs']:
        marcada = (o.firma in elegidas) if o.firma in vistas else (o.gravedad == 'ERROR')
        fuera = sin.get(o.firma, set())
        out.append({'o': o, 'marcada': marcada, 'celdas': [(u, clave_celda(u) not in fuera) for u in o.ubicaciones]})
    return out


def comparar_con_version_anterior(res, obs_anteriores):
    """obs_anteriores: [{'firma','titulo','gravedad'}] de la versión anterior del archivo (ver almacen.nueva_version).
    Devuelve {'corregidas': [dict], 'persisten': {firma}, 'nuevas': {firma}} comparando por CAUSA (firma), o None si
    no hay versión anterior con qué comparar."""
    if obs_anteriores is None:
        return None
    ahora = {o.firma for o in res['obs']}
    descartadas = {o.firma for o, _ in (res.get('obs_descartadas') or [])}
    antes = {x['firma'] for x in obs_anteriores}
    return {'corregidas': [x for x in obs_anteriores if x['firma'] not in ahora and x['firma'] not in descartadas],
            'persisten': ahora & antes, 'nuevas': ahora - antes, 'n_antes': len(antes)}


def generar_pdf(res, carpeta, seleccion=None, info=None):
    """seleccion: {'obs': [firmas], 'sin_celdas': {firma: ['Hoja!A1', ...]}, 'nota': texto}. Sin selección: solo
    los errores. Las observaciones que quedan sin ninguna celda elegida no van."""
    from verificador import informe_pdf as ip
    sel = seleccion or {}
    elegidas = set(sel.get('obs') or [o.firma for o in res['obs'] if o.gravedad == 'ERROR'])
    sin = {k: set(v) for k, v in (sel.get('sin_celdas') or {}).items()}
    items = []
    for o in res['obs']:
        if o.firma not in elegidas:
            continue
        us = [u for u in o.ubicaciones if clave_celda(u) not in sin.get(o.firma, set())]
        if us or not o.ubicaciones:
            items.append((o, us))
    info = dict(info or {})
    info.setdefault('archivo', os.path.basename(res['excel_path']))
    info['nota'] = (sel.get('nota') or '').strip()
    ruta = nombre_salida_unico(res['excel_path'], carpeta, 'Observaciones', '.pdf')
    ip.escribir_pdf(ruta, items, res['datos_informe'], info)
    return ruta


# ----------------------------------------------------------------------
# Planillas VAR y EV armadas con los índices oficiales (no necesita el análisis: solo el Excel y los boletines)
# ----------------------------------------------------------------------
_BOLETINES = {}       # (ruta, tamaño, fecha) -> Boletin ya leído (el Anexo se carga de datos/anexos_indec, es rápido)


def _boletin(ruta):
    try:
        st = os.stat(ruta)
    except OSError:
        return None
    k = (ruta, st.st_size, st.st_mtime)
    if k not in _BOLETINES:
        try:
            _BOLETINES[k] = Boletin(ruta, progreso=False)
        except Exception:
            _BOLETINES[k] = None
    return _BOLETINES[k]


def generar_var_ev(excel_path, rutas_boletines, carpeta, manuales=None, avance=None):
    """Excel con las hojas VAR y EV de TODAS las redeterminaciones del archivo, completadas con los índices del
    boletín de cada mes (se usan todos los boletines de la biblioteca: la EV necesita los meses intermedios).
    'manuales': índices de la VAR asignados por el administrador. Devuelve la ruta."""
    from verificador import planillas_var_ev as pv
    bols = []
    for i, ruta in enumerate(rutas_boletines, start=1):
        if avance:
            avance(int(60 * i / max(1, len(rutas_boletines))), f"Leyendo los boletines de la biblioteca ({i}/{len(rutas_boletines)})…")
        b = _boletin(ruta)
        if b is not None:
            bols.append(b)
    if not bols:
        raise ErrorVerificacion("No hay boletines del INDEC en la biblioteca: subilos en «Biblioteca» y volvé a probar.")
    if avance:
        avance(70, "Armando las planillas VAR y EV…")
    ruta = nombre_salida_unico(excel_path, carpeta, 'Planillas VAR y EV')
    pv.generar(libro(excel_path), bols, ruta, os.path.basename(excel_path), manuales=manuales)
    return ruta


GENERADORES = {'excel': generar_excel, 'word': generar_word, 'copia': generar_copia, 'pdf': generar_pdf,
               'var_ev': generar_var_ev}
NOMBRES_REPORTE = {'excel': 'Excel de verificación', 'word': 'Informe Word', 'copia': 'Copia anotada del Excel',
                   'pdf': 'Reporte PDF para la contratista', 'var_ev': 'Planillas VAR y EV con índices INDEC',
                   'providencia': 'Providencia y acta de comisión (Word)'}

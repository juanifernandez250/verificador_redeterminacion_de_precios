# -*- coding: utf-8 -*-
"""
trabajos.py
------------
Procesos largos (analizar una redeterminación, generar un reporte, leer un PDF) corren en un hilo
aparte para que la página no se quede "colgada": el navegador dispara el trabajo, recibe un ID, y
pregunta cada tanto "¿cómo vas?" (sondeo/polling). La barra de progreso que se ve es REAL: se arma
leyendo, en vivo, el mismo texto que el paquete `verificador` ya imprime por consola (sus barras
[####------] NN%), no una animación inventada.
"""
import contextlib
import re
import sys
import threading
import time
import uuid

_REGISTRO = {}
_LOCK = threading.Lock()
_BARRA_RE = re.compile(r'^(.*?)\s*\[[#\-]+\]\s*(\d{1,3})%\s*\(\d+/\d+\)\s*$')
_PAGINA_RE = re.compile(r'p[aá]gina\s+(\d+)\s*/\s*(\d+)', re.IGNORECASE)
_PDF_RE = re.compile(r'^(.+?\.pdf):', re.IGNORECASE)
_CONTROLES = ('Ítems INDEC', 'VAR', 'Análisis de precios', 'Planilla de costos')


class Trabajo:
    def __init__(self):
        self.estado = 'corriendo'        # corriendo | listo | error
        self.paso = 'Iniciando…'
        self.pct = None                  # 0-100, o None (no se sabe cuánto falta: barra indeterminada)
        self.pct_total = 2               # 0-100: avance del proceso COMPLETO (todas las etapas)
        self.resultado = None
        self.error = None
        self.creado = time.time()

    def como_json(self):
        return {'estado': self.estado, 'paso': self.paso, 'pct': self.pct, 'pct_total': self.pct_total,
                'resultado': self.resultado, 'error': self.error}


def crear():
    t = Trabajo()
    id_ = uuid.uuid4().hex
    with _LOCK:
        _REGISTRO[id_] = t
        _purgar()
    return id_, t


def obtener(id_):
    with _LOCK:
        return _REGISTRO.get(id_)


def corriendo():
    """Cuántos trabajos en segundo plano (análisis, reportes, lectura de PDFs) siguen corriendo ahora."""
    return sum(1 for t in list(_REGISTRO.values()) if t.estado == 'corriendo')


def _purgar(minutos=45):
    """Los trabajos terminados hace rato se olvidan, para no acumular memoria en una sesión larga."""
    limite = time.time() - minutos * 60
    for k in [k for k, t in _REGISTRO.items() if t.estado != 'corriendo' and t.creado < limite]:
        del _REGISTRO[k]


class StreamEnVivo:
    """Para usar con contextlib.redirect_stdout(...). Cada línea que el análisis va imprimiendo
    actualiza 'paso' y 'pct' del trabajo (para la barra de progreso), y las líneas ya cerradas (con
    salto de línea real, no solo '\\r') se guardan para la bitácora final."""

    def __init__(self, trabajo):
        self._t = trabajo
        self._linea = ''
        self.cerradas = []
        self._carga_vista = False
        self._pdfs_vistos = set()
        self._controles_vistos = set()
        self._formulas_vista = False
        self._excel_listo = False
        self._frac_excel = 0.0

    def write(self, s):
        for parte in re.split(r'(\r|\n)', s):
            if parte in ('\r', '\n'):
                self._cerrar(guardar=(parte == '\n'))
            elif parte:
                self._linea += parte
        return len(s)

    def _cerrar(self, guardar):
        texto = self._linea.strip()
        self._linea = ''
        if texto:
            m = _BARRA_RE.match(texto)
            if m:
                self._t.paso, self._t.pct = m.group(1).strip() or 'Analizando…', int(m.group(2))
            else:
                mp = _PAGINA_RE.search(texto)
                if mp and not texto.startswith(('=', '#', '-')):
                    n, total = int(mp.group(1)), int(mp.group(2))
                    self._t.paso = texto
                    self._t.pct = round(100 * n / total) if total else None
                elif not texto.startswith(('=', '#', '-')):
                    self._t.paso, self._t.pct = texto, None
            self._actualizar_avance_total(texto)
        if guardar and texto:
            self.cerradas.append(texto)

    def _actualizar_avance_total(self, texto):
        """Avance del proceso COMPLETO (todas las etapas), no solo del paso actual. Se cuentan las
        etapas que YA aparecieron (carga, cada PDF leído, cada control corrido, las fórmulas) contra
        una estimación del total; como no sabemos de antemano cuántos PDF o controles van a correr
        realmente, el total crece junto con lo que se va viendo, así el número nunca retrocede ni se
        adelanta. Llega al 100% recién cuando el trabajo termina de verdad (ver trabajos.lanzar)."""
        if texto == 'CARGANDO ARCHIVOS':
            self._carga_vista = True
        # Abrir el Excel principal suele ser lo que más tarda: cuenta como una etapa doble, que avanza
        # de a poco con la barra real de lectura de hojas (la del Excel anterior, si hay, ya no suma).
        if not self._excel_listo:
            if texto.startswith('Excel abierto:'):
                self._excel_listo, self._frac_excel = True, 1.0
            else:
                mb = _BARRA_RE.match(texto)
                if mb and mb.group(1).strip().startswith('Abriendo el Excel'):
                    self._frac_excel = max(self._frac_excel, int(mb.group(2)) / 100)
        m = _PDF_RE.match(texto)
        if m:
            self._pdfs_vistos.add(m.group(1))
        if texto.startswith('>>> '):
            titulo = texto[4:]
            for nombre in _CONTROLES:
                if nombre.lower() in titulo.lower():
                    self._controles_vistos.add(nombre)
                    break
        if texto.startswith('Leyendo las fórmulas del Excel'):
            self._formulas_vista = True
        hecho = (2 * self._frac_excel) + len(self._pdfs_vistos) + len(self._controles_vistos) + (1 if self._formulas_vista else 0)
        total = 2 + len(self._pdfs_vistos) + len(_CONTROLES) + 1
        self._t.pct_total = max(self._t.pct_total, min(96, round(100 * hecho / total)))

    def flush(self):
        pass

    def valor(self):
        if self._linea.strip():
            self.cerradas.append(self._linea.strip())
            self._linea = ''
        return '\n'.join(self.cerradas)


class StreamEtapa(StreamEnVivo):
    """Como StreamEnVivo, pero para trabajos cortos que NO son un análisis completo (abrir una
    redeterminación nueva para elegir boletines, preparar los ajustes manuales): el avance total lo
    fija quien llama con etapa(desde, hasta, paso), y la barra real de lo que se imprime adentro
    (ej. la lectura de las hojas del Excel) mueve el total dentro de ese tramo."""

    def __init__(self, trabajo):
        super().__init__(trabajo)
        self._desde, self._hasta = 0, 100

    def etapa(self, desde, hasta, paso):
        self._desde, self._hasta = desde, hasta
        self._t.paso, self._t.pct = paso, None
        self._t.pct_total = max(self._t.pct_total, desde)

    def _actualizar_avance_total(self, texto):
        frac = None
        m = _BARRA_RE.match(texto)
        if m:
            frac = int(m.group(2)) / 100
        else:
            mp = _PAGINA_RE.search(texto)          # lectura de un PDF: buscar el Anexo (30%) y leer sus tablas (70%)
            if mp and int(mp.group(2)):
                r = int(mp.group(1)) / int(mp.group(2))
                frac = 0.3 + 0.7 * r if 'tablas' in texto else 0.3 * r
        if frac is not None:
            self._t.pct_total = max(self._t.pct_total, round(self._desde + (self._hasta - self._desde) * frac))


class _SalidaPorHilo:
    """sys.stdout que manda lo que imprime CADA HILO a su propio destino. Antes se usaba
    contextlib.redirect_stdout, que cambia sys.stdout para TODO el programa: si se abrían dos cosas a
    la vez (ej. analizar y, mientras, elegir una hoja en 'corregir a mano'), los mensajes de una se
    mezclaban en la barra de progreso de la otra."""

    def __init__(self, original):
        self._original = original
        self._local = threading.local()

    def _destino(self):
        return getattr(self._local, 'destino', None) or self._original

    def write(self, s):
        d = self._destino()
        return d.write(s) if d is not None else len(s)

    def flush(self):
        d = self._destino()
        if d is not None and hasattr(d, 'flush'):
            d.flush()

    def __getattr__(self, nombre):
        return getattr(self._original, nombre)


if not isinstance(sys.stdout, _SalidaPorHilo):
    sys.stdout = _SalidaPorHilo(sys.stdout)
_SALIDA = sys.stdout


@contextlib.contextmanager
def redirigir(destino):
    """Como contextlib.redirect_stdout(destino), pero solo para el hilo actual."""
    if not isinstance(sys.stdout, _SalidaPorHilo):        # alguien pisó sys.stdout: volver a instalar
        sys.stdout = _SALIDA
    anterior = getattr(_SALIDA._local, 'destino', None)
    _SALIDA._local.destino = destino
    try:
        yield destino
    finally:
        _SALIDA._local.destino = anterior


def lanzar(func, *args, **kwargs):
    """Corre func(trabajo, *args, **kwargs) en un hilo aparte. 'func' debe dejar el resultado en
    trabajo.resultado y trabajo.estado='listo', o trabajo.error y trabajo.estado='error' (para poder
    controlar en qué momento exacto se considera terminado, ej. después de guardar en la base)."""
    id_, t = crear()
    hilo = threading.Thread(target=func, args=(t,) + args, kwargs=kwargs, daemon=True)
    hilo.start()
    return id_

# -*- coding: utf-8 -*-
"""
web_control.py  --  puente entre la página web (autocontrol en el navegador) y el código del verificador.

Corre dentro del navegador (Pyodide). Usa EXACTAMENTE los mismos controles que el programa del organismo
(paquete `verificador` + interfaz/motor.py). La página le pasa rutas del sistema de archivos virtual del navegador:
el Excel nunca sale de la computadora de quien lo controla.

  preparar(excel)                     -> {'meses': [...], 'faltan': [...], 'datos': {...}}
  leer_boletin_pdf(pdf)               -> {'ok', 'mes', 'nombre', 'lines'} (el Anexo, para guardarlo en el navegador)
  analizar(excel, anexos_json, prev)  -> resultado para mostrar (veredicto, controles, observaciones)
  pdf_observaciones(destino)          -> ruta del PDF con lo que hay que corregir
  copia_anotada(destino)              -> ruta del Excel con las celdas marcadas
"""
import json
import os
import sys
import types

# pdfplumber importa pypdfium2 (dibujar páginas), que no existe en el navegador. El verificador solo extrae texto.
if 'pypdfium2' not in sys.modules:
    sys.modules['pypdfium2'] = types.ModuleType('pypdfium2')

from interfaz import motor                                         # noqa: E402
from verificador import observaciones as ob                        # noqa: E402
from verificador.comunes import ErrorVerificacion, fmt_es, mes_txt  # noqa: E402
from verificador.pdf_indec import (Boletin, construir_mapa_columnas, detectar_fecha_publicacion,  # noqa: E402
                                   detectar_rangos_cuadros, leer_pdf_texto)

MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre',
         'noviembre', 'diciembre']
_ESTADO = {'OK': ('ok', 'OK'), 'REVISAR': ('error', 'Con errores'), 'AVISO': ('aviso', 'OK, con avisos'),
           'OMITIDO': ('gris', 'No se pudo controlar'), 'ERROR': ('gris', 'No se pudo controlar')}
_GRAV = {'ERROR': 'Error: hay que corregirlo', 'MENOR': 'Diferencia menor: revisar', 'AVISO': 'Aviso: no es un error'}
_ULTIMO = {}


class BoletinAnexo(Boletin):
    """Un boletín a partir del texto del Anexo ya extraído (incluido en la página o leído antes de un PDF)."""

    def __init__(self, nombre, lines):
        self.path = nombre
        self.nombre = nombre
        self.desde_guardado = True
        self.lines = lines
        self.rangos = detectar_rangos_cuadros(lines)
        self.pub = detectar_fecha_publicacion(lines)
        self.meses = construir_mapa_columnas(lines, self.pub)
        if not self.meses:
            raise ErrorVerificacion(f"'{nombre}' no parece el Anexo de obra pública del INDEC Informa.")


def _siguiente(ym):
    return (ym[0] + 1, 1) if ym[1] == 12 else (ym[0], ym[1] + 1)


def que_boletin(ym):
    s = _siguiente(ym)
    return f"INDEC Informa de {MESES[s[1] - 1]} {s[0]} (trae los índices de {MESES[ym[1] - 1]} {ym[0]})"


def preparar(excel, meses_disponibles_json):
    disponibles = {tuple(m) for m in json.loads(meses_disponibles_json)}
    meses = [tuple(m) for m in motor.meses_necesarios(excel)]
    datos = motor.datos_obra_seguro(excel)
    faltan = [m for m in meses if m not in disponibles]
    return json.dumps({'meses': [list(m) for m in meses], 'meses_txt': [mes_txt(m) for m in meses],
                       'faltan': [{'ym': list(m), 'mes': mes_txt(m), 'boletin': que_boletin(m)} for m in faltan],
                       'obra': datos.get('obra') or '', 'contratista': datos.get('contratista') or ''})


def leer_boletin_pdf(pdf):
    """Extrae el Anexo de obra pública de un PDF del INDEC Informa (tarda: el PDF tiene cientos de páginas)."""
    try:
        lines = leer_pdf_texto(pdf, progreso=True)
        b = BoletinAnexo(os.path.basename(pdf), lines)
    except Exception as e:
        return json.dumps({'ok': False, 'error': f"{os.path.basename(pdf)}: no pude leerlo como boletín del INDEC ({e})"})
    u = b.ultimo_mes
    s = _siguiente(u)
    nombre = f"INDEC Informa {MESES[s[1] - 1]} {s[0]} (índices de {MESES[u[1] - 1]} {u[0]})"
    return json.dumps({'ok': True, 'ym': list(u), 'mes': mes_txt(u), 'nombre': nombre, 'lines': lines})


def _dec(o):
    return 1 if o.tipo in ('indice', 'indice_directo', 'var') else 2


def _valor(x, dec):
    if x is None:
        return ''
    if isinstance(x, bool):
        return 'Sí' if x else 'No'
    if isinstance(x, (int, float)):
        return fmt_es(x, dec)
    return str(x)


def analizar(excel, anexos_json_paths_json, meses_json, prev=None, nombre=''):
    """anexos_json_paths_json: rutas (en el sistema de archivos del navegador) de los .json de Anexo disponibles."""
    from verificador.informe_pdf import _orden_ubicaciones, _que_esta_mal
    meses = [tuple(m) for m in json.loads(meses_json)]
    bols = {}
    for ruta in json.loads(anexos_json_paths_json):
        try:
            with open(ruta, encoding='utf-8') as f:
                d = json.load(f)
            b = BoletinAnexo(d.get('nombre') or os.path.basename(ruta), d['lines'])
            bols[b.ultimo_mes] = b
        except Exception:
            continue
    elegidos, faltan = [], []
    for m in meses:
        b = bols.get(m)
        if b is None:
            faltan.append(m)
        elif b not in elegidos:
            elegidos.append(b)
    datos = motor.datos_obra_seguro(excel)
    res = motor.ejecutar(excel, elegidos, prev or None, datos, {})
    _ULTIMO.clear()
    _ULTIMO.update(res=res, excel=excel, nombre=nombre or os.path.basename(excel))
    obs = sorted(res['obs'], key=lambda o: {'ERROR': 0, 'MENOR': 1, 'AVISO': 2}.get(o.gravedad, 3))
    n = ob.contar(obs)
    sin_hacer = [v for v in res['veredictos'] if v.estado in ('OMITIDO', 'ERROR')]
    if n.get('ERROR'):
        clase, titulo = 'error', f"{n['ERROR']} error{'es' if n['ERROR'] != 1 else ''} para corregir"
    elif n.get('MENOR'):
        clase, titulo = 'menor', (f"Sin errores, pero con {n['MENOR']} diferencia{'s' if n['MENOR'] != 1 else ''} "
                                  f"menor{'es' if n['MENOR'] != 1 else ''} para revisar")
    else:
        clase, titulo = 'ok', 'OK: no se encontraron errores'
    sub = []
    if sin_hacer:
        sub.append('Hay controles que no se pudieron hacer (ver abajo): el resultado vale solo para lo que se controló.')
    if faltan:
        sub.append('Faltó el boletín del INDEC de ' + ', '.join(mes_txt(m) for m in faltan)
                   + ': esos meses no se compararon con los índices oficiales.')
    if clase == 'ok' and (sin_hacer or faltan):
        clase, titulo = 'parcial', 'OK en lo que se pudo controlar'
    controles = [{'titulo': v.titulo, 'clase': _ESTADO.get(v.estado, ('gris', v.estado))[0],
                  'estado': _ESTADO.get(v.estado, ('gris', v.estado))[1], 'mensaje': v.mensaje} for v in res['veredictos']]
    items = []
    for o in obs:
        dec = _dec(o)
        ubic = [{'hoja': u.hoja, 'celda': u.celda, 'dice': _valor(u.actual, dec), 'debe': _valor(u.correcto, dec),
                 'origen': u.rol == 'origen'} for u in _orden_ubicaciones(o, o.ubicaciones)]
        items.append({'gravedad': o.gravedad, 'grav': _GRAV.get(o.gravedad, o.gravedad), 'titulo': o.titulo,
                      'que': _que_esta_mal(o), 'accion': o.accion or '', 'fuente': o.fuente or '', 'ubic': ubic})
    return json.dumps({'veredicto': {'clase': clase, 'titulo': titulo, 'sub': sub, 'n': n}, 'controles': controles,
                       'items': items, 'obra': datos.get('obra') or '', 'copia': res.get('fm') is not None,
                       'segundos': round(res.get('segundos') or 0, 1)})


def pdf_observaciones(carpeta):
    res = _ULTIMO['res']
    sel = {'obs': [o.firma for o in res['obs'] if o.gravedad in ('ERROR', 'MENOR')],
           'nota': 'Autocontrol realizado por la contratista antes de presentar la planilla.'}
    return motor.generar_pdf(res, carpeta, sel, {'redet': _ULTIMO['nombre'], 'archivo': _ULTIMO['nombre']})


def copia_anotada(carpeta):
    return motor.generar_copia(_ULTIMO['res'], carpeta)
